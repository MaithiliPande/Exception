package threaddemo;

public class MyThread extends Thread{
	
//	public MyThread()
//	{
//		new Thread(this).start();
//	}
	
	@Override
	public void run() {
		System.out.println("------------"+Thread.currentThread().getName()+"-------Started");
		//String threadName = Thread.currentThread().getName();
//		loopCast(threadName);
		for(int i=0; i<10; i++)
		{
			try {
				Thread.sleep(1000);
				System.out.println(Thread.currentThread().getName()+":"+i);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		System.out.println("------------"+Thread.currentThread().getName()+"-------End");
	}
	
	
//	private void loopCast(String threadName)
//	{
//		for(int i=0; i<10;i++)
//		{
//			System.out.println(threadName+" i: "+i);
//		}
//	}
}
