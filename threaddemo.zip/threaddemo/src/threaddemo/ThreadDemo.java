package threaddemo;

public class ThreadDemo {
	public static void main(String[] args) {
		System.out.println("------------"+Thread.currentThread().getName()+"-------Started");
		MyThread t1= new MyThread();
		MyThread t2= new MyThread();	
		MyThread t3= new MyThread();
		t1.setName("Maithili");
		t2.setName("Ayushi");
		t3.setName("Me");
		t1.start();
		
		
		try {
			t1.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		t2.start();
		t3.start();
		System.out.println("------------"+Thread.currentThread().getName()+"-------End");
	}

}
