package employeeCompensation;

import java.util.Scanner;
/**
 * This is the Test class.
 * @author aakash.jangid
 *
 */
public class EmployeeTest {

	public static void main(String[] args) {
		String conti;
		do{
			System.out.println("********Compensation Management********");
			System.out.println("0. Exit");
			System.out.println("1. Enter Employee information");
			System.out.println("2. Display Employees Information");
			
			Scanner scan = new Scanner(System.in);
			int choice = scan.nextInt();
			
			switch(choice) {
			case 0:
				System.exit(0);
			
			case 1:{
				System.out.println("Enter Employee Number -");
				int number= scan.nextInt();

				System.out.println("Enter Compensation -");
				float compensation = scan.nextFloat();
				
				Employee employee = new Employee(number, compensation);
				employee.addEmployee(employee);
				System.out.println("Employee information added");
			}
			break;
			
			case 2:{
				Employee.display();
			}
	}
			System.out.println("Enter More ? (Y/N)");
			conti = scan.next();			
		}while(conti.equalsIgnoreCase("y"));
}
}
