package employeeCompensation;

/**
 * This class has the state and methods.
 * @author aakash.jangid
 *
 */
public class Employee {
	/**
	 * This is the Employee Number
	 */
	int number;
	/**
	 * This is the Employee Compensation.
	 */
	float compensation;
	/**
	 * This is the employee repository which will store the employee information.
	 */
	static Employee[] employeearray = new Employee[3];
	/**
	 * This is the location variable where the employee will be stored in the repository.
	 */
	static int location = 0;
	
	public Employee() {
	}
	
	public Employee(int number, float compensation) {
		this.number=number;
		this.compensation=compensation;
	}

	public int getNumber() {
		return number;
	}

	public float getCompensation() {
		return compensation;
	}
	
	/**
	 * This will display the employees information that is number and compensation.
	 */
	public static void display() {
		Employee[] temp = new Employee[location];
		for (int i = 0; i < location; i++) {
			temp[i] = employeearray[i];
		}
		for (int i = 0; i < temp.length; i++) 
			System.out.println(temp[i].toString());
	}
	
	/**
	 * This will add the employee in the repository.
	 * @param employee
	 */
	void addEmployee(Employee employee) {
		employeearray[location++]=employee;
	}
	
	public String toString() {
		return "Employee No - "+this.number+", Compensation - "+this.compensation;
	}
}
