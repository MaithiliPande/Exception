package com.yash.additionofsequence;

import static org.junit.Assert.*;

import org.junit.Test;

public class AdditionOfSequenceTest {
	
	private static final String Given_String = "10+20+30+40+4@4";

	/*@Test
	public void empty_test() throws Exception{
		
		AdditionOfSequence addition = new AdditionOfSequence();
		int output = addition.result("");
		assertEquals(0, output);
	}*/
	
	/*@Test
	public void single_string_view() throws Exception{
		
		AdditionOfSequence addition = new AdditionOfSequence();
		int output = addition.result(Given_String);
		assertEquals(10, output);
	}*/

	@Test
	public void given_string_test() throws Exception{
		
		AdditionOfSequence addition = new AdditionOfSequence();
		String output = addition.result(Given_String);
		assertEquals("108", output);
	}
}
