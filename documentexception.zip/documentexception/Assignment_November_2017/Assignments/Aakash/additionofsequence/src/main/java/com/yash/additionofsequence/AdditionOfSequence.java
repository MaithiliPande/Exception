package com.yash.additionofsequence;

import java.util.Arrays;

public class AdditionOfSequence {

	public String result(String input) {
	
		if(input.isEmpty()) {
			return "0";
		}
		else {
			input = input.replaceAll("[^0-9 || \\+]", "+");
			input = input.replaceAll("\\++", "\\+");
			String a = Integer.toString(Arrays.stream(input.split("\\+")).mapToInt(Integer::parseInt).sum());
			return a;
		}
	}
}
