package com.yash.carshop;

import java.util.ArrayList;
import com.yash.carshop.*;

class Car{
	
	int speed;
	String owner;
	String type;
	public int getSpeed() {
		return speed;
	}
	public void setSpeed(int speed) {
		this.speed = speed;
	}
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}

	
}
public class CarShop {
	
	static final ArrayList<Car> c1 = new ArrayList<Car>() ;

	public String setCar(int speed, String owner, String cartype) {
		
		Car car = new Car();
		car.setOwner(owner);
		car.setType(cartype);
		car.setSpeed(speed);
		
		c1.add(car);
		
		return "Car Added Successfully";
	
	}
	
	public int carcount() {
		
		return c1.size();
	}

	public String getCar(String name) {
	
		for(Car c2: c1) {
			if(c2.owner.equals(name)) {
				return "Owner : "+c2.getOwner()+" Speed : "+c2.getSpeed()+" Type : "+c2.getType();
			}
		}
		return null;
	}
	
	
}

	