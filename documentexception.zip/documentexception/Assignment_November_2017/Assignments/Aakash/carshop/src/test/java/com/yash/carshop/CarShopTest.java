package com.yash.carshop;

import static org.junit.Assert.*;

import org.junit.Test;

public class CarShopTest {

//@Test
//public void empty_test() {
		
//CarShop carshop = new CarShop();
//String result = carshop.setCar(0,"","");
//assertEquals(null, result);
//}

@Test
public void set_car() {
	
CarShop carshop = new CarShop();
String result = carshop.setCar(100,"Aakash","SWIFT");
carshop.setCar(80,"Ishan","ALTO");
carshop.setCar(50,"Yash","NANO");
int count =carshop.carcount();
assertEquals("Car Added Successfully", result);
assertEquals(3, count);
String ownerinfo = carshop.getCar("Aakash");

assertEquals("Owner : Aakash Speed : 100 Type : SWIFT", ownerinfo);
}
}

//@Test
//public void get_car() {
//	
//CarShop carshop = new CarShop();
//String result = carshop.getCar("Aakash");
//
//assertEquals("Owner : Aakash Speed : 100 Type : SWIFT", result);
//}
//}
