/**
 * This defines the methods and the states of the program.
 * @author aakash.jangid
 *
 */
public class Time {
	/**
	 * This is seconds of time.
	 */
	int seconds;
	/**
	 * This is minutes of time.
	 */
	int minutes;
	/**
	 * This is hours of time.
	 */
	int hours;
	
	public Time() {
	}
	
	/**
	 * This is the constructor which will check the time as per the time format i.e. not more than 60 sec, 60 mins and 24 hours.
	 * @param seconds
	 * @param minutes
	 * @param hours
	 */
	public Time(int seconds, int minutes, int hours) {
		if(seconds<0 || seconds>59) {
			System.out.println("Invalid Input");
		}
		else
		this.seconds=seconds;
		if(minutes<0 || minutes>59) {
			System.out.println("Invalid Input");
		}
		else
		this.minutes=minutes;
		if(hours<0 || hours>24) {
			System.out.println("Invalid Input");
		}
		else
		this.hours=hours;
	}

	public int getSeconds() {
		return seconds;
	}
	public int getMinutes() {
		return minutes;
	}
	public void setMinutes(int minutes) {
		this.minutes = minutes;
	}

	public void setHours(int hours) {
		this.hours = hours;
	}

	public int getHours() {
		return hours;
	}
	
	/**
	 * This will return the time in the Sec : Min : Hour
	 * @return
	 */
	String display() {
	return this.getHours()+":"+this.getMinutes()+":"+this.getSeconds();
	}
	
	/**
	 * This will return the sum of the entered time.
	 * @param time1
	 * @param time2
	 * @return
	 */
	String add(Time time1, Time time2) {
		if (time1.getSeconds()+time2.getSeconds()>59) {
			int time = time1.getSeconds()+time2.getSeconds();
			seconds = time%60;
			time1.setMinutes(time1.getMinutes()+1);
		}
		else
			seconds = time1.getSeconds()+time2.getSeconds();
		
		if (time1.getMinutes()+time2.getMinutes()>59) {
			int time = time1.getMinutes()+time2.getMinutes();
			minutes = time%60;
			time1.setHours(time1.getHours()+1);
		}
		else
			minutes = time1.getMinutes()+time2.getMinutes();
		
		if (time1.getHours()+time2.getHours()>23) {
			int time = time1.getHours()+time2.getHours();
			hours = time%24;
		}
		else
			hours = time1.getHours()+time2.getHours();
		
		return hours+":"+minutes+":"+seconds;
	}
}
