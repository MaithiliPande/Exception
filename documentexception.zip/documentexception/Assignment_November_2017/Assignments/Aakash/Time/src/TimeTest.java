import java.util.Scanner;

public class TimeTest {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter Hour -");
		int hour = scan.nextInt();
		System.out.println("Enter Min -");
		int min = scan.nextInt();
		System.out.println("Enter Seconds -");
		int sec= scan.nextInt();
				
		Time time1 = new Time(sec, min, hour);
				
		System.out.println("Enter Another Hour -");
		int hour1 = scan.nextInt();
		System.out.println("Enter Another Min -");
		int min1 = scan.nextInt();
		System.out.println("Enter Another Seconds -");
		int sec1= scan.nextInt();
				
		Time time2 = new Time(sec1, min1, hour1);
		System.out.println("First Entered Time - "+time1.display());
		System.out.println("Second Entered Time - "+time2.display());
		
		Time time = new Time();
		System.out.println("Sum is - "+time.add(time1, time2));
	}

}
