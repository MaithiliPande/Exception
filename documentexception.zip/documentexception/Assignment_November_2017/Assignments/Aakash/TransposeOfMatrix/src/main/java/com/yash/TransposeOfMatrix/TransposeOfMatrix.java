package com.yash.TransposeOfMatrix;

import java.util.Scanner;

/**
 * This class has the methods which are used to Transpose the Given Matrix
 * @author aakash.jangid
 *
 */
public class TransposeOfMatrix {

	/**
	 * This method will return the transpose of the matrix.
	 * @param matrix
	 * @return
	 */
	public int[][] matrixTranspose(int[][] matrix) {
		
		int[][] matrixx = matrix;
		int[][] temp= new int[matrix.length][matrix.length];
		for(int i=0;i<4;i++) {
			for(int j=0;j<4;j++) {
				temp[i][j]=matrixx[j][i];
				System.out.print(temp[i][j]+" ");
			}
			System.out.println(" ");
		}
		return null;
	}
	
	/**
	 * This will ask user to enter the matrix and will generate a matrix of it.
	 * @return
	 */
	public int[][] numbers() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the values of the Matrix ");
		int[][] number = new int[4][4];
		for(int i=0;i<number.length;i++) {
			for(int j=0;j<number.length;j++) {
			number[i][j]=scan.nextInt();
			}
			}
		return number;
}
}
