package com.yash.TransposeOfMatrix;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * This will test the transpose of the given matrix.
 * @author aakash.jangid
 *
 */
public class TransposeOfMatrixTest {
	
	//private static final int[][] matrix = new int[4][4];	

	@Test
	public void test() {
		TransposeOfMatrix transpose = new TransposeOfMatrix();
		int[][] actual = transpose.matrixTranspose(/*matrix,*/ transpose.numbers());
		assertArrayEquals(null, actual);
		
	}

}
