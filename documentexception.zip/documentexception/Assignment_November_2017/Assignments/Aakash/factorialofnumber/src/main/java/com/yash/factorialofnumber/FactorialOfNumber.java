package com.yash.factorialofnumber;

public class FactorialOfNumber {

	public int result(String givenNumber) {
		
		if(givenNumber.length()!=0) {
			int temp = 1;
			try {
				int a=Integer.parseInt(givenNumber);
				
				if(a>0) {
				while (a>0) {
				
					temp=temp*a;
					a=a-1;
				}		
				}
				
				else {
					return 0;
				}
		}
			catch(NumberFormatException nfe) {
				return 0;
			}
		return temp;
	}
		else {
			return 0;
	}

	}

}
