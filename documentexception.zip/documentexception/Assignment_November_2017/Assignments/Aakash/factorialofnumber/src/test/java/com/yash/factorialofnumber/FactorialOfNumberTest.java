package com.yash.factorialofnumber;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public final class FactorialOfNumberTest {
	
	private static final String Given_Number = "-5";
	private FactorialOfNumber factorial;
	
	@Before
	public void setUp() throws Exception {
		factorial = new FactorialOfNumber();
	}

	/*@Test
	public void Factorial_Of_Number() throws Exception{
		
		int answer = factorial.result("");
		assertEquals(0,answer);
	}
	*/
	
	@Test
	public void Factorial_Of_Number_Given() throws Exception{
		
		int answer = factorial.result(Given_Number);
		assertEquals(0,answer);
	}
	
	/*@Test
	public void Factorial_Of_Alphabets() throws Exception{
		
		int answer = factorial.result("ab");
		assertEquals(0,answer);
	}
	*/
}
