package com.yash.checktypeofinteger;

/**
 * This class contains method to check the type of the integer data
 * @author aakash.jangid
 *
 */
public class CheckTypeOfIntegerData {
	
	/**
	 * This will return the information about the type of given integer data
	 * in the terms of even odd positive and negative.
	 * @return
	 */
	public String checktype(int[] number) {
		
		int[] numbers = number;
		int evencount=0, oddcount = 0, postivecount=0, negativecount = 0;
		for(int i=0;i<numbers.length;i++) {
			if(number[i]%2==0) {
				evencount++;
			}
			else {
				oddcount++;
			}
			if(number[i]>0) {
				postivecount++;
			}
			if(number[i]<0) {
				negativecount++;
			}
		}
		
return "Even = "+evencount+", Odd = "+oddcount+", Positive = "+postivecount+", Negative = "+negativecount;
	}
}
