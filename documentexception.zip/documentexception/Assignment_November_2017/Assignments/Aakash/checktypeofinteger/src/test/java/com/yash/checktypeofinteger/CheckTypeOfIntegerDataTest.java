package com.yash.checktypeofinteger;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

/**
 * This test will check the Type of the Integer whether it is positive negative even or odd.
 * @author aakash.jangid
 *
 */
public class CheckTypeOfIntegerDataTest {
	
	private static final int[] number = new int[] {1,-2,3,-4,-5,0,7,8,-9};
	CheckTypeOfIntegerData checkType;
	
	@Before
	public void setUp() throws Exception{
	checkType = new CheckTypeOfIntegerData();
	}
	
	@Test
	public void test() {
		String actual = checkType.checktype(number);
		assertEquals("Even = 4, Odd = 5, Positive = 4, Negative = 4", actual);
	}
}
