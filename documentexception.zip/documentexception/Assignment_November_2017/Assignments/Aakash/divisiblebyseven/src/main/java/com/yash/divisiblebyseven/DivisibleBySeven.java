package com.yash.divisiblebyseven;

public class DivisibleBySeven {

	public int result(int start, int end) {
		int temp = 0;
		int sum = 0;
		
		if(start<100 || end>200) {
			System.out.println("Out of Bounds, Check the limit");
			return 0;
		}
		else{
			while(start<=end) {
		
			if(start%7==0) {
				temp = start;
				sum=temp+sum;
			}
			start++;
		}
		System.out.println("sum is "+sum);
		return sum;
	}
	}
}
