package com.yash.divisiblebyseven;

import static org.junit.Assert.*;

import org.junit.Test;

public class DivisibleBySevenTest {

//	@Test
//	public void empty_test() throws Exception{
//		
//		DivisibleBySeven divide = new DivisibleBySeven();
//		int output = divide.result(0);
//		assertEquals(0, output);
//	}
	
//	@Test
//	public void correct_sequel() throws Exception{
//		
//		DivisibleBySeven divide = new DivisibleBySeven();
//		int output = divide.result(199,101);
//		assertEquals(0, output);
//	}

	@Test
	public void test() throws Exception{
		
		DivisibleBySeven divide = new DivisibleBySeven();
		int output = divide.result(0,0);
		assertEquals(0, output);
	}

}
