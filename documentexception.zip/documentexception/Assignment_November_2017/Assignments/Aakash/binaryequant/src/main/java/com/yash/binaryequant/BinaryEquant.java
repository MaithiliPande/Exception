package com.yash.binaryequant;

public class BinaryEquant {

	public String result(String givenNumber) {
	
		
		if(givenNumber=="") {
		return "0";
	}
		else {
		int binaryequant=Integer.parseInt(givenNumber);
		String temp = Integer.toBinaryString(binaryequant);
		
		return temp;
}
}
}