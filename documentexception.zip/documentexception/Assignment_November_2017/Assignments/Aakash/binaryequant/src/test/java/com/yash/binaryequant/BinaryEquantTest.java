package com.yash.binaryequant;

import static org.junit.Assert.*;

import org.junit.Test;

public class BinaryEquantTest {

	private static final String Given_Number = "";
	@Test
	public void empty_test() throws Exception{

		BinaryEquant binary = new BinaryEquant();
		String result = binary.result("");
		assertEquals("0", result);
	}

	@Test
	public void any_binary_number() throws Exception{

		BinaryEquant binary = new BinaryEquant();
		String result = binary.result(Given_Number);
		assertEquals("0", result);
	}

	
}
