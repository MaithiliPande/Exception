package com.yash.arrayapp.employeeservice;

import com.yash.arrayapp.model.Employee;

/**
 * This will create the object of the employee and provide repository to employee and services
 */


public class EmployeeService {
	
	private Employee [] employeeRepository = new Employee[2];
	private int location = 0;
	
/**
 * This will store employee details in repository 
 * @param employee
 */
public void setEmployee(Employee employee) {
	
	if(location>=employeeRepository.length) {
		Employee []temp=new Employee[employeeRepository.length]; 
		temp=expandRepository(employeeRepository,employeeRepository.length);
		employeeRepository = new Employee[temp.length];
		
		for(int i=0;i<temp.length;i++) {
			employeeRepository[i]=temp[i];
		}
		
	}
		
		
	employeeRepository[location++]=employee;
}

private Employee[] expandRepository(Employee[] employeeRepository2, int length) {
	Employee []temprepository = new Employee[length*2];
	
	for(int i=0;i<employeeRepository2.length;i++) {
		temprepository[i]=employeeRepository2[i];
	}	
	return temprepository;
}

/**
 * This will return list of employees
 * @return
 */
public Employee[] ListEmployee() {
	Employee[] tempRepository = new Employee[location];
	for (int i=0;i<location;i++) {
		tempRepository[i] = employeeRepository[i];
	}
	return tempRepository;
}

/**
 * This will remove the Employee using unique ID
 * @param id
 */
public void RemoveEmployee(int id) {
	int i=0;
	while(i<location){
		if(employeeRepository[i].getId()==id){
			employeeRepository[i]=null;
			for(int j=i;j<location;j++) {
				employeeRepository[j]=employeeRepository[j+1];
			}
			location--;
		}
		i++;
	}
}
}