package tollbooth;

import java.util.Scanner;

public class TollBoothTest {

	public static void main(String[] args) {
		TollBooth tollbooth = new TollBooth();
		String conti = null;
	do{
		System.out.println("**********Welcome To Indore Highway***********");
		System.out.println("0. Exit");
		System.out.println("1. Paid Car");
		System.out.println("2. UnPaid Car");
		System.out.println("3. Paid Bus");
		System.out.println("4. Unpaid Bus");
		System.out.println("5. Paid Truck");
		System.out.println("6. Unpaid Truck");
		System.out.println("7. Total Cars and Cash");
		
		Scanner scan = new Scanner(System.in);
		int choice = scan.nextInt();
		
		switch(choice) {
		case 0:
			System.exit(0);
		
		case 1:{
			tollbooth.payingCar();
			System.out.println("Car Paid");
		}
		break;
		
		case 2:{
			tollbooth.noPayingCar();
			System.out.println("Unpaid Car");
		}
		break;
		
		case 3:{
			tollbooth.payingBus();
			System.out.println("Paid Bus");
		}
		break;
		
		case 4:{
			tollbooth.noPayingBus();
			System.out.println("Unpaid Bus");
		}
		break;
		
		case 5:{
			tollbooth.payingTruck();
			System.out.println("Paid Truck");
		}
		break;
		
		case 6:{
			tollbooth.noPayingTruck();
			System.out.println("Unpaid Truck");
		}
		break;
		
		case 7:{
			String display = tollbooth.display();
			System.out.println(display);
		}
		break;
		
		default:
		System.out.println("Invalid Input");
		}
		
		System.out.println("Continue ? (Y/N)");
		conti = scan.next();
	}while(conti.equalsIgnoreCase("Y"));
	}
}
