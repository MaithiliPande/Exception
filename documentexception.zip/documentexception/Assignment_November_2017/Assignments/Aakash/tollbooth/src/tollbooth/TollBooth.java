package tollbooth;
/**
 * Class which has the counting of passed vehicles and total cash collected
 * @author aakash.jangid
 *
 */
public class TollBooth {
	/**
	 * This is number of cars.
	 */
	int cars = 0;
	/**
	 * This is the cash.
	 */
	double cash = 0;
	/**
	 * This is the number of bus.
	 */
	int bus = 0;
	/**
	 * This is the number of truck.
	 */
	int truck = 0;
	
	public TollBooth() {
	}
	public int getCars() {
		return cars;
	}
	public double getCash() {
		return cash;
	}
	public int getBus() {
			return bus;
		}
	public int getTruck() {
			return truck;
		}
	
	/**
	 * This will increase the number of car when the car will pass through the toll
	 * Also it will add the cash as per the car toll.
	 */
	void payingCar(){
		cars++;
		cash=(cash+0.50);
	}
	
	/**
	 * This will increase the number of car when the car will pass through the toll
	 */
	void noPayingCar() {
		cars++;
	}
	
	/**
	 * This will increase the number of bus when the car will pass through the toll
	 * Also it will add the cash as per the bus toll.
	 */
	void payingBus(){
		bus++;
		cash=(cash+1.0);
	}
	
	/**
	 * This will increase the number of car when the car will pass through the toll
	 */
	void noPayingBus() {
		bus++;
	}
	
	/**
	 * This will increase the number of truck when the car will pass through the toll
	 * Also it will add the cash as per the truck toll.
	 */
	void payingTruck(){
		truck++;
		cash=(cash+1.50);
	}
	
	/**
	 * This will increase the number of car when the car will pass through the toll
	 */
	void noPayingTruck() {
		truck++;
	}
	
	/**
	 * This will return the total number of car, bus and truck passed and total cash.
	 * @return
	 */
	String display() {
		return "No of Cars Passed = "+this.cars+", No of Bus Passed = "+this.getBus()+", No of Trucks Passed = "+this.getTruck()+", Total Cash = "+this.cash;
	}
}
