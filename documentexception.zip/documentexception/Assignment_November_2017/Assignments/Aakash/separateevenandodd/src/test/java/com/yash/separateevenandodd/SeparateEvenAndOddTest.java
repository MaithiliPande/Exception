package com.yash.separateevenandodd;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class SeparateEvenAndOddTest {
	
	private static final String Given_Number = "123456asfd5";
	private SeparateEvenAndOdd separate;
	
	@Before
	public void setUp() throws Exception {
		separate = new SeparateEvenAndOdd();	
	}

	/*@Test
	public void Empty_Test() throws Exception{
	SeparateEvenAndOdd separate = new SeparateEvenAndOdd();
	int output = separate.result("");
	assertEquals(0,output);
}*/

	@Test
	public void Separate_Even_And_Odd_Numbers() throws Exception{
	
	String output = separate.result(Given_Number);
	assertEquals("3 even and 4 odd",output);
}
}
