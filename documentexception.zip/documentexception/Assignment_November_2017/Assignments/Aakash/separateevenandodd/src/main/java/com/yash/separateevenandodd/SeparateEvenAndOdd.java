package com.yash.separateevenandodd;

public class SeparateEvenAndOdd {

	public String result(String input) {
		
		char[] charArray =input.toCharArray();
		int i=0;
		int evencount = 0;
		int oddcount = 0;
		
		while(i<charArray.length) {
			
			if(Character.isDigit(charArray[i])) {
				if(charArray[i]%2==0) {
					evencount++;
				}
				else {
					oddcount++;
				}
				
			}
			i++;
		}
		return evencount+" even and "+oddcount+" odd";
		}
	}