package com.yash.fetchdatafromurl;

public class FetchDataFromUrl {

	public String requried(String str1) {

		if(str1=="") {
		return null;
	}
		else {
			int i = str1.lastIndexOf(".");
			int j = str1.lastIndexOf("/");
	//		System.out.println(i);
	//		System.out.println(j);
			String s= str1.substring(j+1, i);
			System.out.println(s);
			return s;
			}
		}
}
