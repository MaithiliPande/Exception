package com.yash.fetchdatafromurl;

import static org.junit.Assert.*;

import org.junit.Test;

public class FetchDataFromUrlTest {
	
	String str1 = "www.yash.com/admin/salary.com";

//	@Test
//	public void empty_test() {
//
//		FetchDataFromUrl data = new FetchDataFromUrl();
//		String result = data.requried(str1);
//		assertEquals(null, result);
//	}
	@Test
	public void test() {

		FetchDataFromUrl data = new FetchDataFromUrl();
		String result = data.requried(str1);
		assertEquals("salary", result);
	}

}
