package com.yash.fetchdatafromurl;

public @interface before {

}
