package com.yash.consecutivenumbers;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class AddConsecutiveNumbersTest {

	private static final String FirstNumber = "100000000";
	private AddConsecutiveNumbers consecutiveNumbers;
	
	@Before
	public void setUp() throws Exception {
		consecutiveNumbers = new AddConsecutiveNumbers();
	}
	
	/*@Test
	public void Add_Consecutive_Ten_Numbers() throws Exception{
		
		AddConsecutiveNumbers ConsecutiveNumbers = new AddConsecutiveNumbers();
		int result = ConsecutiveNumbers.addition(0);
		assertEquals(0,result);
	}*/
	
	@Test
	public void Add_Consecutive_Ten_Numbers_given() throws Exception{
		
		int result = consecutiveNumbers.addition(FirstNumber);
		assertEquals(1000000045,result);
	}
}
