package com.yash.consecutivenumbers;

public class AddConsecutiveNumbers {

	public int addition(String firstnumber) {
		
		if(firstnumber.length()!=0) {
			
			int temp = 0;
			try {
				
				int a=Integer.parseInt(firstnumber);
				int x = a+10;
				while (a<x) {
					temp=temp+a;
					a=a+1;
			}
		}
			catch(NumberFormatException nfe) {
				return 0;
			}
		return temp;
	}
		else {
			return 0;
		}}}

