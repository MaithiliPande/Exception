package com.yash.copyinreverseorder;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

/**
 * This test will check the Reverse order of the given array.
 * @author aakash.jangid
 *
 */
public class CopyInReverseOrderTest {
	CopyInReverseOrder reverseOrder;
	int[] toCheck=new int[] {3,2,1};
	
	@Before
	public void setUp() throws Exception{
		reverseOrder = new CopyInReverseOrder();
	}
	
	@Test
	public void test() {
		int[] reverse = reverseOrder.reverseOrder(reverseOrder.inputNumber());
		assertArrayEquals(toCheck, reverse);
	}
}
