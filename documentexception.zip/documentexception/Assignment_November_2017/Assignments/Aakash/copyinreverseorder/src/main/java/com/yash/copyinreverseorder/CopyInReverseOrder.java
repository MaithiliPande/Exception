package com.yash.copyinreverseorder;
import java.util.Scanner;

/**
 * This is the class where the methods are defined.
 * @author aakash.jangid
 *
 */
public class CopyInReverseOrder {

	/**
	 * This will return the input number array.
	 * @return
	 */
	public int[] inputNumber() {
		
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the size of your list - ");
		int size=scan.nextInt();
		System.out.println("Enter the Numbers - ");
		int[] number = new int[size];
		for(int i=0;i<number.length;i++) {
			number[i]=scan.nextInt();
			}
		return number;
	}
	
	/**
	 * This will copy the entered array in the reverse order.
	 * @param number
	 * @return
	 */
	public int[] reverseOrder(int[] number) {
			
		int[] reverse = new int[number.length];
		int i=0;
		for(int j=number.length-1;j>=0;j--) {
			reverse[i]=number[j];
			i++;
		}
		return reverse;
	}
}
