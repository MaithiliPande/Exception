import java.util.Scanner;
/**
 * This is the test class.
 * @author aakash.jangid
 *
 */
public class JoinDateTest {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
				System.out.println("Enter Day -");
				int day= scan.nextInt();
				System.out.println("Enter Month -");
				int month = scan.nextInt();
				System.out.println("Enter Year -");
				int year = scan.nextInt();
				
				JoinDate joindate = new JoinDate(day, month, year);
				System.out.println(joindate.display());
		
			}
}
