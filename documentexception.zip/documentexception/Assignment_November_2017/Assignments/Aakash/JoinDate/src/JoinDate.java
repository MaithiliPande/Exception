/**
 * This has the state of Date which is day of the month, month and year
 * @author aakash.jangid
 *
 */
public class JoinDate {
	/**
	 * This is the day of the month.
	 */
	private int day;
	/**
	 * This is the month.
	 */
	private int month;
	/**
	 * This is the year.
	 */
	private int year;
	
	public JoinDate() {
	}
	
	/**
	 * This method will check that whether the entered date is true as per standard or not.
	 * @param day
	 * @param month
	 * @param year
	 */
	public JoinDate(int day, int month, int year) {
	
		if(month>0 && month<13) {
			if(month==1||month==3||month==5||month==7||month==8||month==10||month==12) {
				if(day>0 && day<32) {
					this.day=day;
					this.month=month;
				}
					}
			else if(month==4||month==6||month==9||month==11){
				if(day>0 && day<31) {
					this.day=day;
					this.month=month;	
				}
			}
			else if(month==2){
				if(day>0 && day<29) {
					this.day=day;
					this.month=month;
				}
			}
		}
		else {
			System.out.println("Invalid Date");
			this.month=0;
		}
		
		if(year>00 && year<9999) {
		this.year=year;
		}
		else {
			System.out.println("Invalid Date");
			this.year=0;
	}
	}

	public int getDay() {
		return day;
	}
	public int getMonth() {
		return month;
	}
	public int getYear() {
		return year;
	}

	/**
	 * This will return the date enter by the user.
	 * @return
	 */
	public String display() {
		return this.month+" / "+this.day+" / "+this.year;
	}
}
