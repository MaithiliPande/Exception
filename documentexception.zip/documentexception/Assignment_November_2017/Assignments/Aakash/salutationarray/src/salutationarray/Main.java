package salutationarray;

import java.util.Scanner;
/**
 * This is the main class.
 * @author aakash.jangid
 *
 */
public class Main {

public static void main(String[] args) {

	String cont;
		do {
			System.out.println("**********Main Menu************");
			System.out.println("0. Exit");
			System.out.println("1. Add Person");
			System.out.println("2. Show Person List");

			System.out.println("Enter Choice");
			int choice;
			Scanner scan=new Scanner(System.in);
			choice = scan.nextInt();
				
			switch(choice) {
			case 0:
				System.exit(0);
					
			case 1:{
			System.out.println("Enter Name : ");
			String name= scan.next();
			System.out.println("Enter Gender (M/F)");
			String  gender = scan.next();
			System.out.println("Enter Marital Status (M/U)");
			String status= scan.next();
			
			String specifier = null;
			int temp = 0;
				
			if(gender.equalsIgnoreCase("M")) {
			temp = 0;
			SalutationWithName person = new SalutationWithName(name, gender, status, specifier, temp);
			SalutationSerivce.addPerson(person);
			}
			else if(gender.equalsIgnoreCase("F")) {
			if(status.equals("M")) {
			temp = 2;
			SalutationWithName person = new SalutationWithName(name, gender, status, specifier, temp);
			SalutationSerivce.addPerson(person);
			}  
			else {
			temp= 1;
			SalutationWithName person = new SalutationWithName(name, gender, status, specifier, temp);
			SalutationSerivce.addPerson(person);
			} 	} }	
			break;
					
			case 2:{
				SalutationWithName[] list = SalutationSerivce.listPersonAdded();
				for (int i = 0; i < list.length; i++) {
					System.out.println(list[i].toString());
				}
				}
			break;
			
			default:
				System.out.println("Invalid Input");
			}
				
			System.out.println("Enter Yes to Continue...");
			cont = scan.next();
			}while(cont.equalsIgnoreCase("Yes"));
		}	
}
