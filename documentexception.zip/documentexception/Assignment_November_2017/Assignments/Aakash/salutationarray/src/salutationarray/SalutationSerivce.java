package salutationarray;
/**
 * This is the service class which has all the methods defined
 * also the repository to store the information.
 * @author aakash.jangid
 *
 */
public class SalutationSerivce {
	/**
	 * This is the initial repository.
	 */
	static SalutationWithName[] salutationarray = new SalutationWithName[10];
	private static int location = 0;
	
	/**
	 * This is the method which will add the new object of the person with salutation.
	 * @param person
	 */
	public static void addPerson(SalutationWithName person) {
		if(location>=salutationarray.length) {
			SalutationWithName[] newarray = new SalutationWithName[2*salutationarray.length];
			newarray = expandArray(salutationarray);
			salutationarray = new SalutationWithName[newarray.length];
			
			for (int i = 0; i < newarray.length; i++) {
				salutationarray[i]=newarray[i];
			}
		}
			salutationarray[location++]=person;
		}
	
	/**
	 * This will return the repository with the double capacity of the initial repository.
	 * @param salutationarray2
	 * @return
	 */
	private static SalutationWithName[] expandArray(SalutationWithName[] salutationarray2) {
		SalutationWithName[] temp = new SalutationWithName[2*salutationarray2.length];
		for (int i = 0; i < temp.length; i++) {
			temp[i] = salutationarray2[i];			
		}
		return temp;
	}

	/**
	 * This will return the list of the person stored in the repository
	 * @return
	 */
	public static SalutationWithName[] listPersonAdded() {
		SalutationWithName[] temp = new SalutationWithName[location];
		for(int i=0; i<location;i++) {
			temp[i]=salutationarray[i];
		}
		return temp;
		
	}
}

	