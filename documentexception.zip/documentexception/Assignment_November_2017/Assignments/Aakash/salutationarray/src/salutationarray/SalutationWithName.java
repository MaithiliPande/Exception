package salutationarray;
/**
 * This is the model class which keeps the state and properties of the Program.
 * @author aakash.jangid
 *
 */
public class SalutationWithName {
	/**
	 * This is the name of the person.
	 */
	String name;
	/**
	 * This is the gender of the person
	 */
	String gender;
	/**
	 * This is the marital status of the person
	 */
	String maritalStatus;
	/**
	 * This is the specifier which will tell either Mr, Miss, Mrs.
	 */
	String specifier;
	
	String[] sal = {"Mr", "Miss", "Mrs"};
	
	public SalutationWithName(String name, String gender, String maritalStatus, String specifier, int temp) {
	this.name=name;
	this.gender=gender;
	this.maritalStatus=maritalStatus;
	this.specifier=sal[temp];
	}
	
	public String getName() {
		return name;
	}
	public String getGender() {
		return gender;
	}
	public String getMaritalStatus() {
		return maritalStatus;
	}
	
	public String toString() {
		return this.specifier+" "+this.name;
	}
}
