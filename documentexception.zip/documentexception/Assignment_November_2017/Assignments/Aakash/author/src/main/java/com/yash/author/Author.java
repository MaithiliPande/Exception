package com.yash.author;

import java.util.ArrayList;

class Book{
	
	String book_name;
	String book_type;
	double price;
	
	public String getBook_name() {
		return book_name;
	}
	public void setBook_name(String book_name) {
		this.book_name = book_name;
	}
	public String getBook_type() {
		return book_type;
	}
	public void setBook_type(String book_type) {
		this.book_type = book_type;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}

	
}
public class Author {

	static final ArrayList<Book> bookcount = new ArrayList<Book>();
	
	public String value(String name, String type, double price) {
		
		Book book = new Book();
		
		book.setBook_name(name);
		book.setBook_type(type);
		book.setPrice(price);
		
		bookcount.add(book);
		return "Book Added";
	}
	
	public String getbook(String name) {
		
		for(Book b1:bookcount) {
			if(b1.book_name.equals(name)) {
				return "Book : "+b1.getBook_name()+" Type : "+b1.getBook_type()+" Price : "+b1.getPrice();
			}
		}
		return null;
	}
	

	public int count() {
		return bookcount.size();
	}
	}
