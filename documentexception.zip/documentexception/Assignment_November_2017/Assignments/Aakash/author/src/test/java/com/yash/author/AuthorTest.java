package com.yash.author;

import static org.junit.Assert.*;

import org.junit.Test;

public class AuthorTest {

//	@Test
//	public void test() {
//		Author author = new Author();
//		String result = author.value();
//		assertEquals(null, result);
//		
//	}

	@Test
	public void test() {
		Author author = new Author();
		System.out.println("0");
		String result1 = author.value("The Sunflower Forest", "Novel", 250.0);
		String result2 = author.value("Head First", "Programming", 2500.0);
		String result3 = author.value("The Last Airbender", "Fiction", 99.0);
		assertEquals("Book Added", result1);
		assertEquals("Book Added", result2);
		assertEquals("Book Added", result3);
		int result = author.count();
		assertEquals(3, result);
		String search = author.getbook("Head First");
		assertEquals("Book : Head First Type : Programming Price : 2500.0", search);
		
	}
//	@Test
//	public void count_test() {
//		Author author = new Author();
//		String result = author.getbook("The Sunflower Forest");
//		assertEquals("Book : ", result);
//		
//	}
}
