package com.yash.reversestring;

/**
 * This is the class where all methods to reverse the string are defined
 * @author aakash.jangid
 *
 */
public class ReverseString {

	/**
	 * This will return the reverse String
	 * If the string is empty/null it will return empty/null
	 * @param string
	 * @return
	 */
	public String reverseIt(String string) {
		
		if(string==null) {
			return null;
		}
		else{char[] input = string.toCharArray();
		char[] output= new char[input.length];
		int j = input.length-1;
		System.out.println(j);
		for(int i=0;i<input.length;i++) {
			output[i]= input[j];
			output[j]=input[i];
			j--;
		}
		return String.valueOf(output);
	}
	}
}
