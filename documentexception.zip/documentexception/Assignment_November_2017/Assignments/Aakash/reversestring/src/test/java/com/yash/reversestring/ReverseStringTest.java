package com.yash.reversestring;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * This will test the program to reverse the given string
 * @author aakash.jangid
 *
 */
public class ReverseStringTest {

	@Test
	public void empty_test() {
		ReverseString reverseString = new ReverseString();
		String actual = reverseString.reverseIt("");
		assertEquals("", actual);
	}
	
	@Test
	public void String_test() {
		ReverseString reverseString = new ReverseString();
		String actual = reverseString.reverseIt("Able was I era I saw elba");
		assertEquals("able was I are I saw elbA", actual);
	}
	
}
