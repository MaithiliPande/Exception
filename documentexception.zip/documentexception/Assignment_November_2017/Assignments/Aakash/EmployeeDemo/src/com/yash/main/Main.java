package com.yash.main;

import java.util.Scanner;

import com.yash.employeedemo.Employee;

/**
 * This is the main class where the methods are described.
 * Here we also ask the user to enter the information about employee.
 * @author aakash.jangid
 *
 */
public class Main {
		static int location = 0;
		
		/**
		 * This is the employee array where we will store the info of employees.
		 */
		static Employee[] employee = new Employee[10];
		
	public static void main(String[] args) {
			
		Scanner scan = new Scanner(System.in);
		String cont;
		do {
			int choice=0;
			
			System.out.println(" YASH TECHNOLOGIES ");
			System.out.println("0. Exit ");
			System.out.println("1. Add Employee Information ");
			System.out.println("2. Show Employee ");
			
			choice = scan.nextInt();
			
			switch(choice) {
			case 0:{
				System.exit(0);
			}
			
			case 1:{
		System.out.println("Enter the Employee Id - ");
		int id = scan.nextInt();
		System.out.println("Enter the Employee Name - ");
		String name = scan.next();
		
		Employee employeeinfo = new Employee(id, name);
		employee[location++]=employeeinfo;
		System.out.println("Employee Information added successfully");
			}
			break;
			
			case 2:{
				System.out.println("Enter Employee ID - ");
				int id = scan.nextInt();
				showEmployees(id);
			}
			break;
			
			default:
				System.out.println("Invalid Input");	
	}
			System.out.println(" ");
			System.out.println("Continue ? (Yes/No)");
			cont=scan.next();
		}while(cont.equalsIgnoreCase("Yes"));
	}

	/**
	 * This is the method through which we will get the info of employee by providing the id of employee.
	 * @param id
	 */
	private static void showEmployees(int id) {
		for(int i=0;i<location;i++) {
			if(employee[i].getId()==id) {
				System.out.println(employee[i].toString());
			}
		}
	}
	}

