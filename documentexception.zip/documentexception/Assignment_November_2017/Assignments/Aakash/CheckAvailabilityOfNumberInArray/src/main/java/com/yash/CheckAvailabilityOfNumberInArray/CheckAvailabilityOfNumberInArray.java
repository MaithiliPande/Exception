package com.yash.CheckAvailabilityOfNumberInArray;

import java.util.Scanner;
/**
 * This is the main class in which all the methods are define.
 * @author aakash.jangid
 *
 */
public class CheckAvailabilityOfNumberInArray {
	
	/**
	 * This method will return the count of the occurence of the number in that array.
	 * @return
	 */
	public int availability(int[] arr, int input) {
		
		int count=0;
		for(int i=0;i<arr.length;i++) {
			if(arr[i]==input) {
				count++;
			}
		}
		return count;
	}
	
	/**
	 * This method will return the numbers which the user will enter via Keyboard.
	 * @return
	 */
	public int[] numbers() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the Ten Numbers - ");
		int[] number = new int[10];
		for(int i=0;i<number.length;i++) {
			number[i]=scan.nextInt();
			}
		System.out.println("Enter the number to be Searched in List : ");
		return number;
		
	}
}
