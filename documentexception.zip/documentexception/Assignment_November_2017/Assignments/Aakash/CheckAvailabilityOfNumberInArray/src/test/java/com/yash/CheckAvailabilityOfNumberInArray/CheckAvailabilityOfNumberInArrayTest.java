package com.yash.CheckAvailabilityOfNumberInArray;
import static org.junit.Assert.*;

import java.util.Scanner;

import org.junit.Before;
import org.junit.Test;
/**
 * This is Test Class which will check that the given program is working correctly or not.
 * @author aakash.jangid
 *
 */
public class CheckAvailabilityOfNumberInArrayTest {
	
	CheckAvailabilityOfNumberInArray checkAvailability;
	Scanner sc=new Scanner(System.in);
	
	@Before
	public void setUp() throws Exception {
		checkAvailability = new CheckAvailabilityOfNumberInArray();
	}
	
	@Test
	public void Numbers_In_Array_test_() {
		int actual = checkAvailability.availability(checkAvailability.numbers(),sc.nextInt());
		assertEquals(2, actual);
	}
}
