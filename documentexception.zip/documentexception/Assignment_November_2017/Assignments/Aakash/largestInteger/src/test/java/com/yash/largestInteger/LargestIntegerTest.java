package com.yash.largestInteger;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * This is the test class to test the largest number and its index.
 * @author aakash.jangid
 *
 */
public class LargestIntegerTest {

	@Test
	public void largest_no_test() {
		LargestInteger largest = new LargestInteger();
		int[] numbers = largest.numbers();
		String actual = largest.maxInt(numbers);
		assertEquals("Largest Number - 5, Index - 1", actual);
	}
}
