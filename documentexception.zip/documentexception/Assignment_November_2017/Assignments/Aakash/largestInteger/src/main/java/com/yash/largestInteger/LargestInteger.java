package com.yash.largestInteger;

import java.util.Scanner;

/**
 * This class has the methods to find the Largest Number and its index
 * @author aakash.jangid
 *
 */
public class LargestInteger {
	
	/**
	 * This will return the largest number and its index
	 * @param input
	 * @return
	 */
	public String maxInt(int[] input) {
		int temp=0; 
		int index=0;
		for(int i=0;i<input.length;i++) {
			if(input[i]>temp) {
				temp=input[i];
				index=i;
			}
		}
		return "Largest Number - "+temp+", Index - "+index;
	}

	/**
	 * This will return the array of numbers from user
	 * @return
	 */
	public int[] numbers() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the number of number you want to enter - ");
		int length = scan.nextInt();
		int[] numbers = new int[length];
		System.out.println("Enter the numbers - ");
		for(int i=0;i<length;i++) {
			numbers[i]=scan.nextInt();
		}
		return numbers;
	}
}
