package com.yash.numberpresentinarray;

public class ArrayNumbers {
	int []array={78,45,89,24,45,123,562,321,789,852};
	public int presence(int num) {
		int times=0;
		for (int i = 0; i < array.length; i++) {
			if(num==array[i])
				times++;
		}
		
		return times;
	}

}
