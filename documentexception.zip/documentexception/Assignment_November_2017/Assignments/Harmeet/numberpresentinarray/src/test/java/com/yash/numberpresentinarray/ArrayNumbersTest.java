package com.yash.numberpresentinarray;

import org.junit.Before;
import org.junit.Test;

import junit.framework.TestCase;

public class ArrayNumbersTest extends TestCase {
	private ArrayNumbers arrayNumbers;
	private final int NUM=45;
	
	@Before
	public void setUp() throws Exception{
		arrayNumbers=new ArrayNumbers();
	}
	
	@Test
	public void test_for_presence_of_number_in_array(){
		int result=arrayNumbers.presence(NUM);
		assertEquals(result,2);
	}
}
