package com.yash.factorial;

import org.junit.Before;
import org.junit.Test;

import junit.framework.TestCase;

public class FactorialOfNumberTest extends TestCase {
	
	private FactorialOfNumber fon;
	
	@Before
	public void setUp(){
		fon=new FactorialOfNumber();
	}
	
//	@Test
//	public void test_empty(){
//		long result=fon.evaluateFactorial("");
//		assertEquals(0,result);
//	}
//	
//	@Test
//	public void test_for_number_0(){
//		long result=fon.evaluateFactorial("0");
//		assertEquals(1,result);
//	}
//	
//	@Test
//	public void test_for_number_1(){
//		long result=fon.evaluateFactorial("1");
//		assertEquals(1,result);
//	}
//	
//	@Test
//	public void test_for_number_2(){
//		long result=fon.evaluateFactorial("2");
//		assertEquals(2,result);
//	}
	
	@Test
	public void test_for_any_number(){
		Long result=fon.evaluateFactorial(21);
		System.out.println(result);
		assertEquals(null,result);
	}

}
