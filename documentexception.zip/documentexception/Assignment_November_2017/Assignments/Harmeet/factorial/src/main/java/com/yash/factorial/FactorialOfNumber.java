package com.yash.factorial;

public class FactorialOfNumber {

	public Long evaluateFactorial(int input) {
		if(Integer.valueOf(input)==null || input<0 || input>20){
			return null;
		}
		else{
			
			if(input==0 || input==1){
				return 1L;
			}
			else if(input>1){
				long ans=1;;
				for(int i=input;i>=1;i--){
					ans=ans*i;
				}
				return ans;
			}
			else{
				return 0L;
			}
		}
	}

}
