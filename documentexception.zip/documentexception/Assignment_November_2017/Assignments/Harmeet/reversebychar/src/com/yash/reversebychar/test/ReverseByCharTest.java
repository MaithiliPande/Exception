package com.yash.reversebychar.test;

import com.yash.reversebychar.service.ReverseByChar;
/**
 * ReverseByCharTest is used to test the methods of ReverseByChar
 * @author harmeet.saluja
 *
 */
public class ReverseByCharTest {
	
	public static void main(String[] args) {
		String string="Able was I era I saw elba"; 
		System.out.println("Entered string:"+string);

		ReverseByChar reverseByChar= new ReverseByChar();
		String reversed=reverseByChar.reverseelt(string);
		System.out.println("Reversed string:"+reversed);

	}
}
