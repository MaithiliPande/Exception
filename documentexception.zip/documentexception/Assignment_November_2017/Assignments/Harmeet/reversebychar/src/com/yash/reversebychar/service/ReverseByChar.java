package com.yash.reversebychar.service;
/**
 * ReverseByChar is used to reverse the characters in string
 * @author harmeet.saluja
 *
 */
public class ReverseByChar {
	/**
	 * reverseelt function takes string input as parameter and returns the reversed string
	 * @param string
	 * @return
	 */
	public String reverseelt(String string){
		char []stringChar=string.toCharArray();
		char []revChar=new char[string.length()];
		if(string.length()%2==0){
			for (int i = 0,j = (string.length()-1); i < (string.length()/2); i++) {
				revChar[i]=stringChar[j];
				revChar[j]=stringChar[i];
				j--;
			}
		}
		else{
			revChar[(string.length()/2)+1]=stringChar[(string.length()/2)+1];
			for (int i = 0,j = (string.length()-1); i < (string.length()/2+1); i++) {
				revChar[i]=stringChar[j];
				revChar[j]=stringChar[i];
				j--;
			}
		}
		return String.valueOf(revChar);
	}
}