package com.yash.transposeofmatrix.service;

/**
 * 
 * @author harmeet.saluja
 *Transpose is used to perform the transpose operations
 */
public class Transpose {
	/**
	 * showMatrix is used to display the matrix
	 * @param array
	 */
	public void showMatrix(int[][] array) {
		for (int i = 0; i < array.length; i++) {
			for (int j = 0; j < array[i].length; j++) {
				System.out.print(array[i][j]+" ");
			}
			System.out.println();
		}
	}

	/**
	 * 
	 * @param array
	 * @return
	 * transposeMatrix is used to to calculate the transpose of matrix
	 */
	public int[][] transposeMatrix(int[][] array) {
		int [][]temp= new int[array.length][array[0].length];
		for (int i = 0; i < array.length; i++) {
			for (int j = 0; j < array[i].length; j++) {
				temp[j][i]=array[i][j];
			}
		}
		return temp;
	}

}
