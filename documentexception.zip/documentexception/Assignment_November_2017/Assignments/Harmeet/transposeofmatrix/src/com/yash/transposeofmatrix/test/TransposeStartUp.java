package com.yash.transposeofmatrix.test;

import java.util.Scanner;

import com.yash.transposeofmatrix.service.Transpose;
/**
 * TransposeStartUp is used to start the transpose operation
 * @author harmeet.saluja
 *
 */
public class TransposeStartUp {
	
	public static void main(String[] args) {
		/**
		 * array is used to store 4x4 matrix
		 */
		int [][]array=new int[4][4];
		Transpose transposeTest=new Transpose();
		
		System.out.println("enter elements in 4x4 matrix");
		Scanner scan=new Scanner(System.in);
		
		for (int i = 0; i < array.length; i++) {
			for (int j = 0; j < array[i].length; j++) {
				array[i][j]=scan.nextInt();
			}
		}
		
		transposeTest.showMatrix(array);
		
		int [][]transpose=transposeTest.transposeMatrix(array);
		System.out.println("Transpose of given matrix is");
		transposeTest.showMatrix(transpose);
		
	}
}
