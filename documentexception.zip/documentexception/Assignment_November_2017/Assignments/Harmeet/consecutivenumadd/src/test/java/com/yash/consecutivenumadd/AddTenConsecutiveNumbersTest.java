package com.yash.consecutivenumadd;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class AddTenConsecutiveNumbersTest {

	private static final Integer NUM_BEGIN=1;
	private AddTenConsecutiveNumbers atcn;
	@Before
	public void setUp() throws Exception{
		atcn=new AddTenConsecutiveNumbers();
	}
	
	
//	@Test
//	public void test_empty(){
//		atcn=new AddTenConsecutiveNumbers();
//		Integer result=atcn.sum_of_ten_consecutive_numbers(null);
//		assertEquals(null,result);
//	}
	
	@Test
	public void test_for_any_digit_number(){
		atcn=new AddTenConsecutiveNumbers();
		Integer result=atcn.sum_of_ten_consecutive_numbers(NUM_BEGIN);
		assertEquals(new Integer(55),result);
	}

}
