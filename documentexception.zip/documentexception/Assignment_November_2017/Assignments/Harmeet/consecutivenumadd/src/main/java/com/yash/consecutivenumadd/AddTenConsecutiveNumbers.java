package com.yash.consecutivenumadd;

public class AddTenConsecutiveNumbers {

	public Integer sum_of_ten_consecutive_numbers(Integer input) {
		if(input==null){
			return null;
		}
		
		else{
			if(input>(-2147483648) || input<21474836){
				int ans;
				ans=input;
				for(int i=1;i<10;i++){
					input+=1;
					ans=ans+input;
				}
			return ans;
			}
			else
				return null;
		}
	}
}

	
