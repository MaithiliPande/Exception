package com.yash.numberdivisiblebyseven;

import static org.junit.Assert.*;

import org.junit.Test;

public class DivisibilityBySevenTest {
	
	private DivisibilityBySeven dbs;
	
	

	@Test
	public void test_empty() {
		dbs=new DivisibilityBySeven();
		int result=dbs.getSum();
		assertEquals(2107,result);
		
	}

}
