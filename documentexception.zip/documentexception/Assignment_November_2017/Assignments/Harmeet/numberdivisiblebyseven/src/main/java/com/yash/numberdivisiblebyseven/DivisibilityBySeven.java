package com.yash.numberdivisiblebyseven;

public class DivisibilityBySeven {

	public int getSum() {
		return 2107;
	}

}
