package com.yash.evenodd;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class EvenOddNumberTest {
	private EvenOddNumber eon;
	
	@Before
	public void setUp(){
		eon=new EvenOddNumber();
	}
	
//	@Test
//	public void test_empty(){
//		int[] result=new int[2];
//		result=eon.calculate_even_odd("");
//		assertEquals(0,result[0]);
//		assertEquals(0,result[1]);
//	}
//	
//	@Test
//	public void test_single_digit_num(){
//		int[] result=new int[2];
//		result=eon.calculate_even_odd("6");
//		assertEquals(1,result[0]);
//		assertEquals(0,result[1]);
//	}
//	
//	@Test
//	public void test_double_digit_num(){
//		int[] result=new int[2];
//		result=eon.calculate_even_odd("24");
//		assertEquals(2,result[0]);
//		assertEquals(0,result[1]);
//	}
//	
	@Test
	public void test_any_num(){
		int[] result=new int[2];
		result=eon.calculate_even_odd(21112111);
		System.out.println("Even numbers:"+result[0]);
		System.out.println("Odd numbers:"+result[1]);
		assertEquals(2,result[0]);
		assertEquals(6,result[1]);
	}
}
