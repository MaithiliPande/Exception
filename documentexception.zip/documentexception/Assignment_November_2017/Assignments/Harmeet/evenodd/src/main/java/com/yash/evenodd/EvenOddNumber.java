package com.yash.evenodd;

public class EvenOddNumber {

	public int[] calculate_even_odd(Integer i) {
			int[] evenodd=new int[2];
			
			if(i==0)
				evenodd[0]++;
			else{
				while(i>0 || i<0){
					int r=i%10;
					i=i/10;
					if(r%2==0)
						evenodd[0]++;
					else
						evenodd[1]++;
				}
			}
			return evenodd;
		}

}
