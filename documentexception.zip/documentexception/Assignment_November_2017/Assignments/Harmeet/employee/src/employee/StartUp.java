package employee;
import java.util.Scanner;
/**
 * @author harmeet.saluja
 *
 */
public class StartUp {
	public static void main(String[] args) {
		EmployeeService employeeService=new EmployeeService();
		String cont;
		
		do{
			System.out.println("*****MAIN MENU*****");
			System.out.println("*****0. EXIT*****");
			System.out.println("*****1.ADD EMPLOYEE*****");
			System.out.println("*****2.SHOW EMPLOYEE*****");
			
			System.out.println("Enter Choice:");
			int choice;
			
			Scanner scan=new Scanner(System.in);
			choice=scan.nextInt();
			
			switch(choice){
			case 0:
				System.exit(0);
				
			case 1:{
				System.out.println("Enter id:");
				int id=scan.nextInt();
				
				System.out.println("Enter name:");
				String name=scan.next();
					
				System.out.println("Enter salary:");
				int salary=scan.nextInt();
				
				Employee emp=new Employee(id,salary,name);
				employeeService.addEmployee(emp);
			}
			break;
			case 2:{
				Employee []employee=employeeService.listEmployees();
				for(int i=0;i<employee.length;i++)
					System.out.println(employee[i]);
			}
			break;
			
			default:System.out.println("Invalid");
			}
			
			System.out.println("enter yes to continue....");
			cont=scan.next();
		}while(cont.equalsIgnoreCase("yes"));
		
	}
}
