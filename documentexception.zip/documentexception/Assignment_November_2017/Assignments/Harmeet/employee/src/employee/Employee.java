package employee;

/**
 * @author harmeet.saluja
 * Employee is used to create the object of type employee
 */


public class Employee {
	
	//id is used for employee id
	private int id;	
	
	//salary represents salary of an employee
	private int salary;
	
	//name represents name of an employee
	private String name;
		
	
	
	public Employee(int id, int salary, String name) {
		this.id = id;
		this.salary = salary;
		this.name = name;
	}


	
	/**
	 * @return 
	 * returns employee id
	 */
	public int getId() {
		return id;
	}
	
	/**
	 * @param id
	 * used to set employee id
	 */
	public void setId(int id) {
		this.id = id;
	}
	
	
	/**
	 * @return
	 * returns employee salary
	 */
	public int getSalary() {
		return salary;
	}
	
	
	/**
	 * @param salary
	 * used to set employee salary
	 */
	public void setSalary(int salary) {
		this.salary = salary;
	}
	
	
	/**
	 * @return
	 * returns employee name
	 */
	public String getName() {
		return name;
	}
	
	
	/**
	 * @param name
	 * used to set employee name
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	@Override
	public String toString() {
	return this.id+" "+this.name+" "+this.salary;	
	}
	
	
}
