package employee;

/**
 * @author harmeet.saluja
 *EmployeeService is used to provide services to an employee 
 */

public class EmployeeService {
	
	
	/**
	 * employeeRepository is a repository for storing employee values
	 */
	private Employee []employeeRepository=new Employee[10];
	private int location=0;
	
	
	
	/**
	 * @param employee
	 * the methods adds an employee to the employee repository
	 */
	public void addEmployee(Employee employee){
		employeeRepository[location++]=employee;
	}
	
	
	/**
	 * @return
	 * the method is used to return the array of the employees in the repository
	 */
	public Employee[] listEmployees(){
		Employee []temp=new Employee[location];
		for(int i=0;i<location;i++){
			temp[i]=employeeRepository[i];
		}
		
		return temp;
	}
}
