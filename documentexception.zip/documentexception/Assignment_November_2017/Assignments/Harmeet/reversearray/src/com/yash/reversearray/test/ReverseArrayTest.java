package com.yash.reversearray.test;
import com.yash.reversearray.service.ReverseArray;
/**
 * ReverseArrayTest is used to reverse the given array
 * @author harmeet.saluja
 *
 */
public class ReverseArrayTest {

	public static void main(String[] args) {
		
		int array[]={34,67,45,89,43,97,754,2356,451,32};
		ReverseArray reverseArrayTest=new ReverseArray();
		
		
		int []reversed=reverseArrayTest.reverse(array);
		
		for (int i : reversed) {
			System.out.print(i+" ");
		}
	}

}