package com.yash.reversearray.service;

/**
 * ReverseArray is service class for ReverseArray
 * @author harmeet.saluja
 *
 */
public class ReverseArray {
	/**
	 * reverse() method takes array as input and reverses the array
	 * @param array
	 * @return
	 */
	public int[] reverse(int[] array) {
		int temp[]=new int[array.length];
		for(int i=0,j=(array.length-1);i<array.length;i++){
			temp[j]=array[i];
			j--;
		}
		return temp;
	}

}

