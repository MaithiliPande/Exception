package com.yash.evaluateurl;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class EvaluateActionTest {

	
	private EvaluateAction ea;
	
	@Before
	public void setUp(){
		ea=new EvaluateAction();
	}
	
	@Test
	public void test_empty() {
		String url=ea.takeAction("");
		assertEquals(null,url);
	}
	
	@Test
	public void test_url() {
		String url=ea.takeAction("www.yash.com/admin/list");
		assertEquals("list",url);
	}
	
	

}
