package com.yash.evaluateurl;

public class EvaluateAction {

	public String takeAction(String input) {
		if(input==""){
			return null;
		}
		else{
			String control;
			int lios=input.lastIndexOf("/");
			
			String temp_control=input.substring(lios);
			
			if(temp_control.lastIndexOf(".")==-1){
				control=temp_control.substring(1);
			}
			else{
				int liod=temp_control.lastIndexOf(".");
				control=temp_control.substring(1, liod);
			}
			
			return control;
		}
		
	}

}
