package com.yash.sumofdigits;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class ExpressionTest {

	Expression e;
	
	@Before
	public void setUp() throws Exception{
		e=new Expression();
	}
	
//	@Test
//	public void test_empty() throws Exception{
//		int result=e.getSum("");
//		assertEquals(0,result);
//	}
//	
//	@Test
//	public void test_single_plus() throws Exception{
//		int result=e.getSum("2+2");
//		assertEquals(4,result);
//	}
//	
	@Test
	public void test_expression() throws Exception{
		int result=e.getSum("");
		assertEquals(-1,result);
	}

}
