package com.yash.sumofdigits;

import java.util.Arrays;

public class Expression {

	public int getSum(String input) {
		if(input.isEmpty() || input.charAt(0)=='+' || input.charAt(input.length()-1)=='+')
			return -1;
		
		else{
			int j;
			
	        for(j=0;j<input.length();j++)
	        {
	            if(input.charAt(j)=='+' && input.charAt(j+1)=='+')
	            {
	                return -1;
	            }
		        
	        }
	    	return Arrays.stream(input.split("\\+")).mapToInt(Integer::parseInt).sum();
		}
	}

}
