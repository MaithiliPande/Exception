package controller;

public class HomeController implements Controller {
	
	public Controller getController(String name){
		Controller hc=new HomeController();
		return hc;
	}
	
	public void activate(){
		System.out.println("Home Controller Activated");
	}

}
