package controller;

public class AdminController implements Controller{
	
	public Controller getController(String name){
		AdminController ac=new AdminController();
		return ac;
	}
	
	public void activate(){
		System.out.println("Admin Controller Activated");
	}

}
