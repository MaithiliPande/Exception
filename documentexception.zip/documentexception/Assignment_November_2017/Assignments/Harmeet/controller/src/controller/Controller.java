package controller;

public interface Controller {
	
	public Controller getController(String name);
	public void activate();
	
	public static Controller callController(String contname){
	
		Controller c;
		
		if(contname.equals("salary")){
			c=new SalaryController().getController(contname);
			return c;
		}
		else if(contname.equals("index")){
			c=new HomeController().getController(contname);
			return c;
		}
		else if(contname.equals("list")){
			c=new AdminController().getController(contname);
			return c;
		}
		else
			return null;	
		
	}

}
