package controller;

public class FrontController {
	public static void main(String args[]){
		
		String url="www.yash.com/salary.co/index/list";
		String control;
		int lios=url.lastIndexOf("/");
		
		String temp_control=url.substring(lios);
		
		if(temp_control.lastIndexOf(".")==-1){
			control=temp_control.substring(1);
		}
		else{
			int liod=temp_control.lastIndexOf(".");
			control=temp_control.substring(1, liod);
		}
		
		Controller c=Controller.callController(control);
		c.activate();
		
		
		
	}
}
