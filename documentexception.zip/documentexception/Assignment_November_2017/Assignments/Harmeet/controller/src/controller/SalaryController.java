package controller;

public class SalaryController implements Controller{

	public Controller getController(String name){
		SalaryController sc=new SalaryController();
		return sc;
	}
	
	public void activate(){
		System.out.println("Salary Controller Activated");
	}
	
}
