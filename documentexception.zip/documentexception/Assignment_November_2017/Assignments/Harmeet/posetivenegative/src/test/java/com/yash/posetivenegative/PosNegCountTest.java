package com.yash.posetivenegative;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class PosNegCountTest {
	PosNegCount posNegCount;
	
	@Before
	public void setUp() throws Exception{
		posNegCount= new PosNegCount();
	}
	
	@Test
	public void test() {
		int []result=new int[2];
		result=posNegCount.getEvenOdd();
		assertEquals(result[0],8);
		assertEquals(result[1],7);
	}

}
