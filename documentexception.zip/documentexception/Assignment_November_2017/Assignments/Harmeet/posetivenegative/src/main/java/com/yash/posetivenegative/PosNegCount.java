package com.yash.posetivenegative;

public class PosNegCount {
	int []array={45,78,36,20,100,225,89,357,951,852,-456,742,258,963,365};
	public int[] getEvenOdd() {
		int []eveodd=new int[2];
//		eveodd[0]=7;
//		eveodd[1]=8;
		for (int i = 0; i < array.length; i++) {
			if(array[i]%2==0)
				eveodd[0]++;
			else
				eveodd[1]++;
		}
		
		return eveodd;
	}

}
