package com.yash.largestnumindex.test;
import java.util.Scanner;

import com.yash.largestnumindex.service.LargestNumber;
/**
 * LargestNumberTest is a test class for LargestNumber class
 * @author harmeet.saluja
 *
 */
public class LargestNumberTest {
	public static void main(String[] args) {
		int []num=new int[10];
		LargestNumber largestNumber=new LargestNumber();
		System.out.println("Enter 10 numbers in array");
		Scanner scan=new Scanner(System.in);
		
		for(int i=0;i<num.length;i++){
			num[i]=scan.nextInt();
		}
		
		/**
		 * index represents the index of the largest number in the array
		 */
		int index=largestNumber.getIndexOfLargestNum(num,num.length);
		System.out.println("Index of largest number:"+(index+1)+" & value at that index is:"+num[index]);
	}
}
