package com.yash.largestnumindex.service;
/**
 * LargestNumber is used to find the index number of the largest number in the array
 * @author harmeet.saluja
 *
 */
public class LargestNumber {
	/**
	 * getIndexOfLargestNum takes an integer array as input and returns the index of the largest number
	 * @param num
	 * @param length
	 * @return
	 */
	public int getIndexOfLargestNum(int[] num, int length) {
		int max=num[0];
		int index=0;
		for (int i = 0; i < length; i++) {
			for (int j = i+1; j < length; j++) {
				if(num[j]>num[i]){
					if(num[j]>max){
						max=num[j];
						index=j;		
					}
				}
			}
		}
		return index;
	}

}
