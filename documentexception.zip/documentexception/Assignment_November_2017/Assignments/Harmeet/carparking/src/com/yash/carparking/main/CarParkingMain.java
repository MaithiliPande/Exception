package com.yash.carparking.main;

import java.util.Scanner;

import com.yash.carparking.model.Car;
import com.yash.carparking.service.CarParkingService;
/**
 * CarParkingMain is used to start the parking process of the car
 * @author harmeet.saluja
 *
 */
public class CarParkingMain {
	public static void main(String[] args) {
		CarParkingService carParkingService=new CarParkingService();
		Car car;
		
		/**
		 * cont is used to ask user if he wants to continue
		 */
		String cont;
		Scanner scan=new Scanner(System.in);
		
		/**
		 * choice is used to ask the choice of the user
		 */
		int choice;
		do{
			System.out.println("*****1.Park Car*****");
			System.out.println("*****2.Show parking Area*****");
			System.out.println("*****3.Take Out Car*****");
			System.out.println("*****4.Show parked car floorwise*****");
			System.out.println("*****5.Exit*****");
			System.out.println("Enter choice");
			choice=Integer.parseInt(scan.next());
			switch(choice){
			case 1:{
				System.out.println("Enter name of owner:");
				scan.nextLine();
				String name=scan.nextLine();
				System.out.println("Enter registration number of car:");
				int regNo=scan.nextInt();
				car=new Car(regNo,name);
				carParkingService.parkCar(car);
			}
			break;
			case 2:{
				carParkingService.displayParking();
			}
			break;
			case 3:{
				System.out.println("Enter token number of car:");
				int token=scan.nextInt();
				carParkingService.takeOutCar(token);
			} 
			break;
			case 4:{
				carParkingService.displayParkingOnEachFloor();
			}
			break;
			case 5:{
				System.exit(0);
			}
			break;
			default:System.out.println("Invalid choice..");
			}
			System.out.println("Continue..?");
			cont=scan.next();
		}while(cont.equalsIgnoreCase("y"));
	}
	
}
