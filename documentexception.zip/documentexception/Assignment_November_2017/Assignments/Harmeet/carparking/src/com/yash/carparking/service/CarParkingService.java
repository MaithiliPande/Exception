package com.yash.carparking.service;

import com.yash.carparking.model.Car;
/**
 * CarParkingService provides services for the Car
 * @author harmeet.saluja
 *
 */
public class CarParkingService {
	/**
	 * car[][] is repository for cars at different floor levels
	 */
	Car [][]car=new Car[5][];{
	car[0]=new Car[5];
	car[1]=new Car[4];
	car[2]=new Car[3];
	car[3]=new Car[2];
	car[4]=new Car[1];
	}
	
	/**
	 * maxparking represents the maximum number of cars that can be parked at the parking area
	 */
	private final int maxparking=15;
	/**
	 * parkcount represents total number of cars parked
	 */
	private int parkcount=0;
	/**
	 * parkOnEachFloor reprents the car parked at each floor
	 */
	private int []parkOnEachFloor=new int[5];
	
	/**
	 * parkCar() method takes a Car object as input and parks the car
	 * @param c
	 */
	public void parkCar(Car c){
		if(parkcount==maxparking)
			System.out.println("Parking area full");
		else{
			park:for (int i = 0; i < car.length; i++) {
				for (int j = 0; j < car[i].length; j++) {
					if(car[i][j]==null){
						car[i][j]=c;
						car[i][j].getTokenNo(i,j);
						System.out.println("Car Parked at floor:"+i+" and token:"+car[i][j].getTokenNo(i,j));
						parkcount++;
						parkOnEachFloor[i]++;
						break park;
					}
				}
			}
		}
		System.out.println("Total available parking space:"+(maxparking-parkcount));
	}
	
	/**
	 * displayParking is used to view all the cars parked in parking area 
	 */
	public void displayParking(){
		for (int i = 0; i < car.length; i++) {
			for (int j = 0; j < car[i].length; j++) {
				if(car[i][j]!=null)
					System.out.print(car[i][j]+"  ");
				else
					System.out.print("");
			}
			System.out.println();
		}
	}
	
	/**
	 * displayParkingOnEachFloor() is used to view the numbers of cars parked on each floor
	 */
	public void displayParkingOnEachFloor(){
		for (int i = 0; i < car.length; i++) {
			System.out.println("Available parking on "+i+" floor:"+(car[i].length-parkOnEachFloor[i])+" and number of cars parked on floor:"+parkOnEachFloor[i]);
		}
	}
	
	/**
	 * takeOutCar takes the car token as input and removes the car from the parking area
	 * @param token
	 */
	public void takeOutCar(int token){
		if(parkcount==0){
			System.out.println("Parking area is empty");
		}
		else{
			for (int i = 0; i < car.length; i++) {
				for (int j = 0; j < car[i].length; j++) {
					if(car[i][j]==null){
						continue;
					}
					else{
						if((car[i][j].getTokenNo(i, j)==token)){
							car[i][j]=null;
							parkcount--;
							parkOnEachFloor[i]--;
							System.out.println("Car removed, available parking space:"+(maxparking-parkcount));
						}
					}
				}
			}
		}
	}
}