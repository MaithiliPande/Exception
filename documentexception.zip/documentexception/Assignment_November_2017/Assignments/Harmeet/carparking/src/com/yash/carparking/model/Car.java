package com.yash.carparking.model;
/**
 * Car is used to create a car entity
 * @author harmeet.saluja
 *
 */
public class Car {
	/**
	 * regNo defines registration number of car 
	 */
	private int regNo;
	/**
	 * ownerName represents owner of car
	 */
	private String ownerName;
	/**
	 * tokenNo is object of class Token that is used to generate the tokens for the cars parked
	 */
	private Token tokenNo=new Token();
	private int i=-1,j=-1;
	
	/**
	 * default constructor of car
	 */
	public Car() {
		this(0,"Unknown");
	/**
	 * parameterized constructor of class that has regNo and ownerName as parameters
	 */
	}
	public Car(int regNo,String ownerName) {
		this.regNo=regNo;
		this.ownerName=ownerName;
	}
	
	public int getRegNo() {
		return regNo;
	}
	public void setRegNo(int regNo) {
		this.regNo = regNo;
	}
	public String getOwnerName() {
		return ownerName;
	}
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	public int getTokenNo(int i,int j) {
		this.i=i;
		this.j=j;
		return tokenNo.getToken(i, j);
	}
	
	@Override
	public String toString() {
		return "[Floor Number:"+this.i+" token:"+this.getTokenNo(i, j)+" name:"+this.ownerName+"  regNo:"+this.regNo+"]";
	}
}
