package com.yash.carparking.model;
/**
 * Token class is used to generate the tokens for Car
 * @author harmeet.saluja
 *
 */
public class Token {
	/**
	 * token[][] is repository for the car tokens
	 */
	private int[][] token=new int[5][];{
		token[0]=new int[5];
		token[1]=new int[4];
		token[2]=new int[3];
		token[3]=new int[2];
		token[4]=new int[1];
	}	
	/**
	 * Token() constructor initializes the token values
	 */
	public Token() {
		for (int i = 0; i < token.length; i++) {
			for (int j = 0; j < token[i].length; j++) {
				token[i][j]=++i;
			}
		}
	}
	/**
	 * getToken returns the token number of car
	 * @param i
	 * @param j
	 * @return
	 */
	public int getToken(int i,int j) {
		return token[i][j];
	}

	
}
