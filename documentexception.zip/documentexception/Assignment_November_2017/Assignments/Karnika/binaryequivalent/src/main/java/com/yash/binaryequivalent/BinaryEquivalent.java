package com.yash.binaryequivalent;

public class BinaryEquivalent {
	public static String binaryOfPositiveNumber(int positive_num)
	{
		StringBuilder temp = new StringBuilder("");
		while(positive_num>=1)
		{
			if(positive_num%2 ==0)
			{
				temp.append(0);				
			}
			else if(positive_num==1)
			{
				temp.append(1);
			}
			else
			{
				temp.append(1);
			}
			positive_num = positive_num/2;
		}
		temp = temp.reverse();
		return temp.toString(); // StringBuilder converted to String
		
	}
	public String getBinaryEquivalent(int input){
		String output;
		if(input>0)
		{
			output = binaryOfPositiveNumber(input);
			return output;
		}
		else if(input==0)
		{
			return "0";
		}
		else
		{

			return "";
		}			
	}

}

