package com.yash.binaryequivalent;
/**
 * Test cases :-
 * 1 valid string 
 * 2 test for zero 
 * 3 test for negative
 */

import org.junit.Test;

import junit.framework.TestCase;

public class BinaryEquivalentTest extends TestCase {
	
	
	@Test
	public void test_for_any_valid_string()
	{
		BinaryEquivalent binaryequivalent = new BinaryEquivalent();
		String results = binaryequivalent.getBinaryEquivalent(10);
	    assertEquals("1010", results);
	}
	@Test
	public void test_for_zero()
	{
		BinaryEquivalent binaryequivalent = new BinaryEquivalent();
		String results = binaryequivalent.getBinaryEquivalent(0);
	    assertEquals("0", results);
	}
	@Test
	public void test_for_negative()
	{
		BinaryEquivalent binaryequivalent = new BinaryEquivalent();
		String results = binaryequivalent.getBinaryEquivalent(-45);
	    assertEquals("", results);
	}
}
