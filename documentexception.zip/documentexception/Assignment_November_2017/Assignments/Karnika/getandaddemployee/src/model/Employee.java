package model;
/**
 * Employee class defines some methods such as adding an employee to an Employee array
 * and retrieving employee details by its id
 * @author karnika.indras
 *
 */
public class Employee {
	
	public String name;
	public int id;
	static int count=0;
	/**
	 * array is an array of type Employee which holds reference to the employee object
	 */
	static Employee array[] = new Employee[10];
	
	/**
	 * Employee constructor is a parameterized constructor which takes name and id of the 
	 * employee to create a new employee
	 * and also calls for setName and setId methods of the created objects
	 * @param name
	 * @param id
	 */
	
	public Employee(String name, int id)
	{	array[count]=new Employee();
		array[count].setName(name);
		array[count].setId(id);
		count++;
	}
	public Employee()
	{
		
	}
	
	/**
	 * getter for name
	 *
	 */
	public String getName() {
		return name;
	}
	/**
	 * setter for name
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * getter for Id
	 * @return
	 */

	public int getId() {
		return id;
	}
	/**
	 * setter for id
	 * @param id
	 */
	public void setId(int id) {
		this.id = id;
	}
	/*
	 * getData() method returns an array of type Employee 
	 * this array contains the employee objects that have been created by user
	 */
	public static Employee[] getData()
	{
		Employee returnarray[] = new Employee[count];
		for(int i=0;i<count;i++)
		{
			returnarray[i]= array[i];
		}
		return returnarray;
	}
	/**
	 * getDataById takes id of type integer as an argument and returns a String that
	 * contains the name and id of the employee 
	 * In case when there is no such id the method returns "no employee with the given id"
	 * @param id
	 * @return
	 */
	public static String getDataById(int id)
	{
		String output="";
		for(int i =0;i<count;i++)
		{
			if(array[i].id==id)
			{
				output = array[i].name+" "+array[i].id;
			}
			else
			{
				return "no employee with the given id";
			}
		}
		return output;
		
	}
}

