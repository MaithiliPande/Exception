package main;

import java.util.Scanner;

import model.Employee;
/**
 * EmployeeMain class is a start up class that displays a menu for performing some operation 
 * on Employee object
 * @author karnika.indras
 *
 */
public class EmployeeMain {
	public static void main(String args[])
	{
		/**
		 * Scanner object created 
		 */
		Scanner sc = new Scanner(System.in);
		/*
		 * name is of String type and holds name of the employee input by user
		 */
		String name;
		/*
		 * id holds the id of employee of type integer
		 */
		int id;
		int choice=0;
		String keep_working="yes";
		do{
			System.out.println("*********Employee Details menu******");
			System.out.println("1 Make a new employee entry");
			System.out.println("2 Find details of an employee by ID");
			choice= sc.nextInt();
			switch(choice)
			{
				case 1:
				{
					System.out.println("Enter the details of employee below");
					System.out.println("Enter the name of the employee");
					name = sc.next();
					System.out.println("Enter the id of the employee");
					id = sc.nextInt();
					/*
					 * employee object invokes the parameterized Employee constructor
					 */
					Employee employee = new Employee(name,id);
					
					
					
				}
				break;
				
				case 2:
				{
					System.out.println("Enter the id of the employee");
					id = sc.nextInt();
					/*
					 * The function getDataById displays the entries made in an employee array
					 */
					System.out.println(Employee.getDataById(id));
				}
				break;
				default:
				{
					System.out.println("invalid choice");
				}
			}
		
		}while(keep_working.equalsIgnoreCase("yes"));
		
		
		
	
	}

	
}
