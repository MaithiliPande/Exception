package copyarrayinreverse;
/**
 * The CopyArrayinReverse reverse class defines method to input an array and copy contents of
 * this array in reverse order into another array
 * @author karnika.indras
 *
 */

public class CopyArrayinReverse {
	/**
	 * 
	 * Inputs and returns an array of type int.
	 * This is a static type method takes int array as an argument and returns a reversed int array corresponding 
	 * to the argument. 
	 * @param arr
	 * @return
	 */
	public static int[] reverseThisArray(int[] arr)
	 {
		 int [] reversed_array = new int[5];
		 int j = 4;
		 for(int i=0;i<arr.length;i++)
		 {
			 reversed_array[i] = arr[j];
			 j=j-1;
		 }
		 return reversed_array;
		 
	 }
	public static void main(String args[])
	{
		int[] input_array ={1,2,3,4,5};
		System.out.println("Input array is ");
		for(int i =0; i<5;i++)
		{
			System.out.print(input_array[i]);
		}
		int[] output = reverseThisArray(input_array);
		System.out.println();
		System.out.println("Output array is ");
		for(int i =0; i<5;i++)
		{
			System.out.print(output[i]);
		}

}

}
