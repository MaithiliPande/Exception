package com.yash.evenoddcount;

public class EvenOdd {
 public String calculateEvenOddNumbers(String input)
  {
	 int even=0;
	 int odd=0;
	 String output;
	 if(input.isEmpty())
	 {
		 output = even+" Even "+odd+" Odd";
		 return output;
	 }
	 else
	 {
		 char array_of_char[] = input.toCharArray();
		 for(int i=0;i<array_of_char.length;i++)
		 {
			 if(Character.getNumericValue(array_of_char[i])%2 == 0)
			{
				even++;
	
			}
			else
			{
				odd++;
			}
			 
		 }
		 output =even+" Even "+odd+" Odd";
		 return output;
		 
		 
	 }
	 
  }
}
