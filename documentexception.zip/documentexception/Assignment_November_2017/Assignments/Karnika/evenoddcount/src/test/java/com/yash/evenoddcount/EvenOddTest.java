package com.yash.evenoddcount;

import org.junit.Test;

import junit.framework.TestCase;

public class EvenOddTest extends TestCase {
	@Test
	public void test_for_empty_string() throws Exception
	{
		EvenOdd evenodd = new EvenOdd();
		String result = evenodd.calculateEvenOddNumbers("");
		assertEquals("0 Even 0 Odd", result);
	}
	
	@Test
	public void test_for_valid_string() throws Exception
	{
		EvenOdd evenodd = new EvenOdd();
		String result = evenodd.calculateEvenOddNumbers("44444444444444444444444");
		assertEquals("23 Even 0 Odd", result);
	}

}
