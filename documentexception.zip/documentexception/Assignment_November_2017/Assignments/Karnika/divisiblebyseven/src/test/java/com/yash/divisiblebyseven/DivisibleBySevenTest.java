package com.yash.divisiblebyseven;

import org.junit.Test;
/**
 * test cases:-
 * 1 valid range
 * 2 invalid range
 */

import junit.framework.TestCase;

public class DivisibleBySevenTest extends TestCase {
	@Test
	public void test_for_valid_range()
	{
		DivisibleBySeven obj = new DivisibleBySeven();
		String result = obj.divisibleBySevenCount(102,199);
		assertEquals("2107",result);
	}
	
	@Test
	public void test_for_invalid_range()
	{
		DivisibleBySeven obj = new DivisibleBySeven();
		String result = obj.divisibleBySevenCount(0,99);
		assertEquals("",result);
	}

}
