package com.yash.divisiblebyseven;

public class DivisibleBySeven {
	public String divisibleBySevenCount(int min, int max)
	{
	int sum =0;
	if( min<100 || max>200)
		{
			return "";
		}
		
	else 
		{
			
		for(int i = min; i<=max;)
		{
			if(i%7==0)
			{
				sum=sum+i;
				;i++;
			}
			else
			{
				;i++;
			}
		}
			return Integer.toString(sum);
		}
}
}
