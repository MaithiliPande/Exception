package main;
import service.EmployeeService;
import model.EmployeeModel;
import java.util.Scanner;


public class Employee {

	public static void main(String[] args) {
		int choice;
		String selectChoice="no";
		EmployeeService employeeservice = new EmployeeService();
		
		
		do {

			System.out.println("******Main Menu******");
			System.out.println("1 Add Employee");
			System.out.println("2 Get the list of employees");
			System.out.println("3 Exit");
			Scanner sc = new Scanner(System.in);
			choice = sc.nextInt();
			
			switch(choice){
		case 1:
		{
			
			System.out.println("Enter name of the employee");
			String name = sc.next();
			System.out.println("Enter id of the employee");
			int id = sc.nextInt();
			System.out.println("Enter salary of the employee");
			int salary = sc.nextInt();
			EmployeeModel employeemodel = new EmployeeModel(name,id,salary);
			employeeservice.addEmployee(employeemodel);
		}	
		break;
		
		
		case 2:
		{
			EmployeeModel[] employee = employeeservice.getEmployeeDetail();
			for(int i=0;i<employee.length;i++)
				System.out.println(employee[i]);
		
			
			
		
		}
		break;
		
		case 3:
		{
		
			System.exit(0);
			}
		break;
		default:System.out.println("invalid Choice");
		}
		System.out.println("Do you still want to continue");
		selectChoice = sc.next();			
			
		
		
	}while (selectChoice.equalsIgnoreCase("yes"));
	}



	}


