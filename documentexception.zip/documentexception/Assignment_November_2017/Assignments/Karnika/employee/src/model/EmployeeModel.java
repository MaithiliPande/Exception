package model;

/**The EmplpoyeeModel class defines the object and its field along with getters and setters method for the field of employee object**/
public class EmployeeModel {
	String name;
	int id;
	int salary;
	
	
	
	
	/**constructor for employee**/
	public EmployeeModel(String name, int id, int salary)
	{
		this.name = name;
		this.id = id;
		this.salary= salary;
		
	}
	/**getters and setters for id**/
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	
	/**getters and setters for name**/
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
	/**getters and setters for salary**/
	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}
	
	/*
	 * This method overrides toString Method of the Object Class. The method converts the hashcode values into String type in the format
	 * as described in the method
	 */
	@Override
	public String toString() {
		return "[id : "+this.id+" , name: "+this.name+" , salary: "+this.salary+"]";
	}


	
	
}

