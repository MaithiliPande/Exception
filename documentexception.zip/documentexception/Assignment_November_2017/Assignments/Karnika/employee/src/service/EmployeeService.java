package service;
import model.EmployeeModel;



/*
 * EmployeeService class includes services such as to add employee to a local repository and retrieve the records stored in the 
 local repository
 */


public class EmployeeService {
		/*
		 * The local repository here is employee_array
		 */
		EmployeeModel[] employee_array = new EmployeeModel[10];
		private int location=0;
		
		/*
		 * addEmployee method takes EmployeeModel object and stores is in the local repository i.e employee_array
		 */
	
	
	public void addEmployee(EmployeeModel employee)
	{
			employee_array[location++] = employee; 
			
		
	}
	/*
	 * The method getEmployeeDetail returns an array of type EmployeeModel. This array i.e temp_employee_array is of the size of the entries made in the employee_array.
	 * 
	 */
	public EmployeeModel[] getEmployeeDetail(){
		EmployeeModel[] temp_employee_array = new EmployeeModel[location];
			for(int i=0;i<location;i++)
			{
				temp_employee_array[i] = employee_array[i];
			}
		return temp_employee_array;
	}
	
	

}
