package tollbooth;
import tollbooth.TollBooth;

import java.util.Scanner;
/**
 * TollBoothTest implements start up menu for TollBooth
 * @author karnika.indras
 *
 */

public class TollBoothTest {

	public static void main(String[] args) {
		int choice;
		String keep_working="yes";
		Scanner sc = new Scanner(System.in);
		TollBooth tollbooth = new TollBooth();
		do{
			System.out.println("************TollBooth*************");
			System.out.println("1. Paying car");
			System.out.println("2. No Paying car");
			System.out.println("3. press escape to display information and exit");		
			choice = sc.nextInt();
			switch(choice)
			{
			 case 1:
			 {
				 tollbooth.payingCar();
			 }
			 break;
			 case 2:
			 {
				 tollbooth.noPayingCar();
			 }
			 break;
			 default:
			 {
				tollbooth.display();
				System.exit(0);
			 }
			 System.out.println("Continue working");
			 
			 keep_working = sc.next();
			
			}
		}while(keep_working.equalsIgnoreCase("yes"));
		
	}

}
