package tollbooth;

public class TollBooth {
	static int no_of_cars;
	static double amount_collected;
	
	TollBooth()
	{
		no_of_cars =0;
		amount_collected=0;
	}
	
	public void payingCar()
	{
		no_of_cars++;
		amount_collected = amount_collected+0.50;
	}
	
	public void noPayingCar()
	{
		no_of_cars++;
	}
	
	public void display()
	{
		System.out.println("No of cars" +no_of_cars);
		System.out.println("Total Amount Collected" +amount_collected);
	}
	
}
