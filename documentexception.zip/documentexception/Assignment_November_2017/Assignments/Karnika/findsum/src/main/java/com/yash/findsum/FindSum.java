package com.yash.findsum;

public class FindSum { 
	
	public String getSum(String input)
	{
		if(input.isEmpty())
			{
				return "";
			}
		else
			{
			int sum = 0;
			String temp_for_check;
			if(input.charAt(0)=='+')
			{
				temp_for_check = input.substring(1);
			}
			else
			{
				temp_for_check = input;
			}
			String  some_array[] = temp_for_check.split("\\+");
		
			   for(int i =0; i<some_array.length; i++)
				{
					String string_var;
					string_var = some_array[i];
					int temp = Integer.parseInt(string_var);
					sum = sum + temp;
				}
					return Integer.toString(sum);
				   
				
			}
			}
	}

			

		



//generates dangling meta character
//error when 
// split("+")
		
		
//		if(input.isEmpty())
//		{
//		return "not valid";
//		}
//		
//		else
//		{
//			int string_array[] = input.split("+");
//			for(int i: number_array)
//			{
//				sum = sum+i;
//			}
//			return Integer.toString(sum);
//		}
		
		
		
		
		
		
//		else
//		{
//			char array_of_char[] = input.toCharArray();
//			for(int i =0;i<array_of_char.length;)
//			{
////				if((Character.getNumericValue(array_of_char[i]))!=-1)
////				{
////				sum = sum + Character.getNumericValue(array_of_char[i]);
////				i++;
////				}
////				else
////				{
////					i++;
////				}
//				
//			}
//			return Integer.toString(sum);
//			
//		}
		
//	}
//}
