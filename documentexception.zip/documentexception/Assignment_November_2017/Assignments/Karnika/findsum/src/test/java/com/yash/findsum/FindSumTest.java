package com.yash.findsum;

import org.junit.Test;
/**
 * 
 * test cases 
 * 1 empty string 
 * 2 test for any valid string of with single digits separated by +
 * 3 test for string with any number of digits separated by +
 * 4 test for valid string that begins with +
 * 5 test for string that ends with +
 */

import junit.framework.TestCase;

public class FindSumTest extends TestCase {
	@Test
	public void test_for_empty_string()
	{
		FindSum findsum = new FindSum();
		String result = findsum.getSum("");
		assertEquals("",result);
	}
	
	@Test
	public void test_for_any_valid_string_with_single_digit()
	{
		FindSum findsum = new FindSum();
		String some_string = "2+3+5";
		String result = findsum.getSum(some_string);
		assertEquals("10",result);
	}
	

	@Test
	public void test_for_string_with_any_number_of_digit_numeric_value()
	{
		FindSum findsum = new FindSum();
		String result = findsum.getSum("245+56+6");
		assertEquals("307",result);
	}
	
	@Test
	public void test_for_string_preceding_with_plus()
	{
		/*generates Pattern syntax Exception: Dangling meta character '+'
		 near index 0
		 */
		
		FindSum findsum = new FindSum();
		String result = findsum.getSum("+24+56+6");
		assertEquals("86",result);
	}
	
	@Test
	public void test_for_string_with_plus_in_the_trail()
	{
		FindSum findsum = new FindSum();
		String result = findsum.getSum("24+56+6+");
		assertEquals("86",result);
	}
	
	@Test
	public void test_for_string_with_plus_only()
	{
		FindSum findsum = new FindSum();
		String result = findsum.getSum("++++++");
		assertEquals("0",result);
	}
}

