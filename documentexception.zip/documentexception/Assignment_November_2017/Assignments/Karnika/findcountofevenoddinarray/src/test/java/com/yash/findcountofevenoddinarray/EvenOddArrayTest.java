package com.yash.findcountofevenoddinarray;

import org.junit.Test;

import junit.framework.TestCase;
/**
 * EvenOddArrayTest defines test_for_any_array that calls a method findCount of class EvenOddArray
 * and checks whether count of even odd negative and positive elements in the array is same as 
 * expected
 * @author karnika.indras
 *
 */

public class EvenOddArrayTest extends TestCase {
	
	private int[] input_array ={1,1,1,1,1,1,1,1,1,1,1,1,1,1,1};
	private final String expected =" even 0 odd 15 negative 0 positive 15";
	EvenOddArray object = new EvenOddArray();
	
	
	@Test
	public void test_for_any_array()
	{
		 String result = object.findCount(input_array);
		 assertEquals(expected, result);
	}

}
