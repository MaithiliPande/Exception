package com.yash.findcountofevenoddinarray;

public class EvenOddArray {
	/*
	 * findCount function inputs an array of type integer and checks for each element whether it is 
	 * even odd negative or positive.
	 * It returns a string that represents count of even odd positive and negative 
	 * number in the input array.
	 * format- "even 0 odd 0 negative 0 positive 0"
	 * 
	 */
	public String findCount(int arr[])
	{
		int even=0;
		int odd=0;
		int positive=0;
		int negative=0;
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]>0)
				positive++;
			if(arr[i]<0)
				negative++;
			if(arr[i]%2==0)
				even++;
			if(arr[i]%2 != 0)
				odd++;
		
		}
		return " even "+even+" odd "+odd+" negative "+negative+" positive "+positive;
	}

}
