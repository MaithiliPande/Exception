package createintclass;
import createintclass.MyInt;

public class StartUp {

	public static void main(String[] args) {
		MyInt myint = new MyInt(5); // creates myint object with integer value 5
		
		MyInt new_myint = new MyInt(10); // creates myint object with integer value 10
		
		MyInt uninitialized = new MyInt(); // creates an uninitialized object 
		
		myint.displayMyInt(); // displays the integer value of myint object
		
		myint.initializeToSomeValue(45);// myint initialized to an integer value of 45
		
		myint.displayMyInt(); // displays 45 i.e new value of object myint
		
		myint.initializeToZero(); // initializes myint to zero
		
		myint.displayMyInt(); // displays 0 i.e new value of object myint
		
		System.out.println(myint.addTwoMyInt(new_myint));// displays sum of value of myint and new_myint object
		uninitialized.initializeToSomeValue(myint.addTwoMyInt(new_myint));// initializes object uninitialized to the sum of value of myint and new_myint
		uninitialized.displayMyInt();// displays value of uninitialized i.e 10
		
	
		

	}

}
