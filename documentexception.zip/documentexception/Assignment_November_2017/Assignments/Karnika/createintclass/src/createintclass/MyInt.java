package createintclass;

/**
 * MyInt class creates object which have a property called value.
 * the value property for each MyInt object holds its integer value
 * @author karnika.indras
 *
 */

public class MyInt {
		private int value; // value is private and cannot be accessed directly by any other class
		
				MyInt(int value)
		{
			initializeToSomeValue(value);
		}
		MyInt()
		{
			
		}
		/**
		 * initializeToZero sets the value property of the invoking 
		 * object equal to the integer argument
		 * @param value
		 */
		public void initializeToZero()
		{
			this.value =0;
		}
		
		/**
		 * initializeToSomeValue method takes an integer value as argument and sets the 
		 * value property of the invoking object equal to the integer argument
		 * @param value
		 */

		public void initializeToSomeValue(int input_value)
		{
			value = input_value;
		}
		/**
		 * displayMyInt method displays the value of the invoking object
		 */
		public void displayMyInt()
		{
			System.out.println(value);
		}
		/**
		 * addTwoMyInt method takes an object of type MyInt as an argument. 
		 * It returns sum of the value of invoking object and the argument as an integer
		 * @param input
		 * @return
		 */
		public int addTwoMyInt(MyInt input)
		{
			System.out.println(this.value);
			return this.value+input.value;
			
		}
		

}
