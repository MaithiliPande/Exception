package com.yash.actionfromurl;

public class UrlAction {
	public String getAction(String input)
	{
		int begin_index = input.lastIndexOf("/");
		int last_index = input.lastIndexOf(".");
		return input.substring(begin_index+1,last_index);
	}
}
