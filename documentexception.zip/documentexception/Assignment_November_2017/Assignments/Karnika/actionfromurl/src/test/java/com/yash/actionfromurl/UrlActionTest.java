package com.yash.actionfromurl;

import org.junit.Test;



import junit.framework.TestCase;

public class UrlActionTest extends TestCase {
	private String first_url="www.yash.com/index.jsp";
	private String second_url="www.yash.com/employees/salary.xhtml";
	private String third_url="google.com/searches/searchdata.jsp";
	
	@Test
	public void test_for_first_url()
	{
		UrlAction urlaction = new UrlAction();
		String result = urlaction.getAction(first_url);
		assertEquals("index", result);
		
	}
	
	@Test
	public void test_for_second_url()
	{
		UrlAction urlaction = new UrlAction();
		String result = urlaction.getAction(second_url);
		assertEquals("salary", result);
	}
	
	@Test
	public void test_for_third_url()
	{
		UrlAction urlaction = new UrlAction();
		String result = urlaction.getAction(third_url);
		assertEquals("searchdata", result);
	}

}
