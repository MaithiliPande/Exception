package carparkingproblem;

import java.util.Scanner;

public class StartUpClass {
	public static void main(String args[])
	{
		/*
		 * choice holds the value of an integer corresponding to which operations 
		 * in the main start up menu are performed
		 */
		int choice;
		String keep_working="yes";
		CarParkingSlot obj = new CarParkingSlot();
		Scanner sc = new Scanner(System.in);
		int id;
		Car car;
		 
		 do{
			 System.out.println("********Car Parking**********");
			 System.out.println("Enter your choice");
			 System.out.println("1 Park Car");
			 System.out.println("2 Remove");
			 System.out.println("3 Show Parking Area");
			 choice = sc.nextInt();
			 switch(choice)
			 {
			 case 1:
			 {
				 System.out.println("Enter the id of the car");
				 id = sc.nextInt();
				 /*
				  * car object is created each time a car wants to park
				  * id of the car is passe din the constructor
				  * parkCar() method of CarParkingSlot is called on an object named obj.
				  */
				  car = new Car(id);
				  obj.parkCar(car);
			 }
			 break;
			 /**
			  * for remove operation removeCar() function of class CarParkingSlot 
			  * is called by passing the id of the car
			  */
			 case 2:
			 {
				System.out.println("Enter the id of the car"); 
				id = sc.nextInt();
				obj.removeCar(id);
			 }
			 break;
			 
			 /**
			  * showParkingArea method displays the occupied and empty slots in 
			  * token array.
			  * for empty slots the value is represented by integer zero
			  */
			 case 3:
			 {
				 obj.showParkingArea();
			 }
			 break;
			 default:
			 {
				 System.out.println("invalid choice");
			 }
			 
				 
			 }
			 
		 } while(keep_working.equalsIgnoreCase("yes"));	
	}

}
