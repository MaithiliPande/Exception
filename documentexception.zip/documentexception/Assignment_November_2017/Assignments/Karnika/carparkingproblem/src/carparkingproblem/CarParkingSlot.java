package carparkingproblem;
/**
 * CarParkingSlot class defines methods to park car, remove car and shows parking area
 * @author karnika.indras
 *
 */
public class CarParkingSlot
{
	/*
	 * token is an array of the parking space for the car
	 * for each car a token of some integer value is generated
	 */
	static public int[][] token = new int[5][];	
	/*
	 * Constructor of the CarParkingSlot initialized the token array
	 * which is a jagged array
	 */
	CarParkingSlot()
	{
		token[0]= new int[1];
		token[1] = new int [2];
		token[2] = new int [3];
		token[3] = new int [4];
		token[4] = new int [5];
	}
	
	/*
	 * parCar() method takes an argument of car type.
	 * This method calls for a function findAnEmptySlot();
	 * to get value of available parking slot. 
	 * this method also sets slot alloted to each car by calling 
	 * setToken() method of Car class
	 */
	
	public int parkCar(Car car)
	{
		int available_slot = findAnEmptySlot();
		int i = available_slot/10;
		int j = available_slot%10;
		car.setToken(available_slot);
		token[i][j] = car.getId();
		return available_slot;
	}
	/*
	 * findAnEmptySlot method returns an integer value corresponding to an 
	 * empty slot
	 * for an empty slot token[i][j] , i*10+j is returned as an integer
	 * 
	 */
	private static int findAnEmptySlot()
	{
		int output=-1;
		for(int i=0;i<token.length;i++)
		{
			for(int j=0;j<token[i].length;j++)
			{
				if(token[i][j]==0)
				{
					output =i*10+j;
				}
			}
		}
		return output;
	}
	
	/*
	 * removeCar method takes id of the car as input and sets the value at
	 * that index in the token array equivalent to zero
	 */
	
	public void removeCar(int id)
	{
		for(int i=0;i<token.length;i++)
		{
			for(int j=0;j<token[i].length;j++)
			{
				if(token[i][j]==id)
				{
					token[i][j]=0;
				}
			}
		}
	}
	
	/*
	 * show parking area method displays the occupied and empty slots in the parking area
	 */
	public void showParkingArea()
	{
		for(int i=0;i<token.length;i++)
		{
			System.out.println("floor"+i);
			for(int j=0;j<token[i].length;j++)
			{
				System.out.println(token[i][j]);
			}
		}
		
	}
}
	
	
