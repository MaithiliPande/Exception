package carparkingproblem;
/**
 * Car defines object of type car which have instance variable of type id and token.
 * @author karnika.indras
 *
 */
public class Car {
	int id;
	/*
	 * getters and setters for id
	 */
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	/*
	 * getters and setters for slot
	 */
	int token;
	public int getToken() {
		return token;
	}
	public void setToken(int token) {
		this.token = token;
	}
	/*
	 * Car constructor
	 */
	public Car(int id)
	{
		this.id = id;
	}
	
	
	
}
