package transposearray;

/**
 * TransposeAnArray class defines a method to transpose a 4*4 integer array and display it
 * @param arr
 * @return
 */
public class TransposeAnArray {
	/**
	 * transposeThisArray method takes 4*4 integer array as argument and returns a transposed 
	 * integer array
	 * @param arr
	 * @return
	 */
	public int[][] transposeThisArray(int[][] arr)
	{
		int temp;
		int temprorary_array[][] = new int[4][4];
		for(int i=0; i<3;i++)
		{
			for(int j=0;j<3;j++)
			{
				temprorary_array[j][i]= arr[i][j];
			}
		}
		return temprorary_array;
		
	}
	public static void main(String[] args) {
		/*
		 * temp_array is a 4*4 integer array that has been initialized to some values;
		 */
		int[][] temp_array = {{1,2,3},{4,5,6},{7,8,9}};
		TransposeAnArray obj = new TransposeAnArray();
		System.out.println("The input array is");
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
			{
				System.out.print(temp_array[i][j]+" ");
			}
			System.out.println();
		}
		/**
		 * result_array holds the array returned from the method transposeThisArray
		 */
		int[][] result_array =obj.transposeThisArray(temp_array);
		System.out.println("The transposed array is");
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
			{
				System.out.print(result_array[i][j]+" ");
			}
			System.out.println();
		

	}

	}
}
