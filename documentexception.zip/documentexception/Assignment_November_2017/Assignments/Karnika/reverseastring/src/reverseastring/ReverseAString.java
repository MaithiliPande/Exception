package reverseastring;

import java.util.Scanner;
/**
 * ReverseAString class defines method reverseIt()
 * to reverse any input string
 * @author karnika.indras
 *
 */

public class ReverseAString {
	/*
	 * reverseIt method takes a string as an argument and returns a character array having elements
	 * sequenced in reverse order corresponding to the input string.
	 * In this method the character at the first index is swapped with the character
	 * at the last index, and successive swapping is performed until the string is reversed
	 */
	public char[] reverseIt(String string)
	{
		char array[] = string.toCharArray();
		int mid = array.length/2;
		int j = array.length -1;
		char temp;
		for(int i = 0; i<mid&&j>=mid;i++)
		{
				temp = array[i];
				array[i] = array[j];
				array[j] = temp;
				j=j-1;
		}
		return array;
	}
	
	public static void main(String args[])
	{
		/*
		 * input_string is a variable that holds the user string input
		 */
		String input_string;
		char[] output;
		String special_string="able was I era I saw elba";
		Scanner sc = new Scanner(System.in);
		ReverseAString obj = new ReverseAString();
		System.out.println("Enter any string ");
		input_string = sc.nextLine();
//		output = obj.reverseIt(input_string);
		output = obj.reverseIt(special_string);
		for(int i=0;i<output.length;i++)
		{
			System.out.print(output[i]);
		}
	}

}
