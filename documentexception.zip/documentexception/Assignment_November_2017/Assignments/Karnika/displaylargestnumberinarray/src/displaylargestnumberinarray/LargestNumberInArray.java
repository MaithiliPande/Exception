package displaylargestnumberinarray;

import java.util.Scanner;
/**\
 * LargestNumberInArray class defines a method to input 
 * @author karnika.indras
 *
 */
public class LargestNumberInArray {
	/**
	 * findLargestElement takes an integer array as an argument and returns the largest 
	 * element in that array
	 * @param arr
	 * @return
	 */
	private static int findLargestElement(int[] arr) {
		int max =arr[0];
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]>max)
			{
				max= arr[i];
			}			
		}
		return max;
		
	}
	public static void main(String args[])
	{
		/*
		 * size stores the size of the array that user intends to input
		 */
		int size;
		System.out.println("enter the size of the array");
		Scanner sc = new Scanner(System.in);
		size = sc.nextInt();
		/*
		 * temp_array is an integer array created with capacity equal to size 
		 */
		int[] temp_array = new int[size];
		int count =0;
		while(count<size)
		{
			for(int i=0;i<size;i++)
			{
				temp_array[i] = sc.nextInt();
				count++;
			}
			
		}
		System.out.println("The largest number in the array is " +findLargestElement(temp_array));
	}

	
}
