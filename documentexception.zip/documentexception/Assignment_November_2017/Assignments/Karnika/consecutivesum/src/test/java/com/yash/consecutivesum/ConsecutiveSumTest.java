package com.yash.consecutivesum;
import org.junit.Before;
/*
 * 
 * List of the test cases applied:-
 * 1  when input is empty - 0 expected 
 * 2  when input is zero - 0 expected
 * 3  when input is invalid string - -1 expected
 * 4  when input is a negative number 
 * 5 when input is a valid number
 */

import org.junit.Test;

import junit.framework.TestCase;

public class ConsecutiveSumTest extends TestCase {
	
	private ConsecutiveSum consecutiveSum;
	@Before
	public void setUp() throws Exception{
		consecutiveSum = new ConsecutiveSum();	
	}
	
    @Test
	public void test_for_empty() throws Exception{
		String result = consecutiveSum.return_sum("");
		assertEquals("0",result);
		}
    
    @Test
	public void test_for_zero() throws Exception{
		String result = consecutiveSum.return_sum("0");
		assertEquals("45",result);
		}
    
    
    @Test
   	public void test_for_any_invalid_string() throws Exception{
   		String result = consecutiveSum.return_sum("gh");
   		assertEquals("-1",result);
   		}
    
    @Test
   	public void test_for_any_negative_input() throws Exception{
   		String result = consecutiveSum.return_sum("-5");
   		assertEquals("-5",result);
   		}
    
    @Test
   	public void test_for_any_valid_input() throws Exception{
   		String result = consecutiveSum.return_sum("2147483647");
   		assertEquals("21474836515",result);
   		}
    
    
    
}
