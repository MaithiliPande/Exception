package com.yash.consecutivesum;

import java.math.BigInteger;
/*
 * ConsecutiveSum class defines a method to input an integer and return the sum of ten consecutive 
 * number after the given number
 */
public class ConsecutiveSum {
	/*
	 * return_sum method accepts String input so that operation on input greater than
	 * int range can be performed as well.
	 * 
	 */
	public  String return_sum(String input) {
		BigInteger temp;
		BigInteger sum = new BigInteger("0");
		BigInteger one = new BigInteger("1");
		
		/*
		 * in case of empty string 0 is returned
		 */
		
		if(input.isEmpty())
		{
			return sum.toString();
		}

		else
			
		/*
		 * 	in case of any other string than zero, the try block calculates the sum 
		 *  for valid input strings. 
		 *  In case of invalid string NumberFormatException is generated which 
		 *  is handled in catch block
		 */
		try {
			temp = new BigInteger(input);
			for(int i=1;i<=10;i++)
			{
				sum=sum.add(temp);
				temp = temp.add(one);
				
			}
			return sum.toString();
			
			
		}
		/*
		 * In case of invalid String -1 is returned
		 */
		catch(NumberFormatException e){
			return "-1";
	    }	
	}

	

}
