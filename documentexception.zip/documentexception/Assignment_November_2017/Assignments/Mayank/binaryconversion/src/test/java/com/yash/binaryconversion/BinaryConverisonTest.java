package com.yash.binaryconversion;

import static org.junit.Assert.assertArrayEquals;


import org.junit.Test;



public class BinaryConverisonTest  {

	
//	@Test
//	public void atNullValue(){
//		BinaryConversion obj = new BinaryConversion();
//		int input[]= obj.converionLogic(null);
//		int[] expected ={0}; 
//		assertArrayEquals(expected,input);
//		}

	@Test
	public void atValue(){
		BinaryConversion obj = new BinaryConversion();
		int[] input= obj.converionLogic(2);
		int[] expected ={1,0};
		assertArrayEquals(expected,input);
		
		}
	
	@Test
	public void atZero(){
		BinaryConversion obj = new BinaryConversion();
		int[] input= obj.converionLogic(0);
		int[] expected ={0};
		assertArrayEquals(expected,input);
		
		}












}
