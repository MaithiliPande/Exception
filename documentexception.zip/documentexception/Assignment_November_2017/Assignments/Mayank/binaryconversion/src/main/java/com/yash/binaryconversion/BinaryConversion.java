package com.yash.binaryconversion;

import java.util.Stack;

public class BinaryConversion {

	public int[] converionLogic(int input){
		//		return "nothing is there to be converted";
		//		return 10;
		//		try{
//			Integer.parseInt(input);
//		}
//		catch(NumberFormatException e)
//		{
//			return "null";
//		}
//		int i;
//		int[] result = new int[size];
//		input=6;
		
		if(input==0){
			int[] zeroinput={0};
			return zeroinput;
		}
	
		int binary=0;
		int size=0;
		Stack<Integer> stack = new Stack<Integer>();
		while(input>0){
		binary=input%2;
	    stack.push(binary);
	    input=input/2;
	    size++;	}
		int[] result = new int[size];
int i=0;
	while(!(stack.isEmpty())){
	
     result[i] = (stack.pop());
	i++;
	}
	return result;
//			
		
//		System.out.println(result);
//			binary[i]=0 ;
//		i++;
//		stack.push(0);
//		}
//		else{
//			binary[i]=1;
//			i++;
//			stack.push(1);
//		}}
		
//System.out.println(stack);
		
//		return stack;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
