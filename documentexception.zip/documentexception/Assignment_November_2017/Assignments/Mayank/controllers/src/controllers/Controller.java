package controllers;

public interface Controller {
	
	
	static Controller getController(String name){
		
		if(name.equals("index")){
			Controller con = new HomeController().getController(name);
			return con;
		}
		
		else if(name.equals("salary")){
			Controller con = new SalaryController().getController(name);
			return con;
		}
		
		else if(name.equals("admin"))
		{
			Controller con = new AdminController().getController(name);
			return con;
		}
	return null;	
	}
	public void activated();
}
