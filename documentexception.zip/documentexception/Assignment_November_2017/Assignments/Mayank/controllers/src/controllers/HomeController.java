package controllers;

public class HomeController implements Controller {

	public static Controller getController(String name){
		
		Controller con = new HomeController();
		return con;
		
	}
	
	public void activated(){
		System.out.println("home activated");
	}
}
