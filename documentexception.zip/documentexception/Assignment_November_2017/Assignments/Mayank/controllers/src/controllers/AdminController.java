package controllers;

public class AdminController implements Controller{

	
public static Controller getController(String name){
		
		Controller con = new AdminController();
		return con;
		
	}
	
	public void activated(){
		System.out.println("AdminController activated");
	}
}
	

