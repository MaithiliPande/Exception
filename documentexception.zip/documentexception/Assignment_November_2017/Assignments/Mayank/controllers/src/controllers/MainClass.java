package controllers;

public  class MainClass {

	public static void main(String[] args)
	{	
	String string1 = "lasjdlksajlkdjolsa/Admin.com";
  int index = string1.lastIndexOf('/');
  System.out.println(index);
  int toend = string1.lastIndexOf('.');
  String substring = string1.substring(++index,toend);
  
           FrontController obj = new FrontController(substring);
 // System.out.println( "have to go to: " +s2);
}
}