package controllers;

public class FrontController {
	
	
	public FrontController(String s){
		
	System.out.println(s);
	
	Controller con = Controller.getController(s);
               con.activated();
}
}