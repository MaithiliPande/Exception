package com.yash.additionstring;



public class StringAddition {
	
	
	public Integer addString (String input)
	{ 
//		char[] check = input.toCharArray();
		
		if(input==null){
			return null;
		}
		
		
		  
	        String[] splitted = input.split("\\+");
	        
	        try{ int i=0;
	        	while(i < splitted.length){
	        	Integer.parseInt(splitted[i]);
	        	i++;
	        	}
	        	
	        }
	        catch(NumberFormatException e){
	        	return null ;
	        }
	        
	        int sum=0;
	       int i=0;
	        while( i < splitted.length)
        {
	     sum = sum + Integer.parseInt(splitted[i]);
	         i++;          	}
	        return sum;
	       
	}
//	        System.out.println(splitted[i]);
	   
		     }		
	
	
		

		
	
		
	


