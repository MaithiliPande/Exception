package com.yash.additionstring;

import static org.junit.Assert.*;

import org.junit.Test;

public class AddStringTest {

	@Test
	public void emptyAdditon()
	{
		StringAddition obj = new StringAddition();
		Integer result = obj.addString("5+6");
		assertEquals(new Integer(11),result);
	}
	
	@Test
	public void atString()
	{
		StringAddition obj = new StringAddition();
		Integer result = obj.addString("5+6+ae");
		assertEquals(null,result);
	}

	
	@Test
	public void atNull()
	{
		StringAddition obj = new StringAddition();
		Integer result = obj.addString("");
		assertEquals(null,result);
	}

}
