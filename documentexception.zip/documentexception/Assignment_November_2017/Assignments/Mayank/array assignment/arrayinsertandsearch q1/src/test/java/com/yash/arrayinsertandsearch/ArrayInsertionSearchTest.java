package com.yash.arrayinsertandsearch;

import static org.junit.Assert.*;
/**
 * here a array input and two variable numbertosearch,checker are given to test the logic for 
 * the values you want to check for and a tes tcase is also here to insert these values.
 */

import org.junit.Test;

public class ArrayInsertionSearchTest {

private	final int[] input = {1,1,5,78,9,12,1};
	
private final int numbertosearch=1;

private final int checker = 3;

//	@Test
//	public void ifNumberIsNotThere(){
//		ArrayInsertionSearch obj = new ArrayInsertionSearch();
//	int  result = obj.insertionTest(input,numbertosearch);
//        assertEquals(0,result);
//	}
//	@Test
//	public void ifNumberIsThereOnce(){
//		ArrayInsertionSearch obj = new ArrayInsertionSearch();	
//     int  result = obj.insertionTest(input,numbertosearch);
//	     assertEquals(1,result);
//		
//	}
	@Test
	public void ifNumberIsRepeatedAnyTime(){
		ArrayInsertionSearch obj = new ArrayInsertionSearch();	
     int  result = obj.insertionTest(input,numbertosearch);
	     assertEquals(checker,result);
		
	}



}
