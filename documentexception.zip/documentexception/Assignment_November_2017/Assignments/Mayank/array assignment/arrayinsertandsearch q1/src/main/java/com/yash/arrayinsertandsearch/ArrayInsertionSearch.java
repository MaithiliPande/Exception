package com.yash.arrayinsertandsearch;

/**
 * logic to accept the array and numbertosearch and count the repetition of number encountered.
 * @author mayank
 *
 */
public class ArrayInsertionSearch {
 
public Integer insertionTest(int[] input,int numbertosearch){
	
	
    int count=0;
   for (int i=0; i<input.length;i++) 
  {	
	   if(input[i]==numbertosearch)
 {
		count++;
          }
				}
			return count;
    }
  }






	







