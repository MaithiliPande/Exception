package transposearray;


import java.util.Scanner;
/**
 * here a array 4*4 is accepted from user in matrix form and then the transpose of that 
 * matrix is done and reult is printed.
 * two arrays :- array for input, transposed array for result 
 * input varibale is to accept the input
 * @author mayank
 *
 */

public class TransposeArray {

	public static void main(String[] args) {
		
	
	
	int[][] array =new int[4][4];
	int[][] transposedarray= new int[4][4];
	
	Scanner input = new Scanner(System.in);
	
	System.out.println("enterr elements 4*4 array");
	
	for(int i=0; i<array.length;i++){
		
		for(int j=0;j<array.length;j++){
			array[i][j]=input.nextInt();
			
		}
	}
	input.close();
	
for(int i=0; i<4;i++){
		
		for(int j=0;j<4;j++){
			
			System.out.print(array[i][j]+"   ");
//		System.out.println(Arrays.toString(array[i][j]));
			
		}System.out.println(" ");
	}



for(int i=0; i<array.length;i++){
	
	for(int j=0;j<array.length;j++){
		transposedarray[i][j]=array[j][i];
		
	}
}
System.out.println("transpose of the array is :");
for(int i=0; i<4;i++){
	
	for(int j=0;j<4;j++){
		
		System.out.print(transposedarray[i][j]+"   ");
//	System.out.println(Arrays.toString(array[i][j]));
		
	}System.out.println(" ");
}

	
}
	}
