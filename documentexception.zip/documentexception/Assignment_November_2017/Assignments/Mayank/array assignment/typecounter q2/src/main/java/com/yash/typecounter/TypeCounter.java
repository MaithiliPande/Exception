package com.yash.typecounter;
/**
 * a loop is used here to go through the array and then two if else are used one is to count 
 * even/odd and other is to count positive or negative.
 * @author mayank
 *
 */

public class TypeCounter {


public int[] positiveCounter(int[] input){
	
	int[] result={0,0,0,0};
	int even=0;
	int odd=0;
	int positive=0;
	int negative=0;
	
	for(int i =0; i <input.length;i++){
		if(input[i] % 2 == 0){
		 even++;
		}
		else odd++;
	if(input[i]>0){
		positive++;
	}
	else negative++;
}
	result[0]=even;
	result[1]=odd;
	result[2]=positive;
	result[3]=negative;
return result;
}



}



