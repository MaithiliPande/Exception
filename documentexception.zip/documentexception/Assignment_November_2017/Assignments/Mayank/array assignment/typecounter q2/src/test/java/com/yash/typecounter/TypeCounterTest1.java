package com.yash.typecounter;

import static org.junit.Assert.*;

import org.junit.Test;

public class TypeCounterTest1 {
	/**
	 * input arrray is apassed array and check array is checking odd even etc.with 0
	 * index for even, 1 for odd, 2 for  positive, 3 for negative
	 */
	private	final int[] input = {1,2,3,-4,5,6,-7};
private final int[] check = {3,4,5,2};
//	@Test
//	public void countPositiveForEmpty() {
//
//		TypeCounter obj = new TypeCounter();
//		int result = obj.positiveCounter(input);
//		assertEquals(0, result);
//	}
	
	@Test
    public void countEvenForInput() {

		TypeCounter obj = new TypeCounter();
		int[] result = obj.positiveCounter(input);
	
		
		assertEquals(check[0], result[0]);
	}

	@Test
    public void countOddForInput() {

		TypeCounter obj = new TypeCounter();
		int [] result = obj.positiveCounter(input);
		assertEquals(check[1], result[1]);
	}

	@Test
    public void countPositiveForInput() {

		TypeCounter obj = new TypeCounter();
		int[] result = obj.positiveCounter(input);
		assertEquals(check[2], result[2]);
	}

	@Test
    public void countNegativeForInput() {

		TypeCounter obj = new TypeCounter();
		int[] result = obj.positiveCounter(input);
		assertEquals(check[3], result[3]);
	}

	
	

}
