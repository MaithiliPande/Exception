package stringreverse;
/**
 * In this the logic to reverse string is defined and to string to cinvert
 *  is accepted and returned.
 * @author mayank
 *
 */
public class ToCall {

	
	public String  reverseIt(String input)
	{
			
//			String input="abc00";
			
		char[] parsedinput =input.toCharArray();
		
		int j=parsedinput.length-1;
		
     for(int i=0 ; i<j ;i++){
	char temp =parsedinput[i];
	parsedinput[i]=parsedinput[j];
	parsedinput[j]=	temp;
            j--;
			
			}
     String reversed= new String(parsedinput);
     
     return reversed  ;
			
			
   
		}    

}