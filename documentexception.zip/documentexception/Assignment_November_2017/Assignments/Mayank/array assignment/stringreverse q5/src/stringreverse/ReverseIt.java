package stringreverse;

import java.util.Scanner;
/**
 * In main function  user can enter the string that he wants to get reversed
 *and  the string is then passed to  reverseIt function where logic to reverse is defined.
 * @author mayank
 *
 */

public class ReverseIt {

	public static void main(String[] args) {
		
	ToCall object = new ToCall();
	
	System.out.println("enter string want  to reverse");
   Scanner sc = new Scanner(System.in);
    String input= sc.nextLine();
	   sc.close();    
String	reversed= object.reverseIt(input);
System.out.println("reversed string is :"+reversed );
	}
}