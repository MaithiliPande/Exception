package arraycopyinreverse;

import java.util.Scanner;
/**
 * in this the elements inside an array are copied in reverse order in reverse array.
 * @author mayank
 *
 */

public class ArrayCopyInReverse {
	
	
	public static void main(String[] args) {
		
		int[] array=new int[5];
		
		System.out.println("enter array elements");
		Scanner input= new Scanner(System.in);
		for(int i=0;i<array.length;i++){
			array[i]=input.nextInt();
		}
		input.close();
		System.out.println("elements inserted succesfully");
	
    int[] reverse = new int[5];
	int i=0;
	for(int j=(array.length)-1 ; j>=0 ; j--){
		
		reverse[i]=array[j];
		i++;
	}
	
	System.out.println("reversed successfully");
	
	for(int k=0;k<reverse.length;k++){
		System.out.println(reverse[k]);
	}
	
	}}
