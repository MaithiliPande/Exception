package employee;

public class Employee {
	
	int id;
	int age;
	int salary;
	String name;
	
	/**
	 * getter & setter to get and set values 
	 * @return
	 */

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	/**
	 * passing values to the constructor
	 * @param id
	 * @param age
	 * @param salary
	 * @param name
	 */
	public Employee(int id, int age, int salary, String name) {
		super();
		this.id = id;
		this.age = age;
		this.salary = salary;
		this.name = name;
	}
	


/**
 * overrriding toString method here
 */
@Override
public String toString(){
	return this.id+" "+this.age+" "+this.salary+" "+this.name;
}}
