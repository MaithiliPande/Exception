package startup;
import java.util.Scanner;

import employee.*;
import employeeservice.*;

public class Startup {
	
	
	public static void main(String[] args) {
		
//		Employee employee = new Employee(101, 22, 5000, "mayank");
		
//		System.out.println(employee.getName());
		EmployeeService employeeservice = new EmployeeService();
//		employeeservice.addNew(employee);		
		String cont;
	
		/**
		 * do while loop alongwith switch to show menu & switch to function according to user choice
		 */
do{
	 System.out.println("main menu");
	 System.out.println("0.Add new ");
     System.out.println("1.show all");
     System.out.println("2.exit");
     
     System.out.println("Enter your Choice ");
      int choice;
      /**
       * scanner to get user choice
       */
      Scanner scan = new Scanner(System.in);
      choice= scan.nextInt();
      /**
       * functioning according to selected choice
       * 0. add
       * 1.show
       * 2.exit
       */
      switch(choice){
      case 0:{
    	  System.out.println("enter id ");
    	  int id = scan.nextInt();
    	  
    	  System.out.println("enter age ");
    	  int age = scan.nextInt();
    	  
    	  System.out.println("enter salary ");
    	  int salary = scan.nextInt();
    	  
    	  System.out.println("enter name ");
    	  String name = scan.nextLine();
    	  Employee emp= new Employee(id, age, salary, name);
    	  employeeservice.addNew(emp);
    	  
      scan.next();}
      break;
      
      case 1:{
    	    Employee [] employee = employeeservice.listEmployees();
    	  for(int i=0;i<employee.length;i++){
    		  System.out.println(employee[i]);
      }}
    	  break;
      case 2:
      {
    	  System.exit(0);
      }
      break;
      
      default:System.out.println("invalid Choice");
     
      }
    	  System.out.println("enter yes to continue");
    	  cont=scan.next();
}while(cont.equalsIgnoreCase("yes"));

	}	
}
	

