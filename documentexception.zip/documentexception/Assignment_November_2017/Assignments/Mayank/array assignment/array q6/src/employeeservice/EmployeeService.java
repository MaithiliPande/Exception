package employeeservice;

import employee.Employee;

public class EmployeeService {
	
	
	/**
	 * creatring an employee array with 10 size to store values for 10 employees
	 */
	private Employee[] employeerepository = new Employee[10];
	private int  location=0;
	
	/**
	 * adding new employee here
	 * @param employee
	 */
	public void  addNew(Employee employee){
		
	System.out.println(employee.getName());
	  employeerepository[location++]=employee;
//		System.out.println(employeerepository[0].getName());
		
	}
	
	/**
	 * savin the stored values into temp array of employee type & returning it
	 * @return
	 */
	public Employee[] listEmployees(){
		Employee[] temp = new Employee[location];
		for(int i=0;i<location;i++){
			temp[i]=employeerepository[i];
		}return temp;
	}
	 }
