package service;
/*
 * This will have repository of employee and it will provide the service for adding an employee and listing it.
 * @author maithili.pande
 */

import model.Employee;

public class EmployeeService {
	
		private Employee[] empRepository;
		int location;
		 public EmployeeService()
		 {
			location =0;
			empRepository =new Employee[10];
		 }
		 public void addEmployee(Employee employee) {
			 empRepository[location++]=employee;
		
	}
		 public Employee[] listEmployee()
		 {
			 Employee [] temp=new Employee[location];
			 for(int i=0;i<location;i++)
			 {
				 temp[i]=empRepository[i];
				 
			 }
			 return temp;
		 }

}
