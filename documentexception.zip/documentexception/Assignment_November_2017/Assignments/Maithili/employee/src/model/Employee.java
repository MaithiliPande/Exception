package model;
/*
 * Model will represent the data of an employee
 * @author maithili.pande
 */

public class Employee {
	/*
	 * id of an employee
	 */
	int id;
	/*
	 * name of an employee
	 */
	String name;
	/*
	 * salary of an employee
	 */
	int salary;
	/*
	 * age of an employee
	 */
	int age;
	/*
	 * This will set employee's details by parameterised constructor
	 * @param id
	 * @param salary
	 * @param name
	 * @param age
	 */
	public void setId(int id) {
		this.id = id;
	}
	public int getId() {
		return id;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	public String getName() {
		return name;
	}
	
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public int getSalary() {
		return salary;
	}
	
	public void setAge(int age) {
		this.age = age;
	}
	public int getAge() {
		return age;
	}
	@Override
	public String toString() {
		return this.id+" "+this.name+" "+this.salary+" "+this.age;
	}

}
