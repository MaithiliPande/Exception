package largestnumber;

import java.util.Scanner;
/**
 * This class provides the logic for finding largest number and its index in an array.
 * @author maithili.pande
 *
 */
public class LargestNumber {
	public static void main(String [] args)
	{
		
		int arr[]=null;
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter size of array:");
		int size=sc.nextInt();
		LargestNumber max=new LargestNumber();
		int [] result=max.maxInt(arr,size);
		
			System.out.println("Largest number: "+result[0]);
			System.out.println("Index of largest number: "+result[1]);
		
		
	
	}
	/**
	 * This method will take input an array from user and find largest number and its index.It takes array address
	 * and array size as parameters.
	 * @param array
	 * @param arrSize
	 * @return
	 */
	public int[] maxInt(int[] array,int arrSize) {
		int largeIndex=0,large=0;
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		array=new int[arrSize];
		System.out.println("Enter "+arrSize+" elements");
		for(int i=0;i<arrSize;i++)
		{
			array[i]=sc.nextInt();
		}
		
		
		/*finding largest number*/
		for(int i=0;i<arrSize;i++)
		{
			if(large<=array[i])
			{
				large=array[i];
				largeIndex=i;
			}
		}
		int []res=new int[2];
		res[0]=large;
		res[1]=largeIndex;
		
		return res;
		
	}
	
}
