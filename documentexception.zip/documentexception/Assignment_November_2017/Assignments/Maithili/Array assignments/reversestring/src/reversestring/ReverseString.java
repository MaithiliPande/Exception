package reversestring;
/**
 * This class provides logic to reverse a string.
 * @author maithili.pande
 *
 */
public class ReverseString {

	public static void main(String[] args) {
		String str="Able was I era I saw elba";
		
		char[] ch=str.toCharArray();
		System.out.println(ch);
		char[] revCh=new char[ch.length];
		//System.out.println(ch.length);
		//System.out.println(revCh.length);
	
		for(int i=ch.length-1; i>=0 ;)
		{
			for(int j=0;j<revCh.length; j++)
			{
				revCh[j]=ch[i--];
			}
		}
		//System.out.println(revCh);
		String revStr=new String(revCh);
		System.out.println("Reverse String: "+revStr);
				
		

	}
}
