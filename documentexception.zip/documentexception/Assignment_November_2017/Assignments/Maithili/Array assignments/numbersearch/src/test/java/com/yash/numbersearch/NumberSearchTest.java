package com.yash.numbersearch;

import org.junit.Test;

import junit.framework.TestCase;
/**
 * This class tests NumberSearch class.
 * @author maithili.pande
 *
 */
public class NumberSearchTest extends TestCase {

	@Test
	public void test_for_ten_digits()
	{
		NumberSearch ns=new NumberSearch();
		int searchedElement=ns.inputArray();
		assertEquals(1, searchedElement);
	}

/*	@Test
	public void test_for_negative_number()
	{
		NumberSearch ns=new NumberSearch();
		int searchedElement=ns.inputArray();
		assertEquals(0, searchedElement);
	}*/
}
	
