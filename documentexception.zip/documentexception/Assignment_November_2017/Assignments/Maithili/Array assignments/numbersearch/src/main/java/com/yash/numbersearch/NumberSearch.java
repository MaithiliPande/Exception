package com.yash.numbersearch;

import java.util.Scanner;

import junit.framework.TestCase;
/**
 * This class provides method to input an array and search a given element.
 * @author maithili.pande
 *
 */
public class NumberSearch extends TestCase {
	public int inputArray()
	{
		
		int [] arr=new int[10];
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter 10 elements: ");
		for(int i=0;i<10;i++)
		{
			arr[i]=sc.nextInt();
		}
		System.out.println("Enter element to search: ");
		int element=sc.nextInt();
		int count=0;
		if(element<0) {
			System.out.println("Enter positive number");
			return 0;
		}
		else {
		for(int i=0;i<10;i++)
		{
			if(arr[i]==element)
			{
				count++;
			}
		}
		System.out.println("No. of times element appears: "+count);
		return count;
		}
	}

}
