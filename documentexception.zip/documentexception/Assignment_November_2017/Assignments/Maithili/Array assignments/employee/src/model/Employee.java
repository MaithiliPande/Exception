package model;

//import java.util.regex.Matcher;
//import java.util.regex.Pattern;

/**
 * Model will represent the data of an employee
 * @author maithili.pande
 */

public class Employee {
	/**
	 * id of an employee
	 */
	int id;
	/**
	 * name of an employee
	 */
	String name;
	/**
	 * salary of an employee
	 */
	int salary;
	/**
	 * age of an employee
	 */
	int age;
	/**
	 * id of an employee to delete
	 */
	int delId;
	/**
	 * This will set employee's details by parameterised constructor
	 * @param id
	 * @param salary
	 * @param name
	 * @param age
	 */
	public void setId(int id) {
		this.id = id;
	}
	public int getId() {
		return id;
	}
	
	public void setName(String name) {
		
		//Pattern p=Pattern.compile("\\D");
		//Matcher m=p.matcher(name);
		//int beginIndex;
		//boolean b;
		//while(m.find())
		//{
		//	 beginIndex=m.start();
		//	 System.out.println(beginIndex);
		//	 
		//}
		//do
		//{
		//	System.out.println("Please enter valid name");
			this.name = name;
			
		//}
		//while();
		
		
	}
	public String getName() {
		return name;
	}
	
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public int getSalary() {
		return salary;
	}
	
	public void setAge(int age) {
		this.age = age;
	}
	public int getAge() {
		return age;
	}
	public void setDelId(int delId) {
		this.delId = delId;
	}
	public int getDelId() {
		return delId;
	}
	@Override
	public String toString() {
		return this.id+" "+this.name+" "+this.salary+" "+this.age;
	}
	

}
