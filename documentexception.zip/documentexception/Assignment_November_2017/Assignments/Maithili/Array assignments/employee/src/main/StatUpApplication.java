package main;

import java.util.Scanner;
//import java.util.regex.Matcher;
//import java.util.regex.Pattern;

import model.Employee;
import service.EmployeeService;

public class StatUpApplication {
	public static void main(String [] args) {
		Scanner sc= new Scanner(System.in);
		EmployeeService service=new EmployeeService();
		int choice;
		String continueChoice;
		do
		{
			System.out.println("Main Menu");
			System.out.println("Enter a choice"+"\n1. Add Employee"+"\n2. List Employee"+"\n3. Delete");
			choice=sc.nextInt();
			switch(choice) 
			{
			case 1: 
					Employee emp=new Employee();
					System.out.println("\nEnter Employee ID:");
					int id=sc.nextInt();
					emp.setId(id);
					System.out.println("\nEnter Employee name");
					String name=sc.next();
					emp.setName(name);
					System.out.println("\nEnter Employee salary:");
					int salary=sc.nextInt();
					emp.setSalary(salary);
					System.out.println("\nEnter Employee age:");
					int age=sc.nextInt();
					emp.setAge(age);
					service.addEmployee(emp);
					break;
			case 2: Employee[] empList=service.listEmployee();
					for(int i=0;i<empList.length;i++)
					{
						System.out.println(empList[i]);
					}
					break;
			case 3:
					System.out.println("Enter Employee id to delete Employee");
					int delId=sc.nextInt();			
					service.deleteEmployee(delId);
					break;
			default: System.out.println("Invalid choice");
					break;
			
			
			}
			System.out.println("\nDo you want to continue : y/n");
			continueChoice=sc.next();
		}
		
		
		while(continueChoice.equalsIgnoreCase("y"));
		
		
		
	}

}
