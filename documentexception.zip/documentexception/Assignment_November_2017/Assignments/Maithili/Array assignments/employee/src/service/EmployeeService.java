package service;
/**
 * This will have repository of employee and it will provide the service for adding an employee and listing it.
 * @author maithili.pande
 */

import model.Employee;

public class EmployeeService {
	
		private Employee[] empRepository;
		int location;
		 public EmployeeService()
		 {
			location =0;
			empRepository =new Employee[2];
		 }
		 public void addEmployee(Employee employee) {
			 
				 empRepository[location++]=employee;
			
	}
		 public Employee[] listEmployee()
		 {
			 Employee [] temp=new Employee[location];
			 if(location<=0)
			 {
				 System.out.println("No record");
				 return  temp;
			 }
			 else {
				 
				 for(int i=0;i<location;i++)
				 {
					 temp[i]=empRepository[i];
					 
				 }
				 return temp;
			 }
			 
		 }
		 public int deleteEmployee(int delId) {
			 if(location<=0)
			 {
				 System.out.println("Employee array is empty.Cannot delete");
				 return 0;
			 }
			 else
			 {
				 for(int i=0; i<empRepository.length; i++)
				 {	
					 //System.out.println(empRepository[0]);
					 int resultID = empRepository[i].getId();
					 //System.out.println("id ="+empRepository[i].getId());
					 if(resultID == delId)
					 {
						 for(int j=i; j<empRepository.length-1; j++)
						 {
							 empRepository[j]=empRepository[j+1];
							 //System.out.println(empRepository[j]);
						 }
						 location--; 
					 }
				 }
				 System.out.println("Employee deleted");
				 return 0;
			 }
		 }
		 
		

}
