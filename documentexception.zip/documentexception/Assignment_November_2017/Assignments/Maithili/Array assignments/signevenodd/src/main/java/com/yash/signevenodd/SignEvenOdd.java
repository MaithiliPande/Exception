package com.yash.signevenodd;

import static org.junit.Assert.*;

import org.junit.Test;
/**
 * This class provides a function to count number of positive, negative, even and odd number in an array.
 * @author maithili.pande
 *
 */
public class SignEvenOdd {
	public int[] findCountEvenOdd(int arr []) {
		
		int countEven=0;
		int countOdd=0;
		int countPos=0;
		int countNeg=0;
		for(int i=0;i<15;i++)
		{
			
			if(arr[i]%2==0)
			{
				countEven++;
			}
			if(arr[i]%2!=0)
			{
				countOdd++;
			}
			if(arr[i]>0)
			{
				countPos++;
			}
			if(arr[i]<0)
			{
				countNeg++;
			}
		 
		}
		System.out.println("Even:"+countEven+" Odd:"+countOdd+" Positive:"+countPos+" Negative:"+countNeg);
		int expArr[]=new int[4];
		expArr[0]=countEven;
		expArr[1]=countOdd;
		expArr[2]=countPos;
		expArr[3]=countNeg;
		
		return expArr;

	}
	

}
