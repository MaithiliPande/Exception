package com.yash.signevenodd;

import static org.junit.Assert.*;

import org.junit.Test;
/**
 * This is a test class that tests actual result of the method with expected result.
 * @author maithili.pande
 *
 */
public class SignEvenOddTest 
{
	
	int array[]= {22,23,45,-34,27,69,-412,45,-7,-3,87,56,78,11,12};

	@Test
	public void test() {
	   SignEvenOdd obj=new SignEvenOdd();
	   int[] result=obj.findCountEvenOdd(array);
	   int [] expected= {6,9,11,4};
	   assertArrayEquals(expected, result);
	   
	   
	}

}

