package reversearray;

import java.util.Scanner;
/**
 * This class provides method to reverse an array.
 * @author maithili.pande
 *
 */
public class reverseMain {

	public static void main(String[] args) {
		int [] arr=new int[5];
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		System.out.println("Ente array :");
		for(int i=0;i<5;i++)
		{
			arr[i]=sc.nextInt();
		}
		
		int revArr[]=new int[5];
		for(int i=4;i>=0;)
		{
			for(int j=0;j<5;j++)
			{
				revArr[j]=arr[i--];
			}
		}
		System.out.println("Reversed array :");
		for(int i=0;i<5;i++)
		{
			System.out.println(revArr[i]);
		}
		

	}

}
