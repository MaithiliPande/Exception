package transpose;

import java.util.Scanner;
/**
 * This class provides method to transpose given matrix
 * @author maithili.pande
 *
 */
public class TransposeMatrix {
	public static void main(String [] args) {
		int [][] matrix=new int[4][4];
		@SuppressWarnings("resource")
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter  matrix:");
		for(int i=0;i<4;i++)
		{
			for(int j=0;j<4;j++)
			{
				matrix[i][j]=sc.nextInt();
			}
		}
		
		/**
		 * This loop has logic to swap the values of rows and columns.
		 */
		int temp=0;
		for(int i=0;i<4;i++)
		{
			for(int j=i;j<4;j++)
			{
				temp=matrix[i][j];
				matrix[i][j]=matrix[j][i];
				matrix[j][i]=temp;
				
			}
		
			
		}
		System.out.println("Transpose : ");
		
		for(int i=0;i<4;i++)
		{
			for(int j=0;j<4;j++)
			{
				System.out.print(matrix[i][j]+" ");
			}
			System.out.println("");
		}
	}
	
	

}
