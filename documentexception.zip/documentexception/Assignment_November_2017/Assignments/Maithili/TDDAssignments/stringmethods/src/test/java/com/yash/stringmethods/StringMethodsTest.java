package com.yash.stringmethods;

import static org.junit.Assert.assertArrayEquals;

//import static org.junit.Assert.assertArrayEquals;

import org.junit.Test;

import junit.framework.TestCase;

public class StringMethodsTest extends TestCase {
	private String str1="apple";
	private String str2="mango";
	private String str3="An apple a day keeps the doctor away";
	private String str4= new String("mango");
	private String str5="CHERRY";
	private String str6="Hello Everyone ";
	
	
	@Test
	public void testCharAt() 
	{
		//StringMethods method=new StringMethods();
		char result= str1.charAt(2);
		assertEquals('p', result);
	}
	@Test
	public void testConcat() 
	{
		String result= str1.concat(str2);
		assertEquals("applemango", result);
	}
	@Test
	public void testContains() 
	{
		boolean result= str3.contains("doctor away");
		assertEquals(true, result);
	}
	@Test
	public void testEndsWith() 
	{
		boolean result= str3.endsWith("doctor away");
		assertEquals(true, result);
	}
	@Test
	public void testEquals() 
	{
		boolean result= str3.equals(str2);
		assertEquals(false, result);
	}
	@Test
	public void testEqualsIgonreCase() 
	{
		boolean result= str2.equalsIgnoreCase("MANGO");
		assertEquals(true, result);
		boolean result2=str2.equalsIgnoreCase("str1");
		assertEquals(false,result2);
		
	}
	@Test
	public void testIntern() 
	{
		boolean result= str2.intern()==str4.intern();
		
		assertEquals(true, result);
	}
	@Test
	public void testIndexOf() 
	{
		int result= str1.indexOf("l");
		assertEquals(3, result);
	}
	@Test
	public void testLastIndexOf() 
	{
		int result= str3.lastIndexOf("o");
		assertEquals(29, result);
	}
	@Test
	public void testLength() 
	{
		int result= str3.length();
		assertEquals(36, result);
	}
	@Test
	public void testReplace() 
	{
		String result= str1.replace("p","P");
		assertEquals("aPPle", result);
	}
	@Test
	public void split() 
	{
		String[] result= str6.split("\\s");
		String expected[]=new String[2];
		expected[0]="Hello";
		expected[1]="Everyone ";
	    assertArrayEquals(expected, result);
	}
	@Test
	public void testSubstring() 
	{
		String result= str3.substring(2,7);
		
		assertEquals(" appl", result);
	}
	@Test
	public void testLowerCase() 
	{
		String result= str5.toLowerCase();
		
		assertEquals("cherry", result);
	}
	@Test
	public void testUpperCase() 
	{
		String result= str2.toUpperCase();
		
		assertEquals("MANGO", result);
	}
	@Test
	public void testTrim() 
	{
		String result= str6.trim();
		
		assertEquals("Hello Everyone", result);
	}
	@Test
	public void testValueOf() 
	{
		int value=37;  
		String s1=String.valueOf(value); 
		assertEquals("37", s1);
	}
	
	 

}
