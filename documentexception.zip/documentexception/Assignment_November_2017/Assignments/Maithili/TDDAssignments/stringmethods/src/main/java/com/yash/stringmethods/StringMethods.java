package com.yash.stringmethods;

import junit.framework.TestCase;

public class StringMethods extends TestCase {
//	public  char stringMethod(String input)
//	{


//		char str1=input.charAt(0);
//		System.out.println(str1);
//		return str1;
//	}

}
