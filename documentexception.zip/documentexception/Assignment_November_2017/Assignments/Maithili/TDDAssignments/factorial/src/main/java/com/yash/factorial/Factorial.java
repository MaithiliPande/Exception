package com.yash.factorial;

import java.math.BigInteger;

import junit.framework.TestCase;

public class Factorial extends TestCase {
	public BigInteger facto(Integer input)
	{
		if(input==null||input<0)
		{
			return null;
		}
		else if(input==0)
		{
				return BigInteger.ONE;
		}
		else if(input==1)
		{
			return BigInteger.ONE;
		}
		else
		{
			//return 120;
			BigInteger fact=new BigInteger("1");
			System.out.println(input);
			for(int i=input ; i>=1 ; i--) 
			{
				fact=fact.multiply(BigInteger.valueOf(i));
				System.out.println(fact);
				
			}
			return fact;
		}
	}
	

}
