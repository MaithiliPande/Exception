package com.yash.factorial;

import java.math.BigInteger;

import org.junit.Before;
import org.junit.Test;

import junit.framework.TestCase;

public class factorialTest extends TestCase {
	private static final int ANY_POSITIVE_INTEGER=5;
	private Factorial factorial;
	@Before
	public void setUp() throws Exception
	{
		factorial=new Factorial();
	}
	@Test
	public void test_empty() throws Exception
	{
		//Factorial factorial=new Factorial();
		BigInteger result=factorial.facto(null);
		assertEquals(null,result);
	}
	@Test
	public void test_for_input_zero() throws Exception
	{
		//Factorial factorial=new Factorial();
		BigInteger result=factorial.facto(0);
		assertEquals("1",result.toString());
	}
	@Test
	public void test_for_input_one() throws Exception
	{
		//Factorial factorial=new Factorial();
		BigInteger result=factorial.facto(1);
		assertEquals("1",result.toString());
	}
	@Test
	public void test_for_any_positive_input_number() throws Exception
	{
		//Factorial factorial=new Factorial();
		BigInteger result=factorial.facto(ANY_POSITIVE_INTEGER);
		assertEquals("120",result.toString());
	}
	
	
	

}
