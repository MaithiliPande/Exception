package com.yash.sumexpress;

import static org.junit.Assert.*;

import org.junit.Test;

public class SumExpressionTest {

	@Test
	public void test_empty_expression() 
	{
		
		SumExpression sumexpr=new SumExpression();
		int result=sumexpr.add("");
		assertEquals(0,result);
		
	}
	@Test
	public void test_for_expression() 
	{
		
		SumExpression sumexpr=new SumExpression();
		int result=sumexpr.add("2+3+4");
		assertEquals(9,result);
		
	}
	

}
