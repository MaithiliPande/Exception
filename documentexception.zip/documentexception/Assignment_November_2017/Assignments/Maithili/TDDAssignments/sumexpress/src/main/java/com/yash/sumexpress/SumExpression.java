package com.yash.sumexpress;

public class SumExpression {

	public int add(String input)
	{
		if(input.isEmpty())
		{
			return 0;
		}
		else if(input.indexOf("\\+")!=1)
		{
			String numbers[]=input.split("\\+");
			int sum=0;
			for(String strNumber:numbers)
			{
				sum+=Integer.parseInt(strNumber);
			}
			return sum;
		}
		else
		{
			return Integer.parseInt(input);
		}
	}

}
//else if(input.indexOf(",")!=1)
//	{
//	String inputs[]=input.split(",");
	//int sum=0;
	//for(String  stringNumber:inputs)
	//{
		//sum+=Integer.parseInt(stringNumber);
		
	//}
	//return sum;
//}
//else
//{
	//return Integer.parseInt(input);
//}