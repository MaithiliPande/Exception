package com.yash.evenodd;

import org.junit.Before;
import org.junit.Test;

import junit.framework.TestCase;

public class evenOddTest extends TestCase {
	private static final String ANY_VALID_STRING_AS_INPUT="23445788";
	private Even evenNumber;
	private Odd oddNumber;
	@Before
	public void setUp() throws Exception
	{
		evenNumber= new Even();
		oddNumber= new Odd();
	}
	
	@Test
	public void test_empty() throws Exception
	{
		//Even evenNumber=new Even();
		long  evenResult=evenNumber.countEven("");
		assertEquals(0,evenResult);
		//Odd oddNumber=new Odd();
		long oddResult=oddNumber.countOdd("");
		assertEquals(0,oddResult);
		System.out.println(evenResult+" even numbers and "+oddResult+" odd numbers");
	}
	@Test
	public void test_for_any_number() throws Exception
	{
		//Even evenNumber=new Even();
		long evenResult=evenNumber.countEven(ANY_VALID_STRING_AS_INPUT);
		assertEquals(5,evenResult);
		//Odd oddNumber=new Odd();
		long oddResult=oddNumber.countOdd(ANY_VALID_STRING_AS_INPUT);
		assertEquals(3,oddResult);
		System.out.println(evenResult+" even numbers and "+oddResult+" odd numbers");
	}
	
	

}
