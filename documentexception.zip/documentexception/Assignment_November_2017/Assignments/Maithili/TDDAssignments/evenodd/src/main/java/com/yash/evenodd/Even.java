package com.yash.evenodd;



public class Even {
	public long  countEven(String input)
	{
		if(input.isEmpty())
		{
			return 0;
		}
		else
		{
			try 
			{
				long count=0;
				int stringLength=input.length();
				for(int i=0;i<stringLength;i++)
				{
					
					char c=input.charAt(i);
					if((Character.getNumericValue(c))%2==0)
							{
								count++;
								
							}
					
				}
				return count;
				
			}
			catch(Exception e)
			{
				System.out.println("Enter numeric string");
				return 0;
			}
		}

	}

}
