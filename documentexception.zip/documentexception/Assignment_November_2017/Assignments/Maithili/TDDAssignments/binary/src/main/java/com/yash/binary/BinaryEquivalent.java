package com.yash.binary;

import junit.framework.TestCase;

public class BinaryEquivalent extends TestCase {
	public int[] convert(int number)
	{
		int binary[]=new int[4];
		int index=0;
		if(number==0)
		{
			binary[0]=0;
			return binary;
		}
		else
		{
			while(number>0)
			{
				binary[index++]=number%2;
				number=number/2;
			}
			for(int i=index-1; i>=0; i--) 
			{
				System.out.println(binary[i]);
			}
			return binary;
		}
	}

}
