package com.yash.binary;

import static org.junit.Assert.assertArrayEquals;

import org.junit.Before;
import org.junit.Test;

import junit.framework.TestCase;

public class BinaryEqivalentTest extends TestCase {
	private static final int ANY_SINGLE_NUMBER_AS_INPUT=3;
	private BinaryEquivalent binEquivalent;
	@Before
	public void setUp() throws Exception
	{
		binEquivalent=new BinaryEquivalent();
	}
	@Test
	public void test_empty()
	{
		int[] result=binEquivalent.convert(0);
		int test[]= new int[4];
		test[0]=0;
		assertArrayEquals(test,result);
	}
	@Test
	public void test_for_single_input()
	{
		int[] result=binEquivalent.convert(ANY_SINGLE_NUMBER_AS_INPUT);
		int test[]=new int[4];
		test[0]=1;
		test[1]=1;
		test[2]=0;
		test[3]=0;
		assertArrayEquals(test,result);
		
	}

}
