package com.yash.divisiblebyseven;





public class DivisibleBySeven {
	public int calculate(int min,int max)
	{
		if(min>100 && max<200)
		{
			int sum=0;
			for(int num=min; num<=max; num++)
			{
				if(num%7==0)
				sum=sum+num;
			}
			return sum;
		}
		else
		{
			return 0;
		}
	}
	

}
