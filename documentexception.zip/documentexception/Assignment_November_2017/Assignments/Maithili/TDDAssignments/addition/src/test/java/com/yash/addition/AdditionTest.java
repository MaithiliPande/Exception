package com.yash.addition;

import org.junit.Before;
import org.junit.Test;

import junit.framework.TestCase;

public class AdditionTest extends TestCase {
	private Addition addition;
	@Before
	public void setUp() throws Exception
	{
		addition = new Addition();
	}
	@Test
	public void test_empty() throws Exception
	{
		//Addition addition = new Addition();
		int result= addition.add("");
		assertEquals(0,result);
	}
	//@Test
	//public void test_for_one_number() throws Exception
	//{
		//Addition addition = new Addition();
		//int result= addition.add("10");
		//assertEquals(10,result);
	//}
	@Test
	public void test_for_addition_of_consecutive_numbers() throws Exception
	{
		//Addition addition = new Addition();
		int result= addition.add("-1");
		assertEquals(35,result);
	}
	@Test
	public void test_for_string_input() throws Exception
	{
		//Addition addition = new Addition();
		int result= addition.add("abc");
		assertEquals(0,result);
	}
	

}
