package com.yash.addition;

import junit.framework.TestCase;

public class Addition extends TestCase {
	public int add(String input)
	{
		if(input.isEmpty())
		{
			return 0;
		}
		else
		{
			int sum=0;
			try
			{
				int number=Integer.parseInt(input);
				for(int i=0;i<10;i++)
				{
				
					System.out.println(number);
					sum=sum + number;
					number++;
					
				}
				return sum;
				
			}
			catch(Exception e)
			{
				System.out.println("Enter only numeric value");
				return 0;
			}
			
		
		}
	}

}
