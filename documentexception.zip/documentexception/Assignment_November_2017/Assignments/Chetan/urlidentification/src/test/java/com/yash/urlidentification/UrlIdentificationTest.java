package com.yash.urlidentification;

import static org.junit.Assert.*;

import org.junit.Test;

public class UrlIdentificationTest {
 
	@Test
	public void test_for_identification_normal_of_url_command_index() throws Exception {
		UrlIdentification url =new UrlIdentification();
		String result = url.getCommand("https://www.yash.com/index.jsp");
	    assertEquals("index", result);
	}
	@Test
	public void test_for_identification_normal_of_url_command_salary() throws Exception {
		UrlIdentification url =new UrlIdentification();
		String result = url.getCommand("https://www.yash.com/employee/salary.xhtml");
	    assertEquals("salary", result);
	}
	@Test
	public void test_for_identification_normal_of_url_command_listusers() throws Exception {
		UrlIdentification url =new UrlIdentification();
		String result = url.getCommand("https://www.google.com/searches/searchdata.jsp");
	    assertEquals("searchdata", result);
	}
}
