package yash.com.documentdemo.main;
/**
 * application start from here
 */

import java.util.Scanner;

import yash.com.documentdemo.documentservice.DocumentService;
import yash.com.documentdemo.exception.InvalidDocumentTypeException;
import yash.com.documentdemo.model.Document;

public class StartDocumentApplication {
	
	public static void main(String[] args) {
		Scanner scan= new Scanner(System.in);
		DocumentService documentService=new DocumentService();
		String conti;
		documentService.addDocumentToRepository(101,"java","educational","this document is about java"); 
		documentService.addDocumentToRepository(102,"c/cpp","educational","this document is about c/cpp"); 
		documentService.addDocumentToRepository(103,"Dairy","personal","this document is about personal Dairy"); 
		documentService.addDocumentToRepository(104,"office doc","company","this document is about office"); 
		documentService.addDocumentToRepository(105,"Adhar card","personal","this document is about Adhar card"); 
		documentService.addDocumentToRepository(106,"Service Agreement","company","this document is about company Service Agreement"); 
		documentService.addDocumentToRepository(107,"Salary Recipt","company","this document is about Company Salary Recipt"); 
		documentService.addDocumentToRepository(108,"PAN card","personal","this document is about PAN card"); 
		documentService.addDocumentToRepository(109,"Attendance","company","this document is about Company");
		documentService.addDocumentToRepository(110,"python","educational","this document is about python"); 
		
		/**
		 * menu start from here
		 */
		do{
			System.out.println("*******Main*******");
			System.out.println("1.Get Document by type");
			System.out.println("0.Exit");
			System.out.println("Enter Your choice...");
			int choice=scan.nextInt();
			switch(choice){
			case 1:{System.out.println("Enter Document type (personal/educational/company) :");
			        try{
			        Document list[]=documentService.getDocumentByType(scan.next());
			        for(int i=0;i<list.length;i++)
			        {  if(list[i]==null) {continue;}
			        	System.out.println(list[i]);
			        }
			        }
			        catch(InvalidDocumentTypeException ex){System.out.println(ex.getMessage()); break;}
			        System.out.println("do you want to read any doucment mentioned above Enter id or Enter 0 to exit");
			        int read=scan.nextInt();
			        if(read!=0)
			        {
			        	String readDescription=documentService.getDocumentDescription(read);
			        	System.out.println(readDescription);
			        }
			} break;
			case 0:{System.exit(0);}
 			default:System.out.println("Invalid input");
			}
				System.out.println("Do yo want to continue...(y/n)");
				 conti=scan.next();
		}while(conti.equalsIgnoreCase("y"));
	}

}
