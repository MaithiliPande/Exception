package yash.com.documentdemo.model;
/**
 * this will store the document details 
 * @author chetan.magre
 *
 */
public class Document {
	/**
	 * id for document 
	 */
	int document_id;
	/**
	 * type of document
	 */
	String document_type;
    /**
     * title of document
     */
	String document_title;
	/**
	 * description of document
	 */
    String document_description;
	
    public int getDocument_id() {
		return document_id;
	}
	public String getDocument_type() {
		return document_type;
	}
	public String getDocument_title() {
		return document_title;
	}
	public String getDocument_description() {
		return document_description;
	}
    @Override
    public String toString() {
    	return "Document ID :"+this.getDocument_id()+" Document Title :"+this.getDocument_title()+" Document Type :"+this.getDocument_type();
    }
	public void setDocument_id(int document_id) {
		this.document_id = document_id;
	}
	public void setDocument_type(String document_type) {
		this.document_type = document_type;
	}
	public void setDocument_title(String document_title) {
		this.document_title = document_title;
	}
	public void setDocument_description(String document_description) {
		this.document_description = document_description;
	}
}
