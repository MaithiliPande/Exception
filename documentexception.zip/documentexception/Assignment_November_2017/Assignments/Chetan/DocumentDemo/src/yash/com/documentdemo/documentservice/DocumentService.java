package yash.com.documentdemo.documentservice;
/**
 * this will provide the document Repository and services 
 */
import yash.com.documentdemo.exception.InvalidDocumentTypeException;
import yash.com.documentdemo.model.Document;

public class DocumentService {
	/**
	 * document repository to store document object
	 */
 private Document documentRepository[];
 private int location;
 private int count;
 private Document documentList[];
 
 public DocumentService() {
	 documentRepository = new Document[10];
	 documentList=new Document[documentRepository.length];
	 location=0;
	 count=0;
}
 /**
  * this will add document details in the document Repository
  * @param id
  * @param title
  * @param docType
  * @param description
  */
 public void addDocumentToRepository(int id,String title,String docType,String description)
 {   Document document= new Document();
     document.setDocument_id(id);
     document.setDocument_title(title);
     document.setDocument_type(docType);
     document.setDocument_description(description);
	 documentRepository[location++]=document;
 }
 /**
  * this will return the list of documents asked, if not found throws exception
  * @param docType
  * @return
  * @throws InvalidDocumentTypeException
  */
 public Document[] getDocumentByType(String docType) throws InvalidDocumentTypeException
 {   
	 
	 int document_exist=0;
	 for(int i=0;i<location;i++)
     {if(documentRepository[i].getDocument_type().equalsIgnoreCase(docType.toLowerCase()))
       {  document_exist=1;}
     }
	 if(document_exist!=1)
	 {
		 throw new InvalidDocumentTypeException("Documnet type does Not exist");
	 }
	 else
     {
     for(int i=0;i<location;i++)
     {if(documentRepository[i].getDocument_type().equalsIgnoreCase(docType.toLowerCase()))
        {
	     documentList[count]=documentRepository[i];
	     count++;
        }
     }
	 }
	 return documentList;
 }
/**
 * this will return the document type and its description by its ID
 * @param read
 * @return
 */
public String getDocumentDescription(int read) {
	for(int i=0;i<count;i++)
	{
		if(documentList[i].getDocument_id()==read)
		{return "Dcoument Type: "+documentList[i].getDocument_type()+" Document Description :\n"+documentList[i].getDocument_description();}
	}
	return "Invalid Document ID";
}


}
