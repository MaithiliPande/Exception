package com.yash.stringtest;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestStringTest {
    String str ="Hello World";
    String str2="Hello WorLD";
	@Test
	public void test_for_charAt_method() {
		char result =str.charAt(6);
		assertEquals('W', result);
	}
	@Test
	public void test_for_concat_method() {
		String result =str.concat(str2);
		assertEquals("Hello WorldHello WorLD", result);
	}
	@Test
	public void test_for_cantains_method() {
		boolean result =str2.contains("Hello");
		assertEquals(true, result);
	}
	@Test
	public void test_for_endsWith_method() {
		boolean result =str.endsWith("World");
		assertEquals(true, result);
	}
	@Test
	public void test_for_equals_method() {
		boolean result =str.equals("Hello World");
		assertEquals(true, result);
	}
	@Test
	public void test_for_equalIgnoreCase_method() {
		boolean result =str.equalsIgnoreCase(str2);
		assertEquals(true, result);
	}
	@Test
	public void test_for_indexOf_method() {
		int result =str.indexOf('o');
		assertEquals(4, result);
	}
	@Test
	public void test_for_intern_method() {
		StringTest stringtest= new StringTest();
		boolean result=stringtest.getintern();	
		assertEquals(true, result);
	}
	@Test
	public void test_for_lastIndexOf_method() {
		int result =str.lastIndexOf('l');
		assertEquals(9, result);
	}
	@Test
	public void test_for_length_method() {
		int result =str.length();
		assertEquals(11, result);
	}
	@Test
	public void test_for_replace_method() {
		String result =str.replace('e', 'Y');
		assertEquals("HYllo World", result);
	}	
	@Test
	public void test_for_split_method_for_white_spaces() {
		String [] result =str.split("\\s");
		String [] ex = new String[2];
		ex[0]="Hello";
		ex[1]="World";		
		assertEquals(ex[0], result[0]);
		assertEquals(ex[1], result[1]);
	}
	@Test
	public void test_for_substring_method() {
		String result =str.substring(6);
		assertEquals("World", result);
	}

	@Test
	public void test_for_trim_method() {
		String str3=" hello world              ";
		String result =str3.trim();
		assertEquals("hello world", result);
	}
	@Test
	public void test_for_toLowerCase_method() {
		String result =str.toLowerCase();
		assertEquals("hello world", result);
	}
	@Test
	public void test_for_toUpperCase_method() {
		String result =str.toUpperCase();
		assertEquals("HELLO WORLD", result);
	}
	@Test
	public void test_for_valueOf_method() {
		String result =str.valueOf(30);
		assertEquals("30", result);
	}
}
