package com.yash.main.arraycarparking;

import java.util.Scanner;

import com.yash.model.arraycarparking.Car;
import com.yash.model.arraycarparking.Token;
import com.yash.service.arraycarparking.CarParking;

public class StartCarParkingApplication {
    private  static Scanner s;
	public static void main(String[] args) {
		CarParking parkingservice= new CarParking();
		String contin;
		s = new Scanner(System.in);
		do{
			System.out.println("*******Main*******");
			System.out.println("1.Park car");
			System.out.println("2.take out car");
			System.out.println("3.Show parked car details along with token");
			System.out.println("4.Show Parked cars count floorwise  ");
			System.out.println("0.Exit");
			
			System.out.println("Enter Your choice...");
			int choice=s.nextInt();
			switch(choice){
			case 1:{Car car = new Car();
			        System.out.println("Enter car's  Registration Number :");
			        car.setRegistrationno(s.nextInt());
			        System.out.println("Enter Car NAME");
			        s.nextLine();
			        car.setCarname(s.nextLine());
			        System.out.println("Enter Car owner Name");
			        car.setOwnername(s.nextLine());
       		        int token=parkingservice.parkACar(car); 
       		        System.out.println("your token is "+token);
			        
			} break;
			case 2:{System.out.println("Enter token Of car you want to remove");
			      	int token=s.nextInt();
			        String output=parkingservice.takeOutAcar(token);
			      		System.out.println(output);
			       }break;
			case 3:{ Token [] parkedcars=parkingservice.listParkedCar();
	      	         for(int i=0;i<parkedcars.length;i++)
	      	         { if(parkedcars[i]==null) {continue;}
	      	         else {System.out.println(parkedcars[i]);}
	      	         }
			       }break;
			case 4:{ parkingservice.showparkedCount();
			       }break;
			case 0:{System.exit(0);}
			default:System.out.println("Invalid input");
			}
				System.out.println("Do yo want to continue...(y/n)");
				 contin=s.next();
		}while(contin.equalsIgnoreCase("y"));
	}

}
