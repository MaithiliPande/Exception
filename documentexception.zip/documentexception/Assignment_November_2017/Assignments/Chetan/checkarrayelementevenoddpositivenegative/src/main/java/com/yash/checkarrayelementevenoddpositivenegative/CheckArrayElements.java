package com.yash.checkarrayelementevenoddpositivenegative;

public class CheckArrayElements {
	private int [] array= new int[]{1,2,3,4,5,0,-1,-2,-3,55,66,12,13,14,15};
	private int evp=0,odn=0;
	public int[] checkEvenAndOdd() {
		for(int i=0;i<array.length;i++)
		{  if(array[i]%2==0)
		 {	 evp++;
		 }else
		 { odn++; }	
		}
		int evenandodd[]={evp,odn};
		evp=0; odn=0;
		return evenandodd;
	}

	public int[] checkPositivieAndNegative() {
		for (int i : array) {
			if(i>=0)
			{evp++;}
			else{odn++;}
		}
		int posineg[]={evp,odn};
		return posineg;
	}

}
