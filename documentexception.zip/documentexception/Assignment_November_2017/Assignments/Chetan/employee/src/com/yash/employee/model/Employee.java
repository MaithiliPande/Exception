package com.yash.employee.model;
/**
 * this will have the employee details 
 * @author chetan.magre
 *
 */
public class Employee {
	/**
	 * id of employee
	 */
	private int id;
	/**
	 * name of employee
	 */
	private String name;
	/**
	 * salary of employee
	 */
	private int salary;
	/**
	 * age of employee
	 */
	private int age;
	
	public Employee(int id2, String name2, int salary2, int age2) {
		id=id2;
		name=name2;
		salary=salary2;
		age=age2;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	/**
	 * this will return required output
	 */
@Override
public String toString() {
	
	return "[id:"+this.getId()+" ,name :"+this.getName()+" ,salary :"+this.getSalary()+", age :"+this.getAge()+"]";
}
}
