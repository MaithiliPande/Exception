package com.yash.employee.main;
/**
 * this will start the application
 */
import java.util.Scanner;

import com.yash.employee.model.Employee;
import com.yash.employee.service.EmployeeService;

public class StartUpApplication {
	private static Scanner s;

	public static void main(String[] args) {
		EmployeeService employeeservice= new EmployeeService();
		String contin;
		s = new Scanner(System.in);
		do{
			System.out.println("*******Main*******");
			System.out.println("1.Add Data");
			System.out.println("2.list Data");
			System.out.println("0.Exit");
			
			System.out.println("Enter Your choice...");
			int choice=s.nextInt();
			switch(choice){
			case 1:{
			        System.out.println("Enter employee ID :");	
			        int id = s.nextInt();
			        System.out.println("Enter employee NAME");
			        String name=s.next();
			        System.out.println("Enter employee salary");
			        int salary =s.nextInt();
			        System.out.println("Enter employee age");
			        int age=s.nextInt();
			        
			        Employee emp=new Employee(id,name,salary,age);
			        employeeservice.addEmployee(emp); 
			        
			} break;
			case 2:{
			      	Employee[] employee=employeeservice.listEmployee();
			      	for(int i=0;i<employee.length;i++)
			      	{
			      		System.out.println(employee[i]);
			      	}
			       }break;
			case 0:{System.exit(0);}
			default:System.out.println("Invalid input");
			}
				System.out.println("Do yo want to continue...(yes/no)");
				 contin=s.next();
		}while(contin.equalsIgnoreCase("yes"));
	}

}
