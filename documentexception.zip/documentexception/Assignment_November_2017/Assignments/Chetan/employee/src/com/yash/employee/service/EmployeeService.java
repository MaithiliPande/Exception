package com.yash.employee.service;
/**
 * this will create object of employee and
 * this will provide repository for employee to provide services to employee
 */

import com.yash.employee.model.Employee;

public class EmployeeService {
 private Employee[] employeesrepository= new Employee[10];
 private int location;
 public EmployeeService()
 {  
	 location=0;
 }
 /**
  *this will store data of employees in repository
  * @param 
  */
public void addEmployee(Employee employee) {
	employeesrepository[location++]=employee;
}
/**
 * this will return list of employees from employee repository
 * @return
 */
public Employee[] listEmployee() {
	Employee [] emp=new Employee[location];
	for(int i=0;i<location;i++)
	{
		emp[i]=employeesrepository[i];
	}
	return emp;
}
}
