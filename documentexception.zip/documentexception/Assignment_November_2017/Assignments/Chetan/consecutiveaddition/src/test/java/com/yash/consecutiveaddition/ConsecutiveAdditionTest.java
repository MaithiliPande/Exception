package com.yash.consecutiveaddition;

import org.junit.Before;
import org.junit.Test;

import junit.framework.TestCase;

public class ConsecutiveAdditionTest extends TestCase {
	private ConsecutiveAddition consecutive;
	private static final String START_VALUE_TO_ADD_10CONSECUTIVE_NUMBER="abc";
	@Before
	public void setUp() throws Exception
	{
		consecutive= new ConsecutiveAddition();
	}
	
	@Test
	public void test_for_empty_input() throws Exception
	{   int result=consecutive.add("");
		assertEquals(0,result);
	}
	
	
	@Test
	public void test_for_return_sum_of_10consecutive_numbers() throws Exception
	{   Integer result = new Integer(consecutive.add(START_VALUE_TO_ADD_10CONSECUTIVE_NUMBER));
		assertEquals(new Integer(0),result);
	}
	
	  @Test
	  public void test_for_retrun_sum_of_10consecutive_numbers_from__negative_Number() throws Exception
	  {   int result=consecutive.add("-4");
	    System.out.println("total"+result);
	      assertEquals(5,result);
	  }

}
