package com.yash.consecutiveaddition;

import junit.framework.TestCase;

public class ConsecutiveAddition extends TestCase {
 	

	public Integer add(String input) {
		int input1;
	if(input.length()!=0)
      {
		try
	    {
		  input1=Integer.parseInt(input);
		  int count=input1,total_sum=0;
			 while(count<(input1+10))	
			 	{
				 	total_sum+=count;
				 	count+=1;
			 	}
			 return total_sum;
	     }
	     catch(NumberFormatException nfs)
	    {
		 return 0;
	    }
		catch(NullPointerException n)
		{
			return null;
		}
	  }else
	   {
		 return 0;
        }
	
	    }
		}
