package com.yash.evenodd;

import org.junit.Before;
import org.junit.Test;

import junit.framework.TestCase;

public class EvenOddTest extends TestCase {
	private EvenOdd evenodd;
	private static final Integer INPUT_VALUE_TO_CHECK_EVEN_AND_ODD_DIGITS_IN_STRING=1000000000;
	@Before
	public void setUp() throws Exception
	{
		 evenodd = new EvenOdd();
	}
//	@Test
//	public void test_for_empty_input_value() throws Exception
//	{    int[] result = new int[2]; 
//		 result = evenodd.evenandodd();
//		 System.out.println("even :"+result[0]);
//		 System.out.println("odd :"+result[1]);
//		 assertEquals(0, result[0]);
//		 assertEquals(0,result[1]);
//	}
	@Test
	public void test_for_single_digit_input_value() throws Exception
	{    int[] result = new int[2]; 
		 result = evenodd.evenandodd(0);
		 System.out.println("even :"+result[0]);
		 System.out.println("odd :"+result[1]);
		 assertEquals(1, result[0]);
		 assertEquals(0,result[1]);
	}
	@Test
	public void test_for_multi_digit_input_value() throws Exception
	{    int[] result = new int[2]; 
		 result = evenodd.evenandodd(1314346);
		 System.out.println("even :"+result[0]);
		 System.out.println("odd :"+result[1]);
		 assertEquals(3, result[0]);
		 assertEquals(4,result[1]);
	}
	@Test
	public void test_for_negitive_input_value() throws Exception
	{    int[] result = new int[2]; 
		 result = evenodd.evenandodd(-100000);
		 System.out.println("even :"+result[0]);
		 System.out.println("odd :"+result[1]);
		 assertEquals(5, result[0]);
		 assertEquals(1,result[1]);
	}
	@Test
	public void test_for_bigest_10digit_input_value1000000000() throws Exception
	{    int[] result = new int[2]; 
		 result = evenodd.evenandodd(INPUT_VALUE_TO_CHECK_EVEN_AND_ODD_DIGITS_IN_STRING);
		 System.out.println("even :"+result[0]);
		 System.out.println("odd :"+result[1]);
		 assertEquals(9, result[0]);
		 assertEquals(1,result[1]);
	}
	

}
