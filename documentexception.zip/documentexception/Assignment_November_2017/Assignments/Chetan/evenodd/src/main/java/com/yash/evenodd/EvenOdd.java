package com.yash.evenodd;

import junit.framework.TestCase;

public class EvenOdd extends TestCase {

	public int[] evenandodd(Integer input) {
		int[] count= new int[2];
		long a;
		if(input==null)
		{   count[0]=0;
		    count[1]=0;
			return count;
		}
		else
		{
		if(input>=0||input<0)
		{ if(input==0)
		    {
			  count[0]=1;
		      count[1]=0;
		      return count;
		     }
			while(input>0||input<0)
			{
			  a=input%10;
			  if(a%2==0)
			  {
				  count[0]+=1;
			  }else
			  {
				  count[1]+=1;
			  }
			  input/=10;
			}
		}
		return count;
		}
	}

}
