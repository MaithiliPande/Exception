package com.yash.service.arraylargestnumber;
/**
 * this will return the max value index of the array 
 * @author chetan.magre
 *
 */
public class ArrayLargestNumber {
/**
 * 
 * this will return the index of greatest integer from the input array
 * @param array
 * @param length
 * @return
 */
	public int maxInt(int[] array, int length) {
		int max=array[0];
		int  index=0;
		for(int i=0;i<length;i++)
		{
			if(max<array[i])
			{
				max=array[i];
				index=i;
			}
		}
		return index;
	}

}
