package com.yash.main.arraylargestnumber;
/**
 * this will show the greatest value from an array
 */
import java.util.Scanner;

import com.yash.service.arraylargestnumber.ArrayLargestNumber;

public class ArrayLargestNumberTest {

	public static void main(String[] args) {
		Scanner scan =new Scanner(System.in);
		int[] array= new int[]{10,60,22,56,0,97,55,63,45};
        ArrayLargestNumber arraylargenumber=new ArrayLargestNumber();
        int index =arraylargenumber.maxInt(array,array.length);
        System.out.println("The Greatest Number you Insert is :"+array[index]);
	}

}
