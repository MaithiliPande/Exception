package com.yash.searchanumberinarray;

import java.util.Scanner;

public class SearchInArray {

	public int searchArray(int element) {
		int array[]= new int[]{10,12,30,40,61,30,88,99,30,100};
		int count=0;
		for(int i=0;i<10;i++)
		{ if(element==array[i])
		  {
			count++;
	      }
			
		}
		if(count>0)
			{ System.out.println(element+" appeared "+count+" times");
			return count;
			}
		return 0;
	}

}
