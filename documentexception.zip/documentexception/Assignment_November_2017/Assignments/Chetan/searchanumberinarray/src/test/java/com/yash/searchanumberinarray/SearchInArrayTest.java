package com.yash.searchanumberinarray;

import static org.junit.Assert.*;

import org.junit.Test;

public class SearchInArrayTest {
     SearchInArray search= new SearchInArray(); 
	@Test
	public void test_case_for_search_of_element_in_array() throws Exception {
      int check=search.searchArray(30);
      assertEquals(3, check);
	}
	@Test
	public void test_case_for_count_element_Appered_multiple_times_in_array() throws Exception {
      int check=search.searchArray(30);
      assertEquals(3, check);
	}
}
