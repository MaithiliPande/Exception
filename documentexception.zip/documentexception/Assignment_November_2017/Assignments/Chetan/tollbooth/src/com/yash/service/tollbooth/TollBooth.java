package com.yash.service.tollbooth;
/**
 * this will count the cars crosses the tollBooth and calculate total cash collected 
 * @author chetan.magre
 *
 */

public class TollBooth {
	/**
	 * count of number of car 
	 */
	private int car;
	/**
	 * total cash collected 
	 */
	private double cash;
	private int paycar;
	private int nonpaycar;
	 public TollBooth() {
		car=0;
		cash=0.0;
		nonpaycar=0;
		paycar=0;
	}
	 /**
	  * this will count car and  add cash to total 
	  */
 public void payingCar() {
	car++;
	cash+=0.50;
	paycar++;
}
 /**
  * this will count the car which do not pay 
  */
 public void noPayCar()
 {   nonpaycar++;
	 car++;
 }
 /**
  * this will display total number of cars and total cash collected
  */
 public void display() {
	System.out.println("Total No. of cars are "+car);
	System.out.println("Total collection of Money "+cash);
}
 /**
  * shows the number of cars pays the toll
  */
public void onlyPayCarCount() {
	System.out.println("Total number of cars which paid the Toll "+paycar);
	
}
/**
 * shows the number of cars did not pays the toll
 */
public void onlyNonPayingCarCount() {
	System.out.println("Total number of cars which haven't paid the Toll "+nonpaycar);
	
}
}
