package com.yash.main.tollbooth;
/**
 * the application starts from here
 */

import java.util.Scanner;

import com.yash.service.tollbooth.TollBooth;

public class TollBoothStartUp {
	public static void main(String[] args) {
		String check;
		int choice;
		Scanner	scan = new Scanner(System.in);
		TollBooth tollbooth = new TollBooth();
		do
		{   System.out.println("***********MAIN***************");
		    System.out.println("1.Paying cars");
		    System.out.println("2.No Paying cars ");
		    System.out.println("3.All Cars count and total Cash collect ");
		    System.out.println("4.Total Paying cars");
		    System.out.println("5.Total Non Paying cars");
		    System.out.println("0.Exit");
		    System.out.println("Enter your choice...");
		    choice=scan.nextInt();
		    switch (choice) {
			case 1:{tollbooth.payingCar();}break;
			case 2:{tollbooth.noPayCar();}break;	
			case 3:{tollbooth.display();}break;
			case 4:{tollbooth.onlyPayCarCount();}break;
			case 5:{tollbooth.onlyNonPayingCarCount();}break;
			case 0:{System.exit(0);}
			default:System.out.println("Invalid Choice");
				break;
			}
			System.out.println("Do you want to Continue...(y/n)");
			check=scan.next();
		}while(check.equalsIgnoreCase("y"));

	}

}
