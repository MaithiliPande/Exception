public class Url {
	public static void main(String[] args) throws Exception
	{
	   FrontController fc = new FrontController();
	   fc.geturl("http://www.yash.com/user/salary.do");
	   fc.geturl("https://www.yash.com/index.htm");
	   fc.geturl("www.yash.com/admin/listuser.htm");
	}

}
