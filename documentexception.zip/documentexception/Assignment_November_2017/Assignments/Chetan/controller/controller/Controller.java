
public interface Controller {
	
	public static Controller getcontroller(String name)
	{  
		if(name.equals("salary"))
		 { Controller conS = new SalaryController().getcontroller(name);;
	       return conS;
		 }
		else
		if(name.equals("index"))
		 { Controller	conH = new HomeController().getController(name);
			return conH;
		 }
		else
		{  if(name.equals("listuser"))
			{Controller conA = new AdminController().getcontroller(name);;
			return conA;
			}
		return null;
		}
				 
	}
	public void activate();

}
