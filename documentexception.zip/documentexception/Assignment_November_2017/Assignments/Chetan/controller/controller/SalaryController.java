
public class SalaryController implements Controller
{
   
	public Controller getcontroller(String name) {
		 SalaryController sal = new SalaryController(); 
		System.out.println("Control type is "+name);
		return sal;
	}

	@Override
	public void activate() {
		System.out.println("Salary controller is activated");
		
	}

}
