package com.yash.sumofnumberbetween100and200;

import static org.junit.Assert.*;

import org.junit.Test;

public class SumOfNumberTest {

	@Test
	public void test_to_return_sum_of_all_number_divisible_by7() {
		SumOfNumber sumofnumber= new SumOfNumber();
		int result=sumofnumber.getSumOfnumberBetween100and200();
		assertEquals(2107, result);
	}

}
