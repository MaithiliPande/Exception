package com.yash.main.revreseitstring;
/**
 * this will reverse the given user input string
 * and will show the reversed string
 */
import java.util.Scanner;

import com.yash.service.revreseitstring.ReverseIT;

public class ReverseItTest {
	
	public static void main(String[] args) {
	 Scanner scan = new Scanner(System.in);
	 String str="talented";
	 System.out.println("Enter a string to reverse ");
	 String input=scan.nextLine();
	 System.out.println("default String is :"+str);
	 ReverseIT reverse=new ReverseIT();
	 String revstr =reverse.reverseIt(str);
	 String reverseodinput =reverse.reverseIt(input);
	 System.out.println("reversed Default String is :"+revstr);
	 System.out.println("reversed input String is :"+reverseodinput);
}
}
