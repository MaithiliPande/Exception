package com.yash.main.arrayreverse;
/**
 * start of application it will print reverse of array
 */

import com.yash.service.arrayreverse.ReverseOfArray;

public class ArrayReverse {	
	public static void main(String[] args) {
		 int [] array= new int[]{1,2,3,4,5,6,7,8,9};
		ReverseOfArray areverse=new ReverseOfArray();
		 System.out.println("before reverse");
	    for (int i : array) {
		System.out.print(i+"  ");
     	}
	    System.out.println("\nAfter Reverse");
	    int [] newarray=areverse.reverse(array);
	    for (int i : newarray) {
			System.out.print(i+"  ");
		}
	}
}
