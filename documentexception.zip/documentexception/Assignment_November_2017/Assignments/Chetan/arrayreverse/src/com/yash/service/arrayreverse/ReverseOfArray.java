package com.yash.service.arrayreverse;
/**
 * this will return the reverse array to main
 * @author chetan.magre
 *
 */
public class ReverseOfArray {

	public int[] reverse(int[] array) {
		int a[]=new int[array.length];
		int i=0;
		int j=array.length-1;
		while(i<array.length)
		{
			a[i]=array[j];
			i++;j--;
		}
		return a;
	}

}
