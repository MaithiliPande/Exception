
package com.yash.binaryequant;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class BinaryEquantTest {
	private BinaryEquant binary;
	@Before
    public void setUp() throws Exception
    {
    	binary= new BinaryEquant();
    }
	@Test
	public void test_for_return_binary_of0() throws Exception 
	{
		String result = binary.calculateBinary(0);
		assertEquals("0",result);		
	}
	@Test
	public void test_for_return_binary_of1() throws Exception 
	{
		String result = binary.calculateBinary(1);
		assertEquals("1", result);
	}
	
	@Test
	public void test_for_return_binary_of2() throws Exception 
	{
		String result = binary.calculateBinary(2);
		assertEquals("10", result);
    }
	@Test
	public void test_for_return_binary_of100() throws Exception 
	{
		String result = binary.calculateBinary(100);
		assertEquals("1100100", result);
	}
	@Test
	public void test_for_return_binary_of999() throws Exception 
	{
		String result = binary.calculateBinary(999);
		assertEquals("1111100111", result);
	}
	}
	
