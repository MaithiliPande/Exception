package employee.yash.service;
/**
 * this will create employee repository and it will provide service for adding the employee and listing it.
 * @author ayushi.jain
 */

import employee.yash.model.Employee;

public class EmployeeService 
{
	private Employee[] employeeRepository=new Employee[10];
	int location=0;
	
	public void addEmployee(Employee employee)
	{
		employeeRepository[location++]=employee;
	}
	public Employee[] listEmployee() {
		Employee[] temp=new Employee[location];
		for(int i=0; i<location; i++)
		{
			temp[i]=employeeRepository[i];
		}
		return temp;
	}
	
}
