package employee.yash.main;

import java.util.Scanner;

import employee.yash.model.Employee;
import employee.yash.service.EmployeeService;

public class StartupApplication 
{
	public static void main(String args[])
	{
		EmployeeService service= new EmployeeService();
		Employee emp;
		Scanner sc=new Scanner(System.in);
		String continueChoice;
		do
		{	
			System.out.println("Menu");
			System.out.println("enter your choice");
			System.out.println("press 1 for adding employee");
			System.out.println("press 2 for displaying employee");
			System.out.println("press 3 for exit");
			int choice=sc.nextInt();
			
		switch(choice)
		{
			case 1: 
				emp=new Employee();
				System.out.println("enter id");
					int id=sc.nextInt();
					emp.setId(id);
					System.out.println("enter name");
					String name=sc.next();
					emp.setName(name);
					System.out.println("enter salary");
					int salary=sc.nextInt();
					emp.setSalary(salary);
					System.out.println("enter age");
					int age=sc.nextInt();
					emp.setAge(age);
					service.addEmployee(emp);
					break;	
			case 2: Employee []employee=service.listEmployee();
					for(int i=0; i<employee.length; i++)
					{
						System.out.println(employee[i]);
					}
			}
		System.out.println("Do you want to continue: yes/no");
		continueChoice=sc.next();
		}
		while(continueChoice.equalsIgnoreCase("yes"));
	
		}

}
