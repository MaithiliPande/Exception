package com.yash.largestElement;

import java.util.Scanner;
/**
 * LargestElement gives value of largest number in given array along with its index
 * @author ayushi.jain
 *
 */
public class LargestElement
{
	/*
	 * values of array
	 */
	int arr[]={1,25,3,4,55,6,7,9,10,12};
	/**
	 * maxInt gives largest element stored in array along with its index
	 */
	public void maxInt()
	{
		int temp=0;
		int i=1;
		int index=0;
		temp=arr[0];
		for(i=0;i<arr.length-1;i++)
		{
			if(temp<arr[i])
			{
				temp=arr[i];
				index=i;
			}
		}
		System.out.println("Number is: "+temp);
		System.out.println("index is: "+index);
	}
	
	
	
	public static void main(String args[])
	{
		LargestElement le=new LargestElement();
		le.maxInt();
	}

}
