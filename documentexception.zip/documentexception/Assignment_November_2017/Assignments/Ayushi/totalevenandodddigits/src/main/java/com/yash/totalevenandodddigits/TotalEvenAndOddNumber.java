package com.yash.totalevenandodddigits;

import junit.framework.TestCase;

public class TotalEvenAndOddNumber extends TestCase {

	public String giveSum(String input) 
	{
		if(input.isEmpty())
		{
			String output = "invalid input";
			return output;
		}
		else
		{	
			int len=input.length();
			int n=Integer.parseInt(input);
			int even=0;
			int odd=0;
			for(int i=0; i<len; i++)
			{
				int val=n%10;
				n=n/10;
				int remainder=val%2;
				if(remainder==0)
				{
					even++;
				}
				else if(remainder!=0)
				{
					odd++;
				}
			}
			String output=even+" Even"+" "+odd+" Odd";
			return output;
		}
	}

}
