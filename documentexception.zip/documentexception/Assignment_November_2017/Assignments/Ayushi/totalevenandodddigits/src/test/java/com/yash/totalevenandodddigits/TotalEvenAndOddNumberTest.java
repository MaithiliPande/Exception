package com.yash.totalevenandodddigits;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

import junit.framework.TestCase;

public class TotalEvenAndOddNumberTest extends TestCase 
{	
	private static final String ANY_VALID_STRING_AS_INPUT="542587545";
	TotalEvenAndOddNumber number;
	
   @Before
	public void setUp() throws Exception
	{
		number=new TotalEvenAndOddNumber();
	}
	
	@Test
	public void test_empty() throws Exception
	{	
		String result=number.giveSum("");
		assertEquals("invalid input",result);	
	}
	

	@Test
	public void test_for_given_number() throws Exception
	{	
		
		String result=number.giveSum(ANY_VALID_STRING_AS_INPUT);
		System.out.println(result);
		assertEquals("4 Even 5 Odd",result);
	}
}
