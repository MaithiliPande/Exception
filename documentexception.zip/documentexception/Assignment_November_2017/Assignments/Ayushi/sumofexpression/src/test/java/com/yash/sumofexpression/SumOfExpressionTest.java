package com.yash.sumofexpression;

import org.junit.Test;

import junit.framework.TestCase;

public class SumOfExpressionTest extends TestCase {
	private SumOfExpression sum;
	
	@Test
	public void test_empty() throws Exception
	{
		SumOfExpression sum=new SumOfExpression();
		int result=sum.add("");
		assertEquals(0,result);
	}
	@Test
	public void test_for_expression()
	{
		SumOfExpression sum=new SumOfExpression();
		int result=sum.add("2+3+4");
		assertEquals(9, result);
	}
	
}
