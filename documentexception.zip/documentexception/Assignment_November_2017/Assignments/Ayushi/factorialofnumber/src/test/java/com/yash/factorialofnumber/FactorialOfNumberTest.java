package com.yash.factorialofnumber;

import static org.junit.Assert.*;

import java.math.BigInteger;

import org.junit.Before;
import org.junit.Test;

public class FactorialOfNumberTest 
{
	private static final Integer ANY_VALID_STRING_AS_INPUT=5;
	FactorialOfNumber factorial;
	@Before
	public void setup() throws Exception
	{
		factorial=new FactorialOfNumber();
	}
	
	@Test
	public void test_empty()
	{	
		BigInteger result=factorial.giveFactorial(null);
		assertEquals(null,result);	
	}
	
	@Test
	public void test_for_input_as_zero_and_one()
	{
		BigInteger result=factorial.giveFactorial(1);
		assertEquals("1",result.toString());
	}
	
	@Test
	public void test_for_any_valid_number_other_than_one_and_two()
	{
		BigInteger result=factorial.giveFactorial(ANY_VALID_STRING_AS_INPUT);
		assertEquals("120",result.toString());
	}
}
