package com.yash.factorialofnumber;

import static org.junit.Assert.*;

import java.math.BigInteger;

import org.junit.Test;

public class FactorialOfNumber
{
	
	public BigInteger giveFactorial(Integer input)
	{
		
		if(input==null)
		{
			return null;
		}
		
		else if(input==0)
		{
			return BigInteger.ONE;
		}
		
		else if(input==1)
		{
			return BigInteger.ONE;
		}
		
		else
		{
			BigInteger fact=new BigInteger("1");
			System.out.println(input);
			//int val=Integer.parseInt(input);
			for(int i=1; i<=input; i++)
			{
				
				fact=fact.multiply(BigInteger.valueOf(i));
			}
			return fact;
		}
	}

}
