package com.yash.carproject;
/**
 * CarParking has functions that helps in parking car, removing it, calculating total cars parked and displaying leftover spaces 
 * @author ayushi.jain
 *
 */
public class CarParking 
{
	/**
	 * jagged array gives slots for car in which it has to get park
	 */
	static int arr[][]=new int[4][];
	/**
	 * count gives value of total no. of cars parked 
	 */
	static int count=0;
	/**
	 * CarParking helps in initialising column values
	 */
	public CarParking()
	{
		
		arr[0]=new int[1];
		arr[1]=new int[2];
		arr[2]=new int[3];
		arr[3]=new int[4];
		//arr[4]=new int[5];
	}
	/**
	 * empty_space will park the car.
	 * @param registration_number
	 */
	public void empty_space(int registration_number)
	{
		for(int i=0; i<arr.length; i++)
		{
			for(int j=0; j<arr[i].length; j++)
			{
				if(arr[i][j]==0)
				{
					arr[i][j]=registration_number;
					break;
				}

			}
		}
		count++;
		System.out.println("car is parked");
	}
	/**
	 * remove_car will remove the car from parking.
	 * @param registration_number
	 */
	public void remove_car(int registration_number)
	{
		for(int i=0; i<arr.length; i++)
		{
			for(int j=0; j<arr[i].length; j++)
			{
				if(arr[i][j]==registration_number)
				{
					arr[i][j]=0;
				}
			}
		}
		count--;
		System.out.println("car is removed");
	}
	/**
	 * display will give the number of cars that is being parked
	 */
	public static void display()
	{
		System.out.println("total cars parked are: "+count);
	}
	/**
	 * spaceAvailable gives total space available for parking car
	 */
	public static void spaceAvailable() 
	{
		
		System.out.println("total space available "+(15-count));
	}
}
