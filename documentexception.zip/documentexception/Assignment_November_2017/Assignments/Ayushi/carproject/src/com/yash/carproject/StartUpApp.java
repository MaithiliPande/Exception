package com.yash.carproject;

import java.util.Scanner;
/**
 * StartUpApp has menu for performing CarParking functions in it.
 * @author ayushi.jain
 *
 */
public class StartUpApp 
{
	
	public static void main(String[] args) 
	{
		Scanner s =new Scanner(System.in);
		String continueChoice;
		do
		{	
			System.out.println("Menu");
			System.out.println("enter your choice");
			System.out.println("press 1 for adding car");
			System.out.println("press 2 for removing car");
			System.out.println("press 3 for displaying total number of cars");
			System.out.println("press 4 for total space available");
			System.out.println("press 5 for exit");
			int choice=s.nextInt();
			/**
			 * cases for list of cars parked, removed, total cars parked and spaces available
			 */
			switch(choice)
			{
				case 1: 
				{
						System.out.println("enter registration number of car to be parked");
						int reg_no= s.nextInt();
						System.out.println("enter name of owner");
						String name=s.next();
						Car car=new Car();
						car.setRegistation_number(reg_no);
						car.setOwner(name);
						CarParking cp=new CarParking();
						cp.empty_space(reg_no);
				}
						break;
				case 2: 
					{
						System.out.println("enter registration number of car you want to remove");
					
						int registration_numb=s.nextInt();
						CarParking cp=new CarParking();
						cp.remove_car(registration_numb);
					}
						break;
				case 3: 
					{
						CarParking.display(); 
					}
					break;
				case 4:
				{
					CarParking.spaceAvailable();
				}
			}
			System.out.println("Do you want to continue: yes/no");
			continueChoice=s.next();
			}
			while(continueChoice.equalsIgnoreCase("yes"));
		
	}

}
