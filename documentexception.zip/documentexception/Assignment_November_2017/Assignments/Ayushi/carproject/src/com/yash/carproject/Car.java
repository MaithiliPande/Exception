package com.yash.carproject;

public class Car
{
	int registation_number;
	String owner;
	public int getRegistation_number() {
		return registation_number;
	}
	public void setRegistation_number(int registation_number) {
		this.registation_number = registation_number;
	}
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	
	
}
