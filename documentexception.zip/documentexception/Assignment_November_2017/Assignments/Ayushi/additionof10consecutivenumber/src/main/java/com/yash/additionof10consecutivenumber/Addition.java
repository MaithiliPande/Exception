package com.yash.additionof10consecutivenumber;

import static org.junit.Assert.*;

import org.junit.Test;

public class Addition
{

		public int giveSum(String input)
		{
			if(input.isEmpty())
			{
			return 0;
			}
			
			else
			{
				try
				{
				int i;
				int total=0;
				int val=Integer.parseInt(input);
				for(i=val; i<val+10; i++)
				{
					total=total+i;
				}
				return total;
				}
				
				catch(Exception e)
				{
					System.out.println("Please enter correct number");
					return 0;
				}
			}
		}
}

	