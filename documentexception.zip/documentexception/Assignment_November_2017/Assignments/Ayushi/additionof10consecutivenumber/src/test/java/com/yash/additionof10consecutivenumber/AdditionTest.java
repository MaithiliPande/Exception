package com.yash.additionof10consecutivenumber;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class AdditionTest {
	private static final String ANY_VALID_SINGLE_STRING_AS_INPUT="1";
	Addition addition;
	@Before
	public void setup() throws Exception
	{
	addition=new Addition();
	}
	
	@Test
	public void test_empty() throws Exception
	{
		int result=addition.giveSum("");
		assertEquals(0,result);
	}
	
	@Test
	public void test_for_any_input() throws Exception
	{
		int result=addition.giveSum(ANY_VALID_SINGLE_STRING_AS_INPUT);
		assertEquals(55,result);
	}
}
