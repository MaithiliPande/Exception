package com.yash.binaryequivalent;

import static org.junit.Assert.assertArrayEquals;

import org.junit.Test;

import junit.framework.TestCase;

public class BinaryEquivalentTest extends TestCase 
{
	private static final int ANY_VALID_SINGLE_STRING_AS_INPUT=3;
	private BinaryEquivalent binaryEquivalent;
	
	@Test
	public void test_empty()
	{	
		binaryEquivalent=new BinaryEquivalent();
		int[] result=binaryEquivalent.getBinary(0);
		int test[]=new int[4];
		test[0]=0;
		assertArrayEquals(test, result);
	}
	
	@Test
	public void test_to_get_binary_for_single_number()
	{	
		binaryEquivalent=new BinaryEquivalent();
		int result[]=binaryEquivalent.getBinary(ANY_VALID_SINGLE_STRING_AS_INPUT);
		int test[]=new int[4];
		test[0]=1;
		test[1]=1;
		test[2]=0;
		test[3]=0;
		assertArrayEquals(test, result);
	}
}
