package com.yash.binaryequivalent;

import junit.framework.TestCase;

public class BinaryEquivalent extends TestCase {

	public int[] getBinary(int num) 
	{
		int binary[]=new int[4];
		int index=0;
		if(num==0)
		{
			binary[0]=0;
			return binary;
		}
		else
		{
			while(num>0)
			{
				binary[index++]=num%2;
				num=num/2;
			}
			for(int i=index-1; i>=0; i--)
			{
				System.out.println(binary[i]);
			}
			return binary;
		}
	}

}
