package com.yash.reverseString;

import java.util.Scanner;
/**
 * ReverseString reverses the given String 
 * @author ayushi.jain
 *
 */
public class ReverseString 
{
	String temp;
	/**
	 * reverseIt method passes String as an arguement and reverses it
	 * @param original
	 */
	public void reverseIt(String original)
	{
		int i;
		char [] arr=original.toCharArray(); 
		int n=original.length()-1;
		for(i=0; i<n; i++)
		{
			 
			char temp=arr[i];
			arr[i]=arr[n];
			arr[n]=temp;
			n--;
		}
		String newvalue=String.valueOf(arr);
		System.out.println(newvalue);
	}
	
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter your string: ");
		String original=sc.nextLine();
		ReverseString rs=new ReverseString();
		rs.reverseIt(original);
	}
}
