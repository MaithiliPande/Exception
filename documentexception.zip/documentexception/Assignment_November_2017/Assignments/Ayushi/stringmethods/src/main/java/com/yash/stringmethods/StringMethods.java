package com.yash.stringmethods;

import junit.framework.TestCase;

public class StringMethods extends TestCase {
	//public char stringMethod(String input)
	//{
	
		//char str=input.charAt(0);
		//System.out.println(str);
		//return str;
	//}
}
