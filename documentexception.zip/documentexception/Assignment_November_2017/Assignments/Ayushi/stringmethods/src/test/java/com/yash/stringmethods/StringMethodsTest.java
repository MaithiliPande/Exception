package com.yash.stringmethods;

import org.junit.Test;

import junit.framework.TestCase;

public class StringMethodsTest extends TestCase {
	
	private String str1="honesty";
	private String str2="policy";
	private String str3="honesty is the best policy";
	private String str4= new String("apple");
	private String str5="HAPPY";
	private String str6="Happy Birthday";
	
	@Test
	public void char_At()
	{
		char result=str1.charAt(2);
		assertEquals('p', result);
	}
	
	@Test
	public void concate()
	{
		String result=str1.concat(str2);
		assertEquals("honestypolicy", result);
	}
	
	@Test
	public void contains()
	{
		boolean result=str3.contains("the best policy");
		assertEquals(true, result);
	}
	
	@Test
	public void charAt()
	{
		char result=str1.charAt(2);
		assertEquals('p', result);
	}
	
	@Test
	public void testEndsWith()
	{
		boolean result=str3.endsWith("best policy");
		assertEquals(true, result);
	}
	
	@Test
	public void testEquals()
	{
		boolean result=str3.equals(str2);
		assertEquals(false, result);
	}
	
	@Test
	public void equalsIgnoreCase()
	{
		boolean result=str2.equalsIgnoreCase("POLICY");
		assertEquals(true, result);
		boolean result2=str2.equalsIgnoreCase("str1");
		assertEquals(false, result2);
	}
	
	@Test
	public void test_Intern()
	{
		boolean result=str2.intern()==str4.intern();
		assertEquals(false, result);
	}
	
	@Test
	public void index_Of()
	{
		int result=str1.indexOf(1);
		assertEquals(3, result);
	}
	
	@Test
	public void last_Index_Of()
	{
		int result=str3.lastIndexOf("y");
		assertEquals(26, result);
	}
	
	@Test
	public void test_Length()
	{
		int result=str3.length();
		assertEquals(26, result);
	}
	
	@Test
	public void test_Replace()
	{
		String result=str1.replace("o","O");
		assertEquals("hOnesty", result);
	}
	
	@Test
	public void split()
	{
		String[] result=str6.split("//s");
		String expected[]=new String[2];
		expected[0]="Happy";
		expected[1]="Everyone";
		assertEquals(expected, result);
	}
	
	@Test
	public void test_Substring()
	{
		String result=str3.substring(2, 7);
		assertEquals("nesty", result);
	}
	
	@Test
	public void lower_Case()
	{
		String result=str5.toLowerCase();
		assertEquals("happy", result);
	}
	
	@Test
	public void upper_Case()
	{
		String result=str2.toUpperCase();
		assertEquals("POLICY", result);
	}
	
	@Test
	public void test_Trim()
	{
		String result=str6.trim();
		assertEquals("Happy Birthday", result);
	}
	
	@Test
	public void test_Value_Of()
	{
		int value=27;
		String s1=String.valueOf(value);
		assertEquals("27", s1);
	}
	
}
