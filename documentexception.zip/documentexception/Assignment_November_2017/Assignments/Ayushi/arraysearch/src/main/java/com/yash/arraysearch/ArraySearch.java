package com.yash.arraysearch;

import java.util.Scanner;
/**
 * ArraySearch will search the number from array
 * @author ayushi.jain
 *
 */

public class ArraySearch {
	int arr[] = new int[10];
	Scanner sc=new Scanner(System.in);
	/**
	 * count of times number searched
	 */
	int count;
	/**
	 * particular number that is being searched
	 */
	int search;
	int i;
	/**
	 * searchAndCount will search the number and give the value how many times it is present
	 * @return
	 */
	public int searchAndCount() 
	{
		System.out.println("enter 10 values of array");
		
		for(i=0; i<10; i++)
		{
			arr[i]=sc.nextInt();
		}
		System.out.println("enter the number you want to search");
		search=sc.nextInt();
		for(i=0; i<10; i++)
		{
				if(search==arr[i])
				count++;
		}
		System.out.println("no. of times present in array=  "+count);
		return count;
	}

}
