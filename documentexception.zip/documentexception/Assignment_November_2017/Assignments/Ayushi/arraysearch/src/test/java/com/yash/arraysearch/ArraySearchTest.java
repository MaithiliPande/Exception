package com.yash.arraysearch;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class ArraySearchTest 
{
	@Test
	public void for_searching_and_counting_digits() throws Exception
	{
		ArraySearch as=new ArraySearch();
		int result =as.searchAndCount();
		assertEquals(3,result);
	}

}
