package com.yash.transpose;

import java.util.Scanner;
/**
 * Transpose class transposes 4*4 matrix
 * @author ayushi.jain
 *
 */
public class Transpose 
{
	
	public static void main(String args[])
	{
		/**
		 * arr[][] takes 4*4 array values
		 */
		int arr[][]=new int[4][4];
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the values of array");
		for(int i=0; i<4; i++)
		{
			for(int j=0; j<4; j++)
			{
				arr[i][j]=sc.nextInt();
			}
		}
		System.out.println("Matrix is:");
		for(int i=0; i<4; i++)
		{
			for(int j=0; j<4; j++)
			{
				System.out.print(arr[i][j]+" " );
			}
			System.out.println("");
		}
		int temp=0;
		for(int i=0; i<4; i++)
		{
			for(int j=i; j<4; j++)
			{
				temp=arr[i][j];
				arr[i][j]=arr[j][i];
				arr[j][i]=temp;
			}
		}
		System.out.println("Transpose :");
		for(int i=0; i<4; i++)
		{
			for(int j=0; j<4; j++)
			{
				System.out.print(arr[i][j]+" ");
			}
			System.out.println(" ");
		}
		
			
	}
}
