package com.yash.divisiblebyseven;

import org.junit.Test;

import junit.framework.TestCase;

public class DivisibleBySevenTest extends TestCase {

	@Test
	public void test_for_any_number()
	{
		DivisibleBySeven number=new DivisibleBySeven();
		int result=number.calculate(101,110);
		assertEquals(105,result);
	}

}
