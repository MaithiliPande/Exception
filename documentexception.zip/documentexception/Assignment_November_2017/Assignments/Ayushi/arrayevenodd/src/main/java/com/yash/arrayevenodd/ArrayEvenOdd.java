package com.yash.arrayevenodd;

import junit.framework.TestCase;
/**
 * ArrayEvenOdd will give us the data that is entered is either even or odd and also positive or negative
 * @author ayushi.jain
 *
 */
public class ArrayEvenOdd extends TestCase {
	/**
	 * arr[] are the values stored in array
	 */
	int arr[]={1,2,3,4,5,6,7,8,9,10,-1,-2,-3,-4,-5};
	int i=0;
	int count;
	/**
	 * positiveNumbers give count of total positive numbers
	 * @return
	 */
	public int positiveNumbers()
	{
		for(i=0; i<15; i++)
		{
			if(arr[i]>0)
			{
				count++;
			}
		}
		return count;	
	}
	/**
	 * negativeNumbers give count of total negative numbers
	 * @return
	 */
	public int negativeNumbers() 
	{
		for(i=0; i<15; i++)
		{
			if(arr[i]<0)
			{
				count++;
			}
		}
		return count;
	}
	/**
	 * evenNumbers give count of total even numbers
	 * @return
	 */
	public int evenNumbers()
	{
		for(i=0; i<15; i++)
		{
			if(arr[i]%2==0)
			{
				count++;
			}
		}
		return count;	
	}
	/**
	 * oddNumbers give count of total odd numbers
	 * @return
	 */
	public int oddNumbers()
	{
		for(i=0; i<15; i++)
		{
			if(arr[i]%2!=0)
			{
				count++;
			}
		}
		return count;	
	}
}

