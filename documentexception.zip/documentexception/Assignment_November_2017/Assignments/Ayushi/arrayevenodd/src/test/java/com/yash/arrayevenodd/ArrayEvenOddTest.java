package com.yash.arrayevenodd;

import org.junit.Test;
import junit.framework.TestCase;


public class ArrayEvenOddTest extends TestCase {

		
	@Test
	public void test_for_positive_number() throws Exception
	{
	 ArrayEvenOdd array=new ArrayEvenOdd();
	 int result=array.positiveNumbers();
	 assertEquals(10,result);
	}
	@Test
	public void test_for_negative_numbers()throws Exception
	{ 
		ArrayEvenOdd array=new ArrayEvenOdd();
		int result=array.negativeNumbers();
		assertEquals(5,result);
	}
	@Test
	public void test_for_even_numbers()throws Exception
	{ 
		ArrayEvenOdd array=new ArrayEvenOdd();
		int result=array.evenNumbers();
		assertEquals(7,result);
	}
	@Test
	public void test_for_odd_numbers()throws Exception
	{ 
		ArrayEvenOdd array=new ArrayEvenOdd();
		int result=array.oddNumbers();
		assertEquals(8,result);
	}
}