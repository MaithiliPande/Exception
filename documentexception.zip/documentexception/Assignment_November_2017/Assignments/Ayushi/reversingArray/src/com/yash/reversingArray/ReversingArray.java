package com.yash.reversingArray;

import java.util.Scanner;
/**
 * ReversingArray will give us array in reverse order
 * @author ayushi.jain
 *
 */
public class ReversingArray {

	public static void main(String[] args) {
		/**
		 * for digits to be entered
		 */
		Scanner sc=new Scanner(System.in);
		System.out.println("enter total number of digits");
		int n=sc.nextInt();
		int i;
		System.out.println("enter digits of array");
		int arr[]=new int[n];
		for (i=0; i<n; i++)
		{
			arr[i]=sc.nextInt();
		
		}
		System.out.println("after reversing we get: ");
		for(i=n-1; i>=0; i--)
		{
			System.out.println(+arr[i]);
		}
	}

}
