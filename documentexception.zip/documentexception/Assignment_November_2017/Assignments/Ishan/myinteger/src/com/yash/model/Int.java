package com.yash.model;
/**
 * this is the model class for MyInt.
 * @author ishan.juneja
 *
 */
public class Int {
/**
 * the only int type variable required.
 */
private int value;
/**
 * default constructor initializes the value to zero
 */
public Int(){
	value = 0;
}
/**
 * this constructor initializes the value variable to the passed value
 * @param v
 */
public Int(int v){
	this.value=v;
	
}
/**
 * this method displays the value of Int just like an int
 * @return
 */
public int display(){
	
	return value;
}

/**
 * this method adds two Int variables and returns a variable of type Int
 * @param one is the first Int operand to be added
 * @param two is the second Int operand to be added
 * @return Int object with initialized value to the sum of the operands
 */
public Int add(Int one,Int two){
	int resultsum = one.display()+two.display();
	Int result = new Int(resultsum);
return result;
}


}
