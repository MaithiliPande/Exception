package com.yash.main;
/**
 * main method to test the Int class and its methods.
 */
import com.yash.model.Int;

public class MainMyInteger {

public static void main(String gg[]){	
Int numberone = new Int(15);
Int numbertwo = new Int(20);
Int numberthree = new Int().add(numberone, numbertwo);

System.out.println(numberthree.display());
}

}
