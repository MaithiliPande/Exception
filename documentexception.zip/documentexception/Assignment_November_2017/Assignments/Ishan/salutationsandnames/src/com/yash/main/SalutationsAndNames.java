package com.yash.main;
/**
 * Salutations and names main class
 */
import java.util.Scanner;

import com.yash.model.Person;
import com.yash.service.SalutationAndNameService;

public class SalutationsAndNames {

	public static void main(String[] args) {
		SalutationAndNameService service = new SalutationAndNameService();
		String cont;
		int choice;
		Scanner sc = new Scanner(System.in);
		do{
			System.out.println("----enter choice----");
			System.out.println("0. exit");
			System.out.println("1. Add person");
			System.out.println("2. list all males");
			System.out.println("3. list all married Females");
			System.out.println("4. list all unmarried Females");
			choice=sc.nextInt();
			switch (choice){
			/**
			 * exit case
			 */
			case 0:{
				System.exit(0);
			}
			/**
			 * add a person in array according to maritial status and gender
			 */
			case 1:{
				Person person = new Person();
				System.out.println("enter name");
				sc.nextLine();
				person.setName(sc.nextLine());
				System.out.println("Gender M/F :");
				person.setGender(sc.nextLine());
				System.out.println("Marital Status M/U :");
				person.setMaritalstatus(sc.nextLine());
				service.insertInArray(person);
			}
			break;
			/**
			 * this case prints all males with salutations in array
			 */
			case 2:{
					int count=service.getManCount();
				for(int i=1;i<count;i++){
					System.out.println(service.mainArray[0][0]+service.mainArray[i][0]);
				}
				
			}break;
			/**
			 * this case prints all married women names with salutation in the array
			 */
			case 3:{
				int count = service.getmarriedWomanCount();
				for(int i=1;i<count;i++){
					System.out.println(service.mainArray[0][1]+service.mainArray[i][1]);
				}
				
			}break;
			/**
			 * this case prints all unmarried women with salutations in array
			 */
			case 4:{
				int count = service.getUnmarriedWomanCount();
				for(int i=1;i<count;i++){
					System.out.println(service.mainArray[0][2]+service.mainArray[i][2]);
				}
				
			}break;
			
		default:
			System.out.println("invalid choice");
		}
		
		System.out.println("enter yes to continue:");
		cont=sc.next();
		}while (cont.equalsIgnoreCase("yes"));	
		
		
		
	}

}
