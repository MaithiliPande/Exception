package com.yash.service;

import com.yash.model.Person;

public class SalutationAndNameService {
	/**
	 * this is the main array to store names and salutations accordingly
	 */
	public static String[][] mainArray = new String[15][3];
	{
	mainArray[0][0]="Mr.";
	mainArray[0][1]="Mrs.";
	mainArray[0][2]="Ms.";
	}
	/**
	 * this is the unmarried women count.
	 * Set to 1 in the beginning because there is already a ms. at the top
	 */
	int unmarriedwomancount=1;
	/**
	 * this is the married women count.
	 * Set to 1 in the beginning because there is already a mrs. at the top
	 */
	int marriedwomancount=1;
	/**
	 * this is the total man count.
	 * Set to 1 in the beginning because there is already a mr. at the top
	 */
	int mancount=1;
	public void insertInArray(Person person){
	if(person.getGender().equalsIgnoreCase("f") && person.getMaritalstatus().equalsIgnoreCase("u")){
		mainArray[unmarriedwomancount][2]=person.getName();		
		unmarriedwomancount++;
	}
	if(person.getGender().equalsIgnoreCase("f") && person.getMaritalstatus().equalsIgnoreCase("m")){
		mainArray[marriedwomancount][1]=person.getName();
		marriedwomancount++;
	}
	if(person.getGender().equalsIgnoreCase("m")){
		mainArray[mancount][0]=person.getName();
		mancount++;
	}
	
}
	public int getUnmarriedWomanCount(){
		return unmarriedwomancount;
	}
	public int getmarriedWomanCount(){
		return marriedwomancount;
	}
	public int getManCount(){
		return mancount;
	}
	
}