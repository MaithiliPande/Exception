package com.yash.model;
/**
 * this is the person model class
 * @author ishan.juneja
 *
 */
public class Person {
	/**
	 * name of the person to store in the array
	 */
String name;
/**
 * gender of the person
 */
String gender;
/**
 * marital status of the person to store in the array
 */
String maritalstatus;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public String getMaritalstatus() {
	return maritalstatus;
}
public void setMaritalstatus(String maritalstatus) {
	this.maritalstatus = maritalstatus;
}



}
