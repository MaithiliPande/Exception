package com.yash.stringfunctions;

import static org.junit.Assert.*;

import org.junit.Test;

public class StringTest {

	@Test
	public void test_char_at() {
		StringDemo str = new StringDemo();
		String result = str.charAt("ishan",3).toString();
		assertEquals("h", result);
	}
	
	@Test
	public void test_concat() {
		StringDemo str = new StringDemo();
		String result = str.concat("ishan","juneja");
		assertEquals("ishan juneja", result);
	}
	
	@Test
	public void test_contains() {
		StringDemo str = new StringDemo();
		Boolean result = str.contains("ishan","an");
		assertEquals(true, result);
	}
	
	@Test
	public void test_ends_with() {
		StringDemo str = new StringDemo();
		Boolean result = str.contains("ishan","an");
		assertEquals(true, result);
	}
	
	@Test
	public void test_equals() {
		StringDemo str = new StringDemo();
		Boolean result = str.equalsDemo("ishan","ishan");
		assertEquals(true, result);
	}
	
	@Test
	public void test_equals_ignore_case() {
		StringDemo str = new StringDemo();
		Boolean result = str.ignoreCase("ishan","ISHAN");
		assertEquals(true, result);
	}
	
	@Test
	public void test_index_of() {
		StringDemo str = new StringDemo();
		int result = str.index("ishan","a");
		assertEquals(3, result);
	}
	
	@Test
	public void test_intern() {
		StringDemo str = new StringDemo();
		boolean result = str.intern("ishan","ishan");
		assertEquals(true, result);
	}
	
	@Test
	public void test_last_index_of() {
		StringDemo str = new StringDemo();
		int result = str.lastindex("juneja","j");
		assertEquals(4, result);
	}
	

	@Test
	public void test_length() {
		StringDemo str = new StringDemo();
		int result = str.length("juneja");
		assertEquals(6, result);
	}
	
	@Test
	public void test_replace() {
		StringDemo str = new StringDemo();
		String result = str.replace("war");
		assertEquals("was", result);
	}
	
	@Test
	public void test_split() {
		StringDemo str = new StringDemo();
		String result = str.split("my cat",' ');
		assertEquals("mycat", result);
	}
	
	@Test
	public void test_substring() {
		StringDemo str = new StringDemo();
		String result = str.substring("unhappy",2);
		assertEquals("happy", result);
	}
	
	@Test
	public void test_tolowercase() {
		StringDemo str = new StringDemo();
		String result = str.tolower("UNHAPPY");
		assertEquals("unhappy", result);
	}
	
	@Test
	public void test_touppercase() {
		StringDemo str = new StringDemo();
		String result = str.toupper("unhappy");
		assertEquals("UNHAPPY", result);
	}
	
	@Test
	public void test_trim() {
		StringDemo str = new StringDemo();
		String result = str.totrim("    ishan juneja     ");
		assertEquals("ishan juneja", result);
	}
	@Test
	public void test_value_of() {
		StringDemo str = new StringDemo();
		String result = str.valueof('a');
		assertEquals("a", result);
	}
	
}
