package com.yash.stringfunctions;

import static org.junit.Assert.assertEquals;

public class StringDemo {

	public Character charAt(String name,int i) {
		
		return name.charAt(2);
		
	}

	public String concat(String firstname, String lastname) {
		String name=firstname.concat(" "+lastname);
		return name;
	}

	public Boolean contains(String string, String contains) {
		return string.contains("an");
	}

	public Boolean equalsDemo(String string, String string2) {
		if(string == string2){
			return true;
		}
		else return false;
	}

	public Boolean ignoreCase(String string, String string2) {
		if(string.equalsIgnoreCase(string2)){
			return true;
		}
		else return false;
		
	}

	public int index(String string, String string2) {
		return string.indexOf(string2);
		
	}

	
	
	public boolean intern(String string, String string2) {
		if(string.equals(string2)){
			if(string.intern()==string2.intern()){
return true;
			
		}
			else return false;
	}
		else return false;
		}

	
	
	public int lastindex(String string, String string2) {
		return string.lastIndexOf(string2);
	}

	
	
	public int length(String string) {
		return string.length();
	}
	
	public String replace(String s1){
		return s1.replace('r', 's');
		
	}

	public String split(String string,Character a) {
		
		return string.split(" ")[0]+string.split(" ")[1];
		
		
	}

	public String substring(String string, int index) {
	
		return string.substring(index);
	}

	public String tolower(String string) {
		return string.toLowerCase();
	}

	public String toupper(String string) {
		return string.toUpperCase();
	}

	public String totrim(String string) {
		return string.trim();
	}

	public String valueof(Character c) {
		return String.valueOf(c);
	}

	
	
	
	
	
	
	
}
