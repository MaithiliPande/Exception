package model;
/*
 * this is the model of employee class.  It contains the required information fields of the employees.
 */
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Employee {
	

/*
 * this is the ID of Employee.
 */
private int id;
/*
 * this is the name of Employee.
 */
private String name;
/*
 * this is the salary of Employee.
 */
private int salary;
/*
 * this is the age of Employee.
 */
private int age;

/*
 * this is the email of the employee
 */
private String email;
/*
 * pattern of email
 */

private static final String email_pattern="^[_A-Za-z0-9-\\+]+@[A-Za-z0-9-]+(\\.[A-Za-z]{2,})$";
/*
 * pattern of name
 */
private static final String name_pattern="^([A-za-z-\\ ]{2,})$";
Pattern pattern;
Matcher matcher;

public Employee(){
	
}

/*
 * this constructor will create a new employee object with required information.
 */
public Employee(int id, String name, int salary, int age, String email) {
	super();
	this.id = id;
	this.name = setName(name);
	this.salary = salary;
	this.age = age;
	this.email=setEmail(email);
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;

}
public String getName() {
	return name;
}
/*
 *this method matches name pattern and returns name if it is of correct name format
 */
public String setName(String name) {
	pattern = Pattern.compile(name_pattern);
	matcher=pattern.matcher(name);
	if(matcher.matches()){
	return this.name = name;
		
		}
	else System.out.println("not a valid name");
	 return this.name=null;
	
}
public int getSalary() {
	return salary;
}
public void setSalary(int salary) {
	this.salary = salary;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public String getEmail() {
	return email;
}

/*
 *this method matches email pattern and returns email if it is of correct name format
 */
public String setEmail(String email) {
	
	pattern = pattern.compile(email_pattern);
	matcher=pattern.matcher(email);
	
	if(matcher.matches()){
	return this.email = email;
	
	}
	else System.out.println("not a valid email");
	return "not a valid email";
}

@Override
public String toString(){
	
	
	return "id : "+this.id+" name : "+this.name+" age : "+this.age+" salary : "+this.salary+" email : "+this.email;
}

	
}
