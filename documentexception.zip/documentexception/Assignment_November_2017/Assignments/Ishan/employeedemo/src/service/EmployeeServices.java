package service;

import java.util.Arrays;

import model.Employee;
/**
 * this is the model of employee. it contains information about the employee entity.
 * @author ishan.juneja
 *
 */
public class EmployeeServices {
/*
 * this is the repository to store Employees in array
 */
private Employee[] employeeRepository= new Employee[2];
/*
 * This is the next available location in employee repository.
 */
private int location=0;



/**
 * this method will add an employee in employee repository.
 * if employee repository is full, it will create a new employee repository with double capacity
 * and copy old repository contents in new employee repository.
 * @param employee
 */
public void addEmployee(Employee employee){
	
if(location>=employeeRepository.length){
	
	Employee[] newRepository=new Employee[employeeRepository.length*2];
			newRepository=expandRepository(employeeRepository);
	employeeRepository = new Employee[newRepository.length];
	for(int i=0;i<employeeRepository.length;i++){
		employeeRepository[i]=newRepository[i];
		
	}
			
}
	
 employeeRepository[location++]=employee;
	
}

/*
 * this method increases the employee repository capacity and return a new repository with extended space
 */
private Employee[] expandRepository(Employee[] newRepo) {
	
	Employee newRepository[] = new Employee[newRepo.length*2];
	for(int i=0;i<newRepo.length;i++){
		
		newRepository[i]=newRepo[i];
	}
	return newRepository;
}
/*
 * this method deletes an employee of a particular id.
 */
public void deleteEmployee(int id){
int i=0;
while(i<location){
	if(employeeRepository[i].getId()==id){
		employeeRepository[i]=null;
		for(int j=i;j<location;j++){
			employeeRepository[j]=employeeRepository[j+1];
		}
		location--;
		
	}
	i++;
}


	
}



/**
 * this method will return a list of employees currently in the repository.
 * the returned list will have the same length as number of employees in repository.
 * @return
 */
public Employee[] showList(){
	Employee[] tempRepository=new Employee[location];

	for(int i=0;i<location;i++){
		tempRepository[i]=employeeRepository[i];
		
	}
	
	return tempRepository;
}
	
}
