package main;
/**
 * this is the start-up class of the application
 */
import java.util.Scanner;

import model.Employee;
import service.EmployeeServices;

public class StartupApplication {

	public static void main(String[] args) {
		EmployeeServices employeeservices = new EmployeeServices();
		String cont;
		int choice;
		Scanner sc = new Scanner(System.in);
		do {
		System.out.println("----enter choice----");
		System.out.println("1. Add Employee");
		System.out.println("2. list all employees");
		System.out.println("3. exit");
		System.out.println("4. delete employee by id");
		choice=sc.nextInt();
		switch (choice) {
		case 1:{
			System.out.println("enter id:");
			int id = sc.nextInt();
			System.out.println("enter name:");
			sc.nextLine();
			String name = sc.nextLine();
		
			System.out.println("enter age:");
			int age = sc.nextInt();
			System.out.println("enter salary:");
			int salary = sc.nextInt();
			System.out.println("enter email:");
			String email=sc.next();
			Employee employee = new Employee(id, name, salary, age,email);
			email=employee.getEmail();
			name=employee.getName();
			if(email!="not a valid email" && name!=null) employeeservices.addEmployee(employee);
			}
		break;
		case 2:{
			Employee employees[]=employeeservices.showList();
			for(int i=0;i<employees.length;i++){
				System.out.println(employees[i].toString());			
			}
			}
		break;
		
		case 3:{
				System.exit(0);		
			}
		case 4:{
			System.out.println("enter id to be deleted :");
			int delid=sc.nextInt();
			employeeservices.deleteEmployee(delid);
			System.out.println("employee deleted with id"+delid);
		}
		
		
		default:
			System.out.println("invalid choice");
		}
		
		System.out.println("enter yes to continue:");
		cont=sc.next();
		
		} while (cont.equalsIgnoreCase("yes"));	
	}
}
