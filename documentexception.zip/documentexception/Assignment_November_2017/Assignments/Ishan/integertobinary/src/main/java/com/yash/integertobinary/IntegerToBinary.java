package com.yash.integertobinary;



public class IntegerToBinary {
	public String integerToBinary(Integer in){
		
	StringBuilder sb = new StringBuilder();
	if(in==null){
		return null;
	}
	
	
	if(Math.signum(in)==1){
	while(in>0){
		int r = in%2;
        sb.append(r);
        in = in/2;
	}
	return sb.reverse().toString();
	}
	
	if(Math.signum(in)==-1){
		in=Math.abs(in);
		while(in>0){
			int r = in%2;
	        sb.append(r);
	        in = in/2;
		}
		while(sb.length()<32){
			sb.append("0");
			
			
		}
		
		String input0=sb.reverse().toString();		
		input0 = input0.replaceAll("1", "-");
        input0 = input0.replaceAll("0", "1");
        input0 = input0.replaceAll("-", "0");
        
        System.out.println(input0);
        String result = addBinary(input0);
		System.out.println(result);
		return result;
		
	}
	
	System.out.println(Integer.toBinaryString(in));
	
	
	

	return sb.reverse().toString();
	}
	
	 public String addBinary(String a) {
	      
	        int la = a.length();
	        int lb = 1;
	        String b="1";
	        int max = la;
	        
	        StringBuilder sum = new StringBuilder("");
	        int carry = 0;
	        
	        for(int i = 0; i < max; i++){
	            int m = getBit(a, la - i - 1);
	            int n = getBit(b, lb - i - 1);
	            int add = m + n + carry;
	            sum.append(add % 2);
	            carry = add / 2;
	        }
	        
	        if(carry == 1)
	            sum.append("1");
	        
	        return sum.reverse().toString();
	        
	    }
	    
	    public int getBit(String s, int index){
	        if(index < 0 || index >= s.length())
	            return 0;
	        
	        if(s.charAt(index) == '0')
	            return 0;
	        else
	            return 1;
	        
	    }
	
	
	
	
}