package com.yash.integertobinary;

import static org.junit.Assert.*;

import org.junit.Test;

public class IntegerToBinaryTest {

	@Test
	public void test_no_input() {
		IntegerToBinary intbin = new IntegerToBinary();
		String result = intbin.integerToBinary(null);
		assertEquals(null, result);
	
	}
	@Test
	public void test_negative_input() {
		IntegerToBinary intbin = new IntegerToBinary();
		String result = intbin.integerToBinary(-5);
		assertEquals("11111111111111111111111111111011", result);
	
	}
	

}