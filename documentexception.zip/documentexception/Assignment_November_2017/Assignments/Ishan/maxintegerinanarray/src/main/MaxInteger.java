package main;
/**
 * this is the main method for finding the maximum integer from an array of integers
 */
import service.MaxIntegerService;

public class MaxInteger {

	public static void main(String[] args) {
		MaxIntegerService service=new MaxIntegerService();
		int[] result=service.inputNumbers();
		String resultString = service.maxInt(result,result.length);
		System.out.print(resultString);
	}

}
