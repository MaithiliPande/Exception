package com.yash.numbertest;

public class PositiveOrNegativeNumber {
	/*
	 * this will hold the count of positive numbers in the array
	 */
private int positiveCount=0;
/*
 * this will hold the count of negative numbers in the array
 */
private int negativeCount=0;
/*
 * this will hold the count of even numbers in the array
 */
private int evenCount=0;
/*
 * this will hold the count of odd numbers in the array
 */
private int oddCount=0;
/*
 * this method will calculate total positive, total Negative, 
 * total Even and total Odd numbers in the array 
 * and return a string containing count of all of them
 */
	public String numberProperties(int[] testArray) {
		for(int i=0;i<15;i++){
			if(Math.signum(testArray[i])==-1){
				positiveCount++;
			}else negativeCount++;
			if(testArray[i]%2==0){
				evenCount++;
			}else oddCount++;
			
		}
		return "positive :"+positiveCount+" negative :"+negativeCount+"even :"+evenCount+"odd :"+oddCount;
	}

}
