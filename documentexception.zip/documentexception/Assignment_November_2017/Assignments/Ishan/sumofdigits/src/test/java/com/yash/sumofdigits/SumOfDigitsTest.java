package com.yash.sumofdigits;

import static org.junit.Assert.*;

import org.junit.Test;

public class SumOfDigitsTest {
private final String input="1+2+5+8+s+a1+85";
	@Test
	public void test_no_input() {
		SumOfDigits sod = new SumOfDigits();
		int result=sod.calculate("");
		assertEquals(0, result);
	}

	@Test
	public void test_any_input() {
		SumOfDigits sod = new SumOfDigits();
		int result=sod.calculate(input);
		assertEquals(102, result);
	}
	
	
	
}