package com.yash.sumoftenconsecutivenumbers;

import java.math.BigInteger;

public class SumOfNumbers {

	

	public String add(BigInteger startingNumber) {
		BigInteger sum=startingNumber;
		
		if(startingNumber==null){
		return null;
		}
		BigInteger temp = BigInteger.ZERO;
		
		BigInteger x = sum.add(BigInteger.TEN);
	    
		while(sum.compareTo(x)<0){
			
			temp = temp.add(sum);
			
			
			
			sum=sum.add(BigInteger.ONE);
			
		}
		
		
		System.out.println(temp);
		return temp.toString();
		
	}
}
