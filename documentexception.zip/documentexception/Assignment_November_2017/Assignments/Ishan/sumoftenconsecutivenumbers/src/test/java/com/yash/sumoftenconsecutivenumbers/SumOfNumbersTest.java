package com.yash.sumoftenconsecutivenumbers;

import static org.junit.Assert.*;

import java.math.BigInteger;

import org.junit.Test;

public class SumOfNumbersTest {

	BigInteger startingNumber = new BigInteger("55");
	
	@Test
	public void test_no_input()  {
		SumOfNumbers sumon = new SumOfNumbers();
		String result = sumon.add(null);
		assertEquals(null, result);
	}
	
	@Test
	public void long_number()  {
		SumOfNumbers sumon = new SumOfNumbers();
		String result= sumon.add(startingNumber);
		assertEquals("595", result);
		
	}
	

}
