package com.yash.model;
/**
 * this is the model for parking token. it will have the owner name same in car class 
 * @author ishan.juneja
 *
 */
public class ParkingToken {
	/**
	 * this is the owner name for the car.
	 */
String ownerName;
/**
 * this is the token number for the car
 */
int token;

public void ParkingToken(String Oname,int tokenNo){
	this.ownerName=Oname;
	this.token=tokenNo;
}

public String getOwnerName() {
	return ownerName;
}
public void setOwnerName(String ownerName) {
	this.ownerName = ownerName;
}
public int getToken() {
	return token;
}
public void setToken(int token) {
	this.token = token;
}


}