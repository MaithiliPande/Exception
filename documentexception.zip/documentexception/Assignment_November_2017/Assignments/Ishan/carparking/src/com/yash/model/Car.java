package com.yash.model;
/**
 * this is the model class for car whose objects will be created \
 * and stored in the parking space array of ParkingService 
 * 
 * @author ishan.juneja
 *
 */
public class Car {
	/**
	 * this is the owner name of the car to be parked. 
	 * token generated for this car will have the same name.
	 */
String ownerName;
/**
 * this is the car name of the car to be parked
 */
String carName;
/**
 * this is the registration number of the car to be parked
 */
int regNo;
/**
 * car object will have a token object inside and owner name will be common in both.
 */
ParkingToken token;

public void Car(String cname){
	this.carName=cname;
	
}
public String getOwnerName() {
	return ownerName;
}
public void setOwnerName(String ownerName) {
	this.ownerName = ownerName;
}
public String getCarName() {
	return carName;
}
public void setCarName(String carName) {
	this.carName = carName;
}
public int getRegNo() {
	return regNo;
}
public void setRegNo(int regNo) {
	this.regNo = regNo;
}
public ParkingToken getToken() {
	return token;
}
public void setToken(ParkingToken token) {
	this.token = token;
}

}