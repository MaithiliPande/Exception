package service;
/*
 * this is the service class to input and print the transpose of a 4X4 matrix
 */
import java.util.Scanner;

public class TransposeService {
	/*
	 * this will be the input matrix.
	 */
	int[][] matrix= new int[4][4];
	/*
	 * this method is created to take input of a 4X4 matrix
	 */
	public void inputMatrix(){
		Scanner sc = new Scanner(System.in);
		 
		System.out.println("enter matrix row wise:");
		for(int i=0;i<4;i++){
			for(int j=0;j<4;j++){
				System.out.print("enter element at "+i+" row"+j+" column");
				matrix[i][j]=sc.nextInt();
			}System.out.println();	
		}
		printMatrix(matrix);
		transpose(matrix);
	}
	/*
	 * this method is for printing a matrix
	 */
	 public void printMatrix(int[][] matrix){
		System.out.println("given matrix");
		for(int i=0;i<4;i++){
			for(int j=0;j<4;j++){
				System.out.print("        "+matrix[i][j]);
			}
			System.out.println();
		}	
	}
	 /*
	  * this method prints the transpose of a passed matrix
	  */
	public void transpose(int[][] matrix){
		int[][] temp=new int[4][4];
		System.out.println("after transposing :");
		for(int i=0;i<4;i++){
			for(int j=0;j<4;j++){
			temp[j][i]=matrix[i][j];
			}
		}
		printMatrix(temp);
	}

}



