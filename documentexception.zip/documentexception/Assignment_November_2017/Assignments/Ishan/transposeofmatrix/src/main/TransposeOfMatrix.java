package main;
/*
 * this is the main class to find transpose of a matrix
 */
import java.util.Scanner;

import service.TransposeService;

public class TransposeOfMatrix {

	public static void main(String[] args) {
	TransposeService transpose = new TransposeService();
	transpose.inputMatrix();
	}

	}
	
