package com.yash.main;

import java.awt.Event;
import java.util.Scanner;
/**
 * this class tests the Toll Booth class functionality
 */
import com.yash.model.TollBooth;

public class TollBoothStartUp {

	public static void main(String[] args) {
		TollBooth booth = new TollBooth();
		Scanner sc = new Scanner(System.in);
		
		int choice=0;
		do {
			System.out.println("1.) Paying car passed");
			System.out.println("2.) Non Paying car passed");
			System.out.println("3.) Display all");
			choice = sc.nextInt();
			switch (choice) {
			case 1:
				booth.payingCar();
				break;
			case 2:
				booth.noPayCar();
				break;
			case 3:
				booth.display();
				break;
			default:
				break;
			}
		} while (true);
	}

}
