package com.yash.factorialofanumber;

import java.math.BigInteger;

public class Factorial {

	public String calculate(Integer input) {
		
		if(input==null || Math.signum(input)==-1){
			return "null";
			
		}
		
		
		BigInteger fact = new BigInteger(input.toString());
		int iterate;
		
		for(iterate = 1;iterate<input;iterate++){
			fact = fact.multiply(BigInteger.valueOf(iterate));
			
		
		}
		System.out.println(fact);
		return fact.toString();
		
		
	
	}

}
