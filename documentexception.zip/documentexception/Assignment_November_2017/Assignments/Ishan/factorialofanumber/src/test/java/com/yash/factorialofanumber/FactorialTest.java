package com.yash.factorialofanumber;

import static org.junit.Assert.*;

import java.math.BigInteger;

import org.junit.Test;

public class FactorialTest {
private static final Integer input = 0; 
	@Test
	public void test_no_input() {
		Factorial fact = new Factorial();
		String result = fact.calculate(null);
		assertEquals("null", result);
	}
	
	@Test
	public void test_any_input() {
		Factorial fact = new Factorial();
		String result = fact.calculate(input);
		assertEquals("0", result);
		
	}
	
	

}
