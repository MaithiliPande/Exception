package com.yash.main;

import java.io.Console;
import java.io.IOException;
import java.util.Scanner;

import com.yash.model.*;
/**
 * this class takes the user input in a console window
 * @author ishan.juneja
 *
 */
public class InputTest {

	public static void main(String[] args) throws IOException{
		Console console = System.console();
		if(console==null){
			System.err.println("no console found");
			System.exit(1);
		}
		Employee employee = new Employee();
		employee.setEmployeeId(Integer.parseInt(console.readLine("enter employee ID : ")));
		employee.setEmployeeSalary(Integer.parseInt(console.readLine("enter employee Salary : ")));
		employee.setEmployeeName(console.readLine("Enter Employee Name : "));

		console.writer().println("Employee ID : "+employee.getEmployeeId());
		console.writer().println("Employee Name : "+employee.getEmployeeName());
		console.writer().println("Employee Salary : "+employee.getEmployeeSalary());


	}

}
