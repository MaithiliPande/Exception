package com.yash.searchfromtennumbers;

import java.util.Scanner;
import java.util.regex.Pattern;

public class FindFromTenNumbers {
	/*
	 * it is an array to store numbers
	 */
	int[] numbersArray = new int[10];
	/*
	 * this is to store the count of number of times a given number has been repeated in the array
	 */
	int count=0;
	
	Scanner sc=new Scanner(System.in);
	/*
	 * this method will take input from a user
	 */
	public String takeInput() {
		System.out.println("enter 10 numbers one by one");
		for(int i=0;i<10;i++){			
			numbersArray[i]=sc.nextInt();
		}	
		return "10 numbers entered";
	}
	/*
	 * this method will calculate the count of a number being repeated.
	 */
	public int claculateCount(){
		System.out.println("enter number to be searched");
		int searchnumber = sc.nextInt();
		for(int i=0;i<10;i++){
			if(searchnumber==numbersArray[i]){
				count++;
			}
		}
		System.out.println(count);
	return count;
		
	}
	

}
