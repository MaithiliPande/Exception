package main;
/**
 * this is the main class for String reversal character wise
 */
import service.StringReverseService;

public class StringReversalByCharacter {

	public static void main(String[] args) {
		StringReverseService service= new StringReverseService();
		String input =service.inputString();
		service.reverseIt(input);
	}

}
