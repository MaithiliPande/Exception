package service;
/**
 * this class is a service class for String reversal by character
 */
import java.util.Scanner;

public class StringReverseService {

	/**
	 * this method is used to reverse a string character wise
	 * @param string
	 */
	public void reverseIt(String string) {
		char[] charArray=string.toCharArray();
		char temp;
		int startIndex=0;
		int lastIndex=charArray.length-1;
		while(startIndex<=lastIndex ){
			temp =charArray[startIndex];
			charArray[startIndex]=charArray[lastIndex];
			charArray[lastIndex]=temp;
			startIndex++;
			lastIndex--;
		}
		String result = new String(charArray);
		System.out.println(result);
	}
/**
 * this method is used to take input in the form of string from the user
 * @return
 */
	public String inputString() {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the string to be reversed");
		return sc.nextLine();
	}

}
