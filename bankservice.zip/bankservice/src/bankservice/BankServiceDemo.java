package bankservice;

public class BankServiceDemo {

	public static void main(String[] args) {
		BankService bank = new BankService();
		Thread one = new Thread(bank);
		Thread two = new Thread(bank);
		one.setName("Ryan");
		two.setName("Monica");
		one.start();
		two.start();
	

	}

}
