package bankservice;

public class BankService implements Runnable{
	
	Account account = new Account();

	@Override
	public void run() {
		System.out.println(Thread.currentThread().getName()+ " is withdrawing money");
		makeWithdrawal(50);
		if (account.getBalance()<0)
		{
			System.out.println("Overdrawn");
		}
		
	}
	
	private synchronized void makeWithdrawal(int amt)
	{
		if(account.getBalance()>=amt)
		{
			System.out.println("Balance :"+account.getBalance());
			System.out.println("Account name:"+Thread.currentThread().getName());
			System.out.println("Amount to withdraw:"+amt);
			account.withdraw(amt);
			System.out.println("Remaining Balance :"+account.getBalance());
			System.out.println("-----------------------------------------------");
		}
		else
		{
			System.out.println("Not enough balance");
		}
	}
	
	
}



	
	


